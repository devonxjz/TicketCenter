
CREATE   VIEW dbo.vw_JpaPayouts AS
SELECT p.id,p.settlement_id,p.amount,p.status,
 CONVERT(nvarchar(200),COALESCE(l.provider_reference,p.reference)) provider_reference,
 CAST(NULL AS nvarchar(2000)) failure_reason,p.created_at started_at,p.paid_at completed_at,
 p.created_at,COALESCE(p.paid_at,p.created_at) updated_at
FROM dbo.tc_payouts p LEFT JOIN dbo.tc_settlement_transfer_logs l ON l.id=p.id;
