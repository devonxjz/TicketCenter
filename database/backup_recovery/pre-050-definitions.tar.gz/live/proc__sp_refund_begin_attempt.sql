
-- SP10/SP09 already allocate the durable attempt. Claim it; do not allocate an automatic retry.
CREATE   PROCEDURE dbo.sp_refund_begin_attempt @refund_id uniqueidentifier,@attempt_id uniqueidentifier,@lease_token uniqueidentifier
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 DECLARE @started bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END;
 IF @started=1 BEGIN TRAN; ELSE SAVE TRAN khanh05_claim;
 BEGIN TRY
  IF COALESCE(IS_ROLEMEMBER('tc_worker'),0)<>1 AND COALESCE(IS_MEMBER('db_owner'),0)<>1 THROW 53500,'Worker principal required',1;
  IF @lease_token IS NULL THROW 53501,'Lease token required',1;
  -- Use the same Event -> Order -> Payment -> Request -> Attempt order as the financial SPs.
  DECLARE @status varchar(20),@amount decimal(19,0),@ref nvarchar(200),@kind varchar(10),@now datetime2(3)=SYSUTCDATETIME();
  DECLARE @payment uniqueidentifier,@request uniqueidentifier,@order uniqueidentifier,@event uniqueidentifier,@count bigint,@captured decimal(19,0),@payment_status varchar(20),@purpose varchar(30);
  SELECT @payment=payment_id,@request=refund_request_id FROM dbo.tc_refunds WHERE id=@attempt_id;
  SELECT @order=order_id FROM dbo.tc_payments WHERE id=@payment;
  SELECT @event=event_id FROM dbo.tc_orders WHERE id=@order;
  SELECT @count=COUNT_BIG(*) FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@event;
  SELECT @count=COUNT_BIG(*) FROM dbo.tc_orders WITH(UPDLOCK,HOLDLOCK) WHERE id=@order;
  SELECT @captured=amount,@payment_status=status FROM dbo.tc_payments WITH(UPDLOCK,HOLDLOCK) WHERE id=@payment;
  IF @request IS NOT NULL SELECT @count=COUNT_BIG(*) FROM dbo.tc_refund_requests WITH(UPDLOCK,HOLDLOCK) WHERE id=@request;
  SELECT @status=status,@amount=amount,@ref=provider_reference FROM dbo.tc_refunds WITH(UPDLOCK,HOLDLOCK) WHERE id=@attempt_id;
  IF @status NOT IN('PENDING','UNKNOWN') OR @status IS NULL OR @amount<=0 OR NOT EXISTS(
   SELECT 1 FROM dbo.tc_refund_transfer_logs l JOIN dbo.tc_refund_obligations o ON o.id=l.refund_id
   WHERE l.id=@attempt_id AND o.id=@refund_id AND o.current_attempt_id=@attempt_id) BEGIN
    IF @started=1 COMMIT; RETURN;
  END;
  SELECT @purpose=purpose FROM dbo.tc_refunds WHERE id=@attempt_id;
  IF @payment_status<>'CAPTURED' OR @payment_status IS NULL OR @amount>@captured
    OR (SELECT COALESCE(SUM(amount),0) FROM dbo.tc_refunds WHERE payment_id=@payment AND status IN('PENDING','UNKNOWN','SUCCEEDED'))>@captured
    OR (@purpose='CUSTOMER_REFUND' AND NOT EXISTS(SELECT 1 FROM dbo.tc_orders WHERE id=@order AND accepted_payment_id=@payment))
   THROW 53505,'Refund is not backed by a reserved captured payment',1;
  IF EXISTS(SELECT 1 FROM dbo.tc_refund_dispatches WITH(UPDLOCK,HOLDLOCK) WHERE attempt_id=@attempt_id AND
    (lease_until>@now OR next_query_at>@now)) BEGIN IF @started=1 COMMIT; RETURN; END;
  IF NOT EXISTS(SELECT 1 FROM dbo.tc_refund_dispatches WHERE attempt_id=@attempt_id) BEGIN
   SET @kind=CASE WHEN @status='PENDING' AND @ref IS NULL THEN 'EXECUTE' ELSE 'QUERY' END;
   INSERT dbo.tc_refund_dispatches(attempt_id,lease_token,lease_until,next_query_at) VALUES(@attempt_id,@lease_token,DATEADD(second,120,@now),@now);
  END ELSE BEGIN
   SET @kind='QUERY';
   UPDATE dbo.tc_refund_dispatches SET lease_token=@lease_token,lease_until=DATEADD(second,120,@now) WHERE attempt_id=@attempt_id;
  END;
  IF @started=1 COMMIT;
  SELECT @refund_id refund_id,@attempt_id attempt_id,@amount amount,@ref provider_reference,@kind work_kind,@lease_token lease_token;
 END TRY BEGIN CATCH
  IF @started=1 AND XACT_STATE()<>0 ROLLBACK; ELSE IF @started=0 AND XACT_STATE()=1 ROLLBACK TRAN khanh05_claim;
  THROW;
 END CATCH
END;
