
/* Stored Procedure: usp_ApplyRefundResult */
CREATE   PROCEDURE dbo.usp_ApplyRefundResult @refund_id uniqueidentifier, @verified_result nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @lock_count bigint;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp11;
    BEGIN TRY
        IF COALESCE(IS_ROLEMEMBER('tc_worker'), 0) <> 1 AND COALESCE(IS_ROLEMEMBER('db_owner'), 0) <> 1
            THROW 51409, 'Worker principal required', 1;
        IF ISJSON(@verified_result) <> 1 THROW 51410, 'Verified result must be JSON', 1;
        DECLARE @result varchar(20) = JSON_VALUE(@verified_result, '$.status'),
                @provider_reference nvarchar(200) = JSON_VALUE(@verified_result, '$.providerReference'),
                @request_id uniqueidentifier, @payment_id uniqueidentifier, @purpose varchar(30),
                @receipt uniqueidentifier, @fingerprint binary(32), @old_reference nvarchar(200), @problem varchar(60),
                @amount decimal(19,0), @current varchar(20), @order_id uniqueidentifier,
                @event_id uniqueidentifier, @payment_amount decimal(19,0),
                @now datetime2(3) = SYSUTCDATETIME();
        IF @result IS NULL OR @result NOT IN ('SUCCEEDED', 'FAILED', 'UNKNOWN') THROW 51411, 'Unsupported refund result', 1;
        IF @provider_reference IS NULL OR LEN(@provider_reference) = 0 THROW 51415, 'Provider reference is required', 1;

        SELECT @payment_id=payment_id,@request_id=refund_request_id FROM dbo.tc_refunds WHERE id=@refund_id;
        IF @payment_id IS NULL THROW 51412, 'Refund not found', 1;
        SELECT @order_id = order_id FROM dbo.tc_payments WHERE id = @payment_id;
        SELECT @event_id = event_id FROM dbo.tc_orders WHERE id = @order_id;
        SELECT @lock_count = COUNT_BIG(*) FROM dbo.tc_events WITH (UPDLOCK, HOLDLOCK) WHERE id = @event_id;
        SELECT @lock_count = COUNT_BIG(*) FROM dbo.tc_orders WITH (UPDLOCK, HOLDLOCK) WHERE id = @order_id;
        SELECT @payment_amount = amount FROM dbo.tc_payments WITH (UPDLOCK, HOLDLOCK) WHERE id = @payment_id;
        IF @request_id IS NOT NULL SELECT @lock_count=COUNT_BIG(*) FROM dbo.tc_refund_requests WITH(UPDLOCK,HOLDLOCK) WHERE id=@request_id;
        SELECT @lock_count = COUNT_BIG(*) FROM dbo.tc_refunds WITH (UPDLOCK, HOLDLOCK) WHERE payment_id = @payment_id;
        SELECT @request_id = refund_request_id, @purpose = purpose, @amount = amount, @current = status, @old_reference=provider_reference
        FROM dbo.tc_refunds WHERE id = @refund_id AND payment_id = @payment_id;
        IF @current IS NULL THROW 51412, 'Refund not found', 1;


        SET @now=SYSUTCDATETIME();
        SET @fingerprint=HASHBYTES('SHA2_256',CONCAT(CONVERT(varchar(36),@refund_id),'|',@result,'|',@provider_reference));
        SELECT @receipt=id FROM dbo.tc_gateway_refund_receipts WITH(UPDLOCK,HOLDLOCK) WHERE fingerprint=@fingerprint;
        IF @receipt IS NULL BEGIN
            SET @receipt=NEWID();
            INSERT dbo.tc_gateway_refund_receipts(id,refund_id,payment_id,fingerprint,observed_status,provider_reference,verified_payload)
            VALUES(@receipt,@refund_id,@payment_id,@fingerprint,@result,@provider_reference,@verified_result);
        END;
        IF @old_reference IS NOT NULL AND @old_reference<>@provider_reference SET @problem='PROVIDER_REFERENCE_CONFLICT';
        IF @current = 'SUCCEEDED' AND @problem IS NULL BEGIN
            UPDATE dbo.tc_gateway_refund_receipts SET resolution='APPLIED' WHERE id=@receipt;
            SELECT @refund_id refund_id, @current refund_status;
            IF @started = 1 COMMIT TRANSACTION; RETURN;
        END;
        IF @current='FAILED' AND @result='UNKNOWN' AND @problem IS NULL BEGIN
            UPDATE dbo.tc_gateway_refund_receipts SET resolution='IGNORED' WHERE id=@receipt;
            IF @started=1 COMMIT;
            SELECT @refund_id refund_id,@current refund_status; RETURN;
        END;
        IF @current='FAILED' AND @result='SUCCEEDED' AND (@old_reference IS NULL OR @old_reference<>@provider_reference) SET @problem='LATE_SUCCESS_UNMATCHED_REFERENCE';
        IF @current='FAILED' AND @result='SUCCEEDED' AND EXISTS(SELECT 1 FROM dbo.tc_refunds WHERE id<>@refund_id AND status IN('PENDING','UNKNOWN','SUCCEEDED') AND ((refund_request_id=@request_id AND @request_id IS NOT NULL) OR (@purpose='PAYMENT_COMPENSATION' AND payment_id=@payment_id AND purpose=@purpose))) SET @problem='LATE_SUCCESS_WITH_ANOTHER_ATTEMPT';
        IF @result = 'SUCCEEDED' AND
           (SELECT COALESCE(SUM(amount), 0) FROM dbo.tc_refunds WHERE payment_id = @payment_id AND status = 'SUCCEEDED') + @amount > @payment_amount
            SET @problem='REFUND_EXCEEDS_CAPTURE';

        IF @result = 'SUCCEEDED' AND @purpose = 'CUSTOMER_REFUND' BEGIN
            SELECT @lock_count = COUNT_BIG(*) FROM dbo.tc_tickets t WITH (UPDLOCK, HOLDLOCK)
            JOIN dbo.tc_refund_request_tickets rt ON rt.ticket_id = t.id
            WHERE rt.refund_request_id = @request_id;
            SELECT @lock_count = COUNT_BIG(*) FROM dbo.tc_zones z WITH (UPDLOCK, HOLDLOCK) WHERE EXISTS (
                SELECT 1 FROM dbo.tc_refund_request_tickets rt JOIN dbo.tc_tickets t ON t.id = rt.ticket_id
                JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id
                WHERE rt.refund_request_id = @request_id AND oi.zone_id = z.id);
            SELECT @lock_count = COUNT_BIG(*) FROM dbo.tc_seats s WITH (UPDLOCK, HOLDLOCK) WHERE EXISTS (
                SELECT 1 FROM dbo.tc_refund_request_tickets rt JOIN dbo.tc_tickets t ON t.id = rt.ticket_id
                JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id
                WHERE rt.refund_request_id = @request_id AND oi.seat_id = s.id);
            IF EXISTS (
                SELECT 1 FROM dbo.tc_zones z JOIN (
                    SELECT oi.zone_id, COUNT_BIG(*) quantity FROM dbo.tc_refund_request_tickets rt
                    JOIN dbo.tc_tickets t ON t.id = rt.ticket_id JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id
                    WHERE rt.refund_request_id = @request_id AND oi.seat_id IS NULL AND t.status = 'REFUND_PENDING'
                    GROUP BY oi.zone_id
                ) q ON q.zone_id = z.id WHERE z.sold_quantity < q.quantity)
                SET @problem='INVENTORY_INCONSISTENT';
        END;

        IF @problem IS NOT NULL BEGIN
            UPDATE dbo.tc_gateway_refund_receipts SET resolution='NEEDS_RECONCILIATION',reason=@problem WHERE id=@receipt;
            UPDATE dbo.tc_refund_obligations SET status='NEEDS_RECONCILIATION',updated_at=@now WHERE id=@refund_id OR legacy_request_id=@request_id;
            INSERT dbo.tc_audit_logs(action,aggregate_type,aggregate_id,detail) VALUES('REFUND_RECONCILIATION_REQUIRED','REFUND',@refund_id,@problem);
            IF @started=1 COMMIT;
            SELECT @refund_id refund_id,CAST('NEEDS_RECONCILIATION' AS varchar(30)) refund_status; RETURN;
        END;
        UPDATE dbo.tc_gateway_refund_receipts SET resolution='APPLIED' WHERE id=@receipt;
        UPDATE dbo.tc_refunds SET status = @result, provider_reference = @provider_reference,
               processed_at = CASE WHEN @result IN ('SUCCEEDED', 'FAILED') THEN @now ELSE processed_at END,
               version = version + 1 WHERE id = @refund_id;

        IF @result = 'SUCCEEDED' AND @purpose = 'CUSTOMER_REFUND' BEGIN
            UPDATE s SET status = 'AVAILABLE', version = s.version + 1
            FROM dbo.tc_seats s JOIN dbo.tc_order_items oi ON oi.seat_id = s.id
            JOIN dbo.tc_tickets t ON t.order_item_id = oi.id JOIN dbo.tc_refund_request_tickets rt ON rt.ticket_id = t.id
            WHERE rt.refund_request_id = @request_id AND t.status = 'REFUND_PENDING' AND s.status = 'SOLD';
            UPDATE z SET sold_quantity = sold_quantity - q.quantity, version = z.version + 1
            FROM dbo.tc_zones z JOIN (
                SELECT oi.zone_id, COUNT_BIG(*) quantity FROM dbo.tc_refund_request_tickets rt
                JOIN dbo.tc_tickets t ON t.id = rt.ticket_id JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id
                WHERE rt.refund_request_id = @request_id AND oi.seat_id IS NULL AND t.status = 'REFUND_PENDING'
                GROUP BY oi.zone_id
            ) q ON q.zone_id = z.id;
            UPDATE t SET status = 'REFUNDED', version = t.version + 1
            FROM dbo.tc_tickets t JOIN dbo.tc_refund_request_tickets rt ON rt.ticket_id = t.id
            WHERE rt.refund_request_id = @request_id AND t.status = 'REFUND_PENDING';
            UPDATE dbo.tc_refund_request_tickets SET is_open = 0 WHERE refund_request_id = @request_id;
            UPDATE dbo.tc_refund_requests SET status = 'COMPLETED', version = version + 1 WHERE id = @request_id;
        END;

        INSERT dbo.tc_audit_logs(action, aggregate_type, aggregate_id, detail)
        VALUES (CONCAT('REFUND_', @result), 'REFUND', @refund_id, @provider_reference);
        IF @result = 'SUCCEEDED' INSERT dbo.tc_outbox(event_type, aggregate_type, aggregate_id, payload, idempotency_key)
        VALUES ('REFUND_SUCCEEDED', 'REFUND', @refund_id,
                CONCAT(N'{"refundId":"', @refund_id, N'"}'), CONCAT('refund-succeeded:', @refund_id));
        IF @started = 1 COMMIT TRANSACTION;
        SELECT @refund_id refund_id, @result refund_status;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp11;
        THROW;
    END CATCH
END;
