-- ON tc_refund_request_tickets

/* Trigger: trg_RefundRequestTicket_MirrorCanonical */
CREATE   TRIGGER dbo.trg_RefundRequestTicket_MirrorCanonical
ON dbo.tc_refund_request_tickets AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE t
    SET is_open = i.is_open
    FROM dbo.tc_refund_tickets t
    JOIN dbo.tc_refund_obligations o ON o.id = t.refund_id
    JOIN inserted i ON i.refund_request_id = o.legacy_request_id AND i.ticket_id = t.ticket_id;

    INSERT dbo.tc_refund_tickets(refund_id, ticket_id, is_open, created_at)
    SELECT o.id, i.ticket_id, i.is_open, i.added_at
    FROM inserted i
    JOIN dbo.tc_refund_obligations o ON o.legacy_request_id = i.refund_request_id
    WHERE NOT EXISTS (
        SELECT 1 FROM dbo.tc_refund_tickets t WHERE t.refund_id = o.id AND t.ticket_id = i.ticket_id
    );

    UPDATE o
    SET amount = totals.amount, updated_at = SYSUTCDATETIME()
    FROM dbo.tc_refund_obligations o
    JOIN (SELECT DISTINCT refund_request_id FROM inserted) affected ON affected.refund_request_id = o.legacy_request_id
    CROSS APPLY (
        SELECT COALESCE(SUM(t.paid_amount), 0) amount
        FROM dbo.tc_refund_request_tickets rt
        JOIN dbo.tc_tickets t ON t.id = rt.ticket_id
        WHERE rt.refund_request_id = o.legacy_request_id
    ) totals;
END;
