-- ON tc_settlement_items

/* Trigger: trg_SettlementItem_MirrorCanonical */
CREATE   TRIGGER dbo.trg_SettlementItem_MirrorCanonical
ON dbo.tc_settlement_items AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE s
    SET settlement_id = i.settlement_id, order_id = i.order_id,
        gross_amount = i.gross_amount, refund_amount = i.refund_amount,
        commission_amount = i.commission_amount, net_amount = i.net_amount,
        updated_at = SYSUTCDATETIME()
    FROM dbo.tc_settlement_order_snapshots s JOIN inserted i ON i.id = s.id;

    INSERT dbo.tc_settlement_order_snapshots
        (id, settlement_id, order_id, gross_amount, refund_amount, commission_amount, net_amount)
    SELECT i.id, i.settlement_id, i.order_id, i.gross_amount, i.refund_amount, i.commission_amount, i.net_amount
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM dbo.tc_settlement_order_snapshots s WHERE s.id = i.id);
END;
