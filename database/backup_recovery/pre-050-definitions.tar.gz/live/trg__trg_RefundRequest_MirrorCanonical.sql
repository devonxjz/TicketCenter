-- ON tc_refund_requests

/* Trigger: trg_RefundRequest_MirrorCanonical */
/* Mirror proven legacy write paths into canonical persistence tables. */
CREATE   TRIGGER dbo.trg_RefundRequest_MirrorCanonical
ON dbo.tc_refund_requests AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE o
    SET order_id = i.order_id,
        reason_type = i.reason_type,
        reason = i.reason,
        rejection_reason = i.rejection_reason,
        status = CASE
            WHEN i.status = 'COMPLETED' THEN 'COMPLETED'
            WHEN i.status = 'REJECTED' THEN 'REJECTED'
            WHEN i.status = 'APPROVED' AND o.current_attempt_id IS NULL THEN 'APPROVED'
            ELSE o.status
        END,
        updated_at = SYSUTCDATETIME()
    FROM dbo.tc_refund_obligations o
    JOIN inserted i ON i.id = o.legacy_request_id;

    INSERT dbo.tc_refund_obligations
        (id, legacy_request_id, order_id, payment_id, amount, purpose, reason_type,
         reason, rejection_reason, status, created_at, updated_at)
    SELECT i.id, i.id, i.order_id, captured.id, 0, 'CUSTOMER_REFUND', i.reason_type,
           i.reason, i.rejection_reason,
           CASE i.status WHEN 'APPROVED' THEN 'APPROVED' WHEN 'REJECTED' THEN 'REJECTED'
                         WHEN 'COMPLETED' THEN 'COMPLETED' ELSE 'REQUESTED' END,
           i.requested_at, SYSUTCDATETIME()
    FROM inserted i
    OUTER APPLY (
        SELECT TOP (1) p.id FROM dbo.tc_payments p
        WHERE p.order_id = i.order_id AND p.status = 'CAPTURED'
        ORDER BY p.captured_at, p.created_at, p.id
    ) captured
    WHERE NOT EXISTS (SELECT 1 FROM dbo.tc_refund_obligations o WHERE o.legacy_request_id = i.id);
END;
