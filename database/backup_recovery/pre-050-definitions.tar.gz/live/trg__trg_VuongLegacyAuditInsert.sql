-- ON vw_VuongAuditLogs
CREATE   TRIGGER dbo.trg_VuongLegacyAuditInsert ON dbo.vw_VuongAuditLogs INSTEAD OF INSERT AS
 BEGIN
  SET NOCOUNT ON;
  IF EXISTS(SELECT 1 FROM inserted WHERE TRY_CONVERT(uniqueidentifier,entity_id) IS NULL) THROW 52702,'Invalid finance audit entity identifier',1;
  /* Internal NEWID supplied by finance procedures is not a public audit ID.
     The legacy store allocates its own identity; reads return its stable UUID. */
  INSERT dbo.tc_audit_logs(actor_id,action,aggregate_type,aggregate_id,detail,created_at)
  SELECT actor_id,action,entity_type,CONVERT(uniqueidentifier,entity_id),metadata_json,created_at FROM inserted;
 END;