-- ON tc_refunds

/* Trigger: trg_RefundAttempt_MirrorCanonical */
CREATE   TRIGGER dbo.trg_RefundAttempt_MirrorCanonical
ON dbo.tc_refunds AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT dbo.tc_refund_obligations
        (id, order_id, payment_id, amount, purpose, status, current_attempt_id,
         provider_reference, processed_at, created_at, updated_at)
    SELECT i.id, p.order_id, i.payment_id, i.amount, i.purpose,
           CASE i.status WHEN 'SUCCEEDED' THEN 'COMPLETED' WHEN 'FAILED' THEN 'RETRYABLE'
                         WHEN 'UNKNOWN' THEN 'NEEDS_RECONCILIATION' ELSE 'PROCESSING' END,
           i.id, i.provider_reference, i.processed_at, i.created_at, SYSUTCDATETIME()
    FROM inserted i
    JOIN dbo.tc_payments p ON p.id = i.payment_id
    WHERE i.refund_request_id IS NULL
      AND NOT EXISTS (SELECT 1 FROM dbo.tc_refund_obligations o WHERE o.id = i.id);

    UPDATE l
    SET status = i.status, result = i.status,
        provider_reference = i.provider_reference, processed_at = i.processed_at
    FROM dbo.tc_refund_transfer_logs l JOIN inserted i ON i.id = l.id;

    ;WITH attempts AS (
        SELECT i.*, COALESCE(o.id, i.id) obligation_id,
               ROW_NUMBER() OVER (PARTITION BY COALESCE(o.id, i.id) ORDER BY i.created_at, i.id)
               + COALESCE(existing.max_attempt_no, 0) attempt_no
        FROM inserted i
        LEFT JOIN dbo.tc_refund_obligations o ON o.legacy_request_id = i.refund_request_id
        OUTER APPLY (
            SELECT MAX(l.attempt_no) max_attempt_no
            FROM dbo.tc_refund_transfer_logs l
            WHERE l.refund_id = COALESCE(o.id, i.id)
        ) existing
    )
    INSERT dbo.tc_refund_transfer_logs
        (id, refund_id, attempt_no, status, result, provider_reference, processed_at, created_at)
    SELECT a.id, a.obligation_id, a.attempt_no, a.status, a.status,
           a.provider_reference, a.processed_at, a.created_at
    FROM attempts a
    WHERE NOT EXISTS (SELECT 1 FROM dbo.tc_refund_transfer_logs l WHERE l.id = a.id);

    UPDATE o
    SET payment_id = i.payment_id,
        amount = i.amount,
        status = CASE i.status WHEN 'SUCCEEDED' THEN 'COMPLETED' WHEN 'FAILED' THEN 'RETRYABLE'
                               WHEN 'UNKNOWN' THEN 'NEEDS_RECONCILIATION' ELSE 'PROCESSING' END,
        current_attempt_id = i.id,
        provider_reference = i.provider_reference,
        processed_at = i.processed_at,
        updated_at = SYSUTCDATETIME()
    FROM dbo.tc_refund_obligations o
    JOIN inserted i ON o.id = i.id OR o.legacy_request_id = i.refund_request_id;
END;
