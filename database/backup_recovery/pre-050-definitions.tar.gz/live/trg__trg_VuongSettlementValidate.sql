-- ON tc_settlements

CREATE   TRIGGER dbo.trg_VuongSettlementValidate ON dbo.tc_settlements AFTER INSERT,UPDATE,DELETE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM deleted d LEFT JOIN inserted i ON i.id=d.id WHERE i.id IS NULL AND d.status<>'DRAFT') THROW 52709,'SETTLEMENT_IMMUTABLE',1;
 IF EXISTS(SELECT 1 FROM inserted WHERE status NOT IN('DRAFT','CONFIRMED','PAID') OR gross_revenue<0 OR total_refund<0 OR total_commission<0 OR total_refund+total_commission>gross_revenue OR paid_amount<0 OR pending_amount<0 OR paid_amount+pending_amount>net_payable OR (status='PAID' AND (paid_amount<>net_payable OR pending_amount<>0))) THROW 52702,'SETTLEMENT_BALANCE_INVALID',1;
 IF EXISTS(SELECT 1 FROM inserted i JOIN deleted d ON d.id=i.id WHERE i.event_id<>d.event_id OR (d.status IN('CONFIRMED','PAID') AND EXISTS(SELECT i.gross_revenue,i.total_refund,i.total_commission,i.confirmed_at EXCEPT SELECT d.gross_revenue,d.total_refund,d.total_commission,d.confirmed_at)) OR (d.status='PAID' AND i.status<>'PAID') OR (d.status='CONFIRMED' AND i.status='DRAFT')) THROW 52709,'SETTLEMENT_SNAPSHOT_IMMUTABLE',1;
 IF EXISTS(SELECT 1 FROM inserted s WHERE s.paid_amount<>COALESCE((SELECT SUM(amount) FROM dbo.tc_settlement_transfer_logs WHERE settlement_id=s.id AND status='SUCCEEDED'),0) OR s.pending_amount<>COALESCE((SELECT SUM(amount) FROM dbo.tc_settlement_transfer_logs WHERE settlement_id=s.id AND status='PENDING'),0)) THROW 52702,'PAYOUT_LEDGER_MISMATCH',1;
 IF EXISTS(SELECT 1 FROM inserted s WHERE s.gross_revenue<>COALESCE((SELECT SUM(gross_amount) FROM dbo.tc_settlement_order_snapshots WHERE settlement_id=s.id),0) OR s.total_refund<>COALESCE((SELECT SUM(refund_amount) FROM dbo.tc_settlement_order_snapshots WHERE settlement_id=s.id),0) OR s.total_commission<>COALESCE((SELECT SUM(commission_amount) FROM dbo.tc_settlement_order_snapshots WHERE settlement_id=s.id),0)) THROW 52702,'SETTLEMENT_SNAPSHOT_MISMATCH',1;
END;
