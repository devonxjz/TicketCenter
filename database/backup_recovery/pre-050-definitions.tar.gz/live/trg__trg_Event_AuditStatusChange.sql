-- ON tc_events

/* Trigger: trg_Event_AuditStatusChange */
CREATE   TRIGGER dbo.trg_Event_AuditStatusChange ON dbo.tc_events
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT dbo.tc_audit_logs(actor_id, action, aggregate_type, aggregate_id, detail)
    SELECT TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'actor_id')), 'EVENT_STATUS_CHANGED', 'EVENT',
           i.id, CONCAT(N'{"from":"', d.status, N'","to":"', i.status, N'"}')
    FROM inserted i JOIN deleted d ON d.id = i.id WHERE i.status <> d.status;
END;
