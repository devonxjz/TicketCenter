
/* Stored Procedure: usp_CalculateEventSettlement */
CREATE   PROCEDURE dbo.usp_CalculateEventSettlement @event_id uniqueidentifier, @actor_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp14;
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.tc_user_platform_roles WHERE user_id = @actor_id AND role = 'ADMIN')
            THROW 51540, 'Administrator role required', 1;
        DECLARE @rule_id uniqueidentifier, @rate decimal(7,4), @fixed decimal(19,0), @settlement_id uniqueidentifier,
                @settlement_status varchar(20), @gross decimal(19,0), @refund decimal(19,0), @commission decimal(19,0), @net decimal(19,0);
        SELECT @rule_id = commission_rule_id FROM dbo.tc_events WITH (UPDLOCK, HOLDLOCK) WHERE id = @event_id;
        IF @rule_id IS NULL THROW 51541, 'Event has no applied commission rule', 1;
        SELECT @rate = rate_percent, @fixed = fixed_fee FROM dbo.tc_commission_rules WHERE id = @rule_id;
        SELECT o.id FROM dbo.tc_orders o WITH (UPDLOCK, HOLDLOCK) WHERE o.event_id = @event_id ORDER BY o.id;
        SELECT @settlement_id = id, @settlement_status = status FROM dbo.tc_settlements WITH (UPDLOCK, HOLDLOCK) WHERE event_id = @event_id;
        IF @settlement_status IN ('CONFIRMED', 'PAID') THROW 51542, 'Confirmed settlement cannot be recalculated', 1;
        DECLARE @items TABLE(order_id uniqueidentifier PRIMARY KEY, gross decimal(19,0), refund decimal(19,0), commission decimal(19,0), net decimal(19,0));
        INSERT @items
        SELECT order_id, total_amount, ticket_refund_amount,
               dbo.fn_CalculateCommission(remaining_ticket_amount, @rate, @fixed),
               remaining_ticket_amount - dbo.fn_CalculateCommission(remaining_ticket_amount, @rate, @fixed)
        FROM dbo.vw_OrderFinancialSummary WHERE event_id = @event_id AND status = 'PAID';
        SELECT @gross = COALESCE(SUM(gross), 0), @refund = COALESCE(SUM(refund), 0),
               @commission = COALESCE(SUM(commission), 0), @net = COALESCE(SUM(net), 0) FROM @items;
        IF NOT EXISTS (SELECT 1 FROM @items) AND @settlement_id IS NULL BEGIN
            IF @started = 1 COMMIT TRANSACTION;
            SELECT CAST(NULL AS uniqueidentifier) settlement_id, @gross gross_revenue, @refund total_refund, @commission total_commission, @net net_payable; RETURN;
        END;
        IF @settlement_id IS NULL BEGIN SET @settlement_id = NEWID(); INSERT dbo.tc_settlements(id, event_id) VALUES (@settlement_id, @event_id); END;
        DELETE FROM dbo.tc_settlement_items WHERE settlement_id = @settlement_id;
        INSERT dbo.tc_settlement_items(settlement_id, order_id, gross_amount, refund_amount, commission_amount, net_amount)
        SELECT @settlement_id, order_id, gross, refund, commission, net FROM @items;
        UPDATE dbo.tc_settlements SET gross_revenue = @gross, total_refund = @refund,
               total_commission = @commission, net_payable = @net, version = version + 1 WHERE id = @settlement_id;
        IF @started = 1 COMMIT TRANSACTION;
        SELECT @settlement_id settlement_id, @gross gross_revenue, @refund total_refund, @commission total_commission, @net net_payable;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp14;
        THROW;
    END CATCH
END;
