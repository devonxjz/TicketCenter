-- ON tc_users

CREATE   TRIGGER dbo.trg_User_AuthRoleGuard ON dbo.tc_users AFTER INSERT,UPDATE AS
BEGIN SET NOCOUNT ON;
 IF COALESCE(IS_ROLEMEMBER('tc_auth'),0)=1 AND COALESCE(IS_MEMBER('db_owner'),0)<>1
 AND EXISTS(SELECT 1 FROM inserted i LEFT JOIN deleted d ON d.id=i.id WHERE (d.id IS NULL AND i.platform_role<>'CUSTOMER') OR (d.id IS NOT NULL AND i.platform_role<>d.platform_role))
 THROW 51818,'Authentication principal cannot assign platform roles',1;
END;
