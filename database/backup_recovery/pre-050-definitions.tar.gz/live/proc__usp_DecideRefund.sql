
/* Stored Procedure: usp_DecideRefund */
CREATE   PROCEDURE dbo.usp_DecideRefund
    @refund_id uniqueidentifier,
    @actor_id uniqueidentifier = NULL,
    @decision varchar(20),
    @rejection_reason nvarchar(2000) = NULL,
    @attempt_id uniqueidentifier = NULL,
    @retry_failed bit = 0
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @request_id uniqueidentifier = COALESCE(
        (SELECT legacy_request_id FROM dbo.tc_refund_obligations WHERE id = @refund_id),
        CASE WHEN EXISTS (SELECT 1 FROM dbo.tc_refund_requests WHERE id = @refund_id) THEN @refund_id END
    );
    IF @request_id IS NULL THROW 52630, 'Refund obligation not found', 1;
    EXEC dbo.usp_DecideRefundRequest
        @request_id = @request_id,
        @actor_id = @actor_id,
        @decision = @decision,
        @rejection_reason = @rejection_reason,
        @retry_failed = @retry_failed;
END;
