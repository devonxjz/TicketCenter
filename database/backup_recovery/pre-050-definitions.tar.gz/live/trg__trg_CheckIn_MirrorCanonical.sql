-- ON tc_check_ins

/* Trigger: trg_CheckIn_MirrorCanonical */
CREATE   TRIGGER dbo.trg_CheckIn_MirrorCanonical
ON dbo.tc_check_ins AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT dbo.tc_ticket_check_in_logs(id, event_id, ticket_id, actor_id, result, scanned_at)
    SELECT i.id, i.event_id, i.ticket_id, i.actor_id,
           CASE i.result
               WHEN 'NOT_FOUND' THEN 'INVALID_CODE'
               WHEN 'TOO_EARLY' THEN 'OUTSIDE_WINDOW'
               WHEN 'TOO_LATE' THEN 'OUTSIDE_WINDOW'
               WHEN 'NOT_ACTIVE' THEN 'INACTIVE_TICKET'
               WHEN 'EVENT_CANCELLED' THEN 'INACTIVE_TICKET'
               ELSE i.result
           END,
           i.scanned_at
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM dbo.tc_ticket_check_in_logs l WHERE l.id = i.id);
END;
