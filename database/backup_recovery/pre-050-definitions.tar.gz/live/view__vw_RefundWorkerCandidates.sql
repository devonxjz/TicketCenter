
CREATE   VIEW dbo.vw_RefundWorkerCandidates AS
 SELECT r.id attempt_id,l.refund_id,r.amount,r.provider_reference,
 CASE WHEN d.attempt_id IS NULL AND r.status='PENDING' AND r.provider_reference IS NULL THEN 'EXECUTE' ELSE 'QUERY' END work_kind,
 r.created_at
 FROM dbo.tc_refunds r JOIN dbo.tc_refund_transfer_logs l ON l.id=r.id
 JOIN dbo.tc_refund_obligations o ON o.id=l.refund_id AND o.current_attempt_id=r.id
 LEFT JOIN dbo.tc_refund_dispatches d ON d.attempt_id=r.id
 WHERE r.status IN('PENDING','UNKNOWN') AND r.amount>0
 AND (d.lease_until IS NULL OR d.lease_until<=SYSUTCDATETIME())
 AND (d.attempt_id IS NULL OR d.next_query_at<=SYSUTCDATETIME());
