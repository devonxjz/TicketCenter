
/* Stored Procedure: usp_CheckInTicket */
CREATE   PROCEDURE dbo.usp_CheckInTicket
    @event_id uniqueidentifier, @actor_id uniqueidentifier, @ticket_code varchar(100)
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp04;
    BEGIN TRY
        DECLARE @organization_id uniqueidentifier, @ticket_id uniqueidentifier, @ticket_event uniqueidentifier,
                @ticket_status varchar(30), @result varchar(30), @now datetime2(3) = SYSUTCDATETIME();
        SELECT @organization_id = organization_id FROM dbo.tc_events WITH (UPDLOCK, HOLDLOCK) WHERE id = @event_id;
        IF @organization_id IS NULL THROW 51240, 'Event not found', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.tc_organization_memberships WHERE user_id = @actor_id
                       AND organization_id = @organization_id AND active = 1 AND role IN ('MANAGER', 'CHECK_IN_STAFF'))
            THROW 51241, 'Active event staff membership required', 1;
        SELECT @ticket_id = t.id, @ticket_status = t.status, @ticket_event = o.event_id
        FROM dbo.tc_tickets t WITH (UPDLOCK, HOLDLOCK) JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id
        JOIN dbo.tc_orders o ON o.id = oi.order_id WHERE t.ticket_code = @ticket_code;
        IF @ticket_id IS NULL SET @result = 'NOT_FOUND';
        ELSE IF @ticket_event <> @event_id SET @result = 'WRONG_EVENT';
        ELSE IF EXISTS (SELECT 1 FROM dbo.tc_events WHERE id = @event_id AND status = 'CANCELLED') SET @result = 'EVENT_CANCELLED';
        ELSE IF @now < (SELECT opens_at FROM dbo.fn_GetEventCheckInWindow(@event_id, @now)) SET @result = 'TOO_EARLY';
        ELSE IF @now >= (SELECT closes_at FROM dbo.fn_GetEventCheckInWindow(@event_id, @now)) SET @result = 'TOO_LATE';
        ELSE IF @ticket_status = 'USED' SET @result = 'ALREADY_USED';
        ELSE IF @ticket_status <> 'ACTIVE' SET @result = 'NOT_ACTIVE';
        ELSE BEGIN UPDATE dbo.tc_tickets SET status = 'USED', version = version + 1 WHERE id = @ticket_id; SET @result = 'SUCCESS'; END;
        INSERT dbo.tc_check_ins(event_id, ticket_id, actor_id, result, scanned_at)
        VALUES (@event_id, CASE WHEN @result = 'NOT_FOUND' THEN NULL ELSE @ticket_id END, @actor_id, @result, @now);
        IF @started = 1 COMMIT TRANSACTION;
        SELECT @result result, @now scanned_at, @ticket_id ticket_id;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp04;
        THROW;
    END CATCH
END;
