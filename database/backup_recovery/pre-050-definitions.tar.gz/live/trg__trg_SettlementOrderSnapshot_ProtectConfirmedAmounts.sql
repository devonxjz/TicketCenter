-- ON tc_settlement_order_snapshots

/* Trigger: trg_SettlementOrderSnapshot_ProtectConfirmedAmounts */
CREATE   TRIGGER dbo.trg_SettlementOrderSnapshot_ProtectConfirmedAmounts
ON dbo.tc_settlement_order_snapshots AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1
        FROM (
            SELECT settlement_id FROM inserted
            UNION
            SELECT settlement_id FROM deleted
        ) affected
        JOIN dbo.tc_settlements s WITH (UPDLOCK, HOLDLOCK) ON s.id = affected.settlement_id
        WHERE s.status IN ('CONFIRMED', 'PAID')
    ) THROW 52640, 'Confirmed settlement order snapshots are immutable', 1;
END;
