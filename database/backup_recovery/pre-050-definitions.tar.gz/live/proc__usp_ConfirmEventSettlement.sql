
/* Stored Procedure: usp_ConfirmEventSettlement */
CREATE   PROCEDURE dbo.usp_ConfirmEventSettlement @settlement_id uniqueidentifier, @actor_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp15;
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.tc_user_platform_roles WHERE user_id = @actor_id AND role = 'ADMIN')
            THROW 51550, 'Administrator role required', 1;
        DECLARE @event_id uniqueidentifier, @status varchar(20), @net decimal(19,0);
        SELECT @event_id = event_id, @status = status, @net = net_payable FROM dbo.tc_settlements WITH (UPDLOCK, HOLDLOCK) WHERE id = @settlement_id;
        IF @event_id IS NULL THROW 51551, 'Settlement not found', 1;
        IF @status IN ('CONFIRMED', 'PAID') BEGIN
            SELECT * FROM dbo.vw_SettlementPayoutBalance WHERE settlement_id = @settlement_id;
            IF @started = 1 COMMIT TRANSACTION; RETURN;
        END;
        SELECT 1 FROM dbo.tc_events WITH (UPDLOCK, HOLDLOCK) WHERE id = @event_id;
        SELECT id FROM dbo.tc_orders WITH (UPDLOCK, HOLDLOCK) WHERE event_id = @event_id ORDER BY id;
        IF EXISTS (SELECT 1 FROM dbo.fn_GetSettlementBlockers(@event_id, SYSUTCDATETIME()))
            THROW 51552, 'Settlement has unresolved blockers', 1;
        EXEC dbo.usp_CalculateEventSettlement @event_id, @actor_id;
        SELECT @net = net_payable FROM dbo.tc_settlements WHERE id = @settlement_id;
        UPDATE dbo.tc_settlements SET status = CASE WHEN @net = 0 THEN 'PAID' ELSE 'CONFIRMED' END,
               confirmed_at = SYSUTCDATETIME(), version = version + 1 WHERE id = @settlement_id;
        INSERT dbo.tc_audit_logs(actor_id, action, aggregate_type, aggregate_id)
        VALUES (@actor_id, 'SETTLEMENT_CONFIRMED', 'SETTLEMENT', @settlement_id);
        IF @started = 1 COMMIT TRANSACTION;
        SELECT * FROM dbo.vw_SettlementPayoutBalance WHERE settlement_id = @settlement_id;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp15;
        THROW;
    END CATCH
END;
