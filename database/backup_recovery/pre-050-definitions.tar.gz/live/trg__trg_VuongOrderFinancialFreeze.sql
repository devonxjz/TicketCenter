-- ON tc_orders

-- Reject later owner writes that would invalidate a confirmed financial source. These triggers
-- also acquire the Event lock, so conflicts with confirmation abort instead of accepting a stale snapshot.
CREATE   TRIGGER dbo.trg_VuongOrderFinancialFreeze ON dbo.tc_orders AFTER INSERT,UPDATE,DELETE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted i FULL JOIN deleted d ON d.id=i.id
 CROSS APPLY(SELECT i.event_id event_id UNION SELECT d.event_id) a JOIN dbo.tc_events e WITH(UPDLOCK,HOLDLOCK) ON e.id=a.event_id JOIN dbo.tc_settlements s ON s.event_id=e.id
 WHERE s.status IN('CONFIRMED','PAID') AND (i.id IS NULL OR d.id IS NULL OR EXISTS(SELECT i.user_id,i.event_id,i.status,i.accepted_payment_id,i.paid_at,i.total_amount,i.subtotal_amount,i.discount_amount EXCEPT SELECT d.user_id,d.event_id,d.status,d.accepted_payment_id,d.paid_at,d.total_amount,d.subtotal_amount,d.discount_amount)))
 THROW 52709,'CONFIRMED_FINANCIAL_SOURCE_IMMUTABLE',1;
END;
