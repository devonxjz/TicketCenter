-- ON tc_payouts

/* Trigger: trg_Payout_MirrorCanonical */
CREATE   TRIGGER dbo.trg_Payout_MirrorCanonical
ON dbo.tc_payouts AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE l
    SET settlement_id = i.settlement_id, amount = i.amount, status = i.status, result = i.status,
        provider_reference = i.reference, processed_at = i.paid_at
    FROM dbo.tc_settlement_transfer_logs l JOIN inserted i ON i.id = l.id;

    INSERT dbo.tc_settlement_transfer_logs
        (id, settlement_id, amount, status, result, provider_reference, processed_at, created_at)
    SELECT i.id, i.settlement_id, i.amount, i.status, i.status, i.reference, i.paid_at, i.created_at
    FROM inserted i
    WHERE NOT EXISTS (SELECT 1 FROM dbo.tc_settlement_transfer_logs l WHERE l.id = i.id);

    UPDATE s
    SET paid_amount = balances.paid_amount,
        pending_amount = balances.pending_amount,
        updated_at = SYSUTCDATETIME()
    FROM dbo.tc_settlements s
    JOIN (SELECT DISTINCT settlement_id FROM inserted) affected ON affected.settlement_id = s.id
    CROSS APPLY (
        SELECT COALESCE(SUM(CASE WHEN p.status = 'SUCCEEDED' THEN p.amount ELSE 0 END), 0) paid_amount,
               COALESCE(SUM(CASE WHEN p.status = 'PENDING' THEN p.amount ELSE 0 END), 0) pending_amount
        FROM dbo.tc_payouts p WHERE p.settlement_id = s.id
    ) balances;
END;
