-- ON tc_settlement_items

/* Trigger: trg_SettlementItem_ProtectConfirmedAmounts */
CREATE   TRIGGER dbo.trg_SettlementItem_ProtectConfirmedAmounts ON dbo.tc_settlement_items
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted i JOIN dbo.tc_settlements s ON s.id = i.settlement_id
        WHERE s.status IN ('CONFIRMED', 'PAID')
    ) OR EXISTS (
        SELECT 1 FROM deleted d JOIN dbo.tc_settlements s ON s.id = d.settlement_id
        WHERE s.status IN ('CONFIRMED', 'PAID')
    ) THROW 51104, 'Confirmed settlement items are immutable', 1;
END;
