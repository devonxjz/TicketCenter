
/* View: vw_RefundWork */
CREATE   VIEW dbo.vw_RefundWork
AS
    SELECT id, amount, status, provider_reference, created_at
    FROM dbo.tc_refunds
    WHERE status IN ('PENDING', 'UNKNOWN');
