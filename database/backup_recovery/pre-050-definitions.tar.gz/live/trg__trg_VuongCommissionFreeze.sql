-- ON tc_commission_rules

CREATE   TRIGGER dbo.trg_VuongCommissionFreeze ON dbo.tc_commission_rules AFTER UPDATE,DELETE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM deleted d LEFT JOIN inserted i ON i.id=d.id JOIN dbo.tc_events e WITH(UPDLOCK,HOLDLOCK) ON e.commission_rule_id=d.id WHERE i.id IS NULL OR EXISTS(SELECT i.organization_id,i.rate_percent,i.fixed_fee,i.effective_from,i.effective_to EXCEPT SELECT d.organization_id,d.rate_percent,d.fixed_fee,d.effective_from,d.effective_to)) THROW 52709,'RULE_ALREADY_ATTACHED_TO_EVENTS',1;
END;
