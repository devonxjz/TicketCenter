
CREATE   VIEW dbo.v_admin_refund_requests AS
SELECT r.id refund_id,r.order_id,o.user_id buyer_id,u.full_name buyer_name,u.email buyer_email,
 e.title event_name,r.amount,r.reason,r.status,r.created_at,r.rejection_reason,r.current_attempt_id,
 (SELECT COUNT(*) FROM dbo.tc_refund_tickets t WHERE t.refund_id=r.id) ticket_count,
 q.reviewer_id,q.decided_at,
 CAST(CASE WHEN r.status='REQUESTED' AND q.status='PENDING' AND r.current_attempt_id IS NULL THEN 1 ELSE 0 END AS bit) can_decide,
 CAST(CASE WHEN r.status='RETRYABLE' AND a.status='FAILED'
  AND NOT EXISTS(SELECT 1 FROM dbo.tc_refunds f WHERE f.refund_request_id=q.id AND f.status IN('PENDING','UNKNOWN','SUCCEEDED'))
  AND NOT EXISTS(SELECT 1 FROM dbo.tc_gateway_refund_receipts x WHERE x.payment_id=r.payment_id AND x.resolution='NEEDS_RECONCILIATION')
  THEN 1 ELSE 0 END AS bit) can_retry
FROM dbo.tc_refund_obligations r JOIN dbo.tc_refund_requests q ON q.id=r.legacy_request_id
JOIN dbo.tc_orders o ON o.id=r.order_id JOIN dbo.tc_events e ON e.id=o.event_id
JOIN dbo.tc_users u ON u.id=o.user_id
LEFT JOIN dbo.tc_refund_transfer_logs a ON a.id=r.current_attempt_id AND a.refund_id=r.id
WHERE r.purpose='CUSTOMER_REFUND';
