-- ON tc_order_items

CREATE   TRIGGER dbo.trg_OrderItem_ValidateEventSeat ON dbo.tc_order_items AFTER INSERT,UPDATE AS
BEGIN SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted i JOIN dbo.tc_orders o ON o.id=i.order_id JOIN dbo.tc_zones z ON z.id=i.zone_id LEFT JOIN dbo.tc_seats s ON s.id=i.seat_id
 WHERE z.event_id<>o.event_id OR (i.event_id IS NOT NULL AND i.event_id<>o.event_id) OR (i.seat_id IS NOT NULL AND s.zone_id<>i.zone_id)) THROW 51820,'Order item zone or seat belongs to another event',1;
 UPDATE i SET event_id=o.event_id FROM dbo.tc_order_items i JOIN inserted n ON n.id=i.id JOIN dbo.tc_orders o ON o.id=i.order_id WHERE i.event_id IS NULL;
END;
