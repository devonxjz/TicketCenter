
/* View: vw_EventCancellationProgress */
CREATE   VIEW dbo.vw_EventCancellationProgress
AS
    SELECT e.id event_id, e.status event_status,
           (SELECT COUNT_BIG(*) FROM dbo.tc_orders o WHERE o.event_id = e.id) total_orders,
           (SELECT COUNT_BIG(*) FROM dbo.tc_orders o
            WHERE o.event_id = e.id AND (
                EXISTS (SELECT 1 FROM dbo.tc_ticket_holds h WHERE h.id = o.hold_id AND h.status = 'ACTIVE')
                OR EXISTS (SELECT 1 FROM dbo.tc_order_items oi JOIN dbo.tc_tickets t ON t.order_item_id = oi.id
                           WHERE oi.order_id = o.id AND t.status = 'ACTIVE')
                OR EXISTS (SELECT 1 FROM dbo.tc_refund_requests rr WHERE rr.order_id = o.id AND rr.status = 'PENDING')
                OR EXISTS (SELECT 1 FROM dbo.tc_refund_requests rr
                           LEFT JOIN dbo.tc_refunds r ON r.refund_request_id = rr.id
                           WHERE rr.order_id = o.id AND rr.reason_type = 'EVENT_CANCELLATION'
                             AND rr.status = 'APPROVED' AND (r.id IS NULL OR r.status = 'PENDING')))) pending_orders,
           (SELECT COUNT_BIG(*) FROM dbo.tc_orders o
            WHERE o.event_id = e.id
              AND NOT EXISTS (SELECT 1 FROM dbo.tc_ticket_holds h WHERE h.id = o.hold_id AND h.status = 'ACTIVE')
              AND NOT EXISTS (SELECT 1 FROM dbo.tc_order_items oi JOIN dbo.tc_tickets t ON t.order_item_id = oi.id
                              WHERE oi.order_id = o.id AND t.status NOT IN ('REFUNDED', 'INVALIDATED'))
              AND NOT EXISTS (SELECT 1 FROM dbo.vw_EventCancellationExceptions x WHERE x.order_id = o.id)) completed_orders,
           (SELECT COUNT_BIG(*) FROM dbo.vw_EventCancellationExceptions x WHERE x.event_id = e.id) exception_count,
           (SELECT COUNT_BIG(*) FROM dbo.tc_refund_requests rr JOIN dbo.tc_orders o ON o.id = rr.order_id
            WHERE o.event_id = e.id AND rr.reason_type = 'EVENT_CANCELLATION') requests_created,
           (SELECT COUNT_BIG(*) FROM dbo.tc_refunds r JOIN dbo.tc_refund_requests rr ON rr.id = r.refund_request_id
            JOIN dbo.tc_orders o ON o.id = rr.order_id
            WHERE o.event_id = e.id AND rr.reason_type = 'EVENT_CANCELLATION' AND r.status = 'SUCCEEDED') refunds_succeeded,
           (SELECT COUNT_BIG(*) FROM dbo.tc_refunds r JOIN dbo.tc_refund_requests rr ON rr.id = r.refund_request_id
            JOIN dbo.tc_orders o ON o.id = rr.order_id
            WHERE o.event_id = e.id AND rr.reason_type = 'EVENT_CANCELLATION' AND r.status = 'PENDING') refunds_pending
    FROM dbo.tc_events e;
