-- ON tc_payments

CREATE   TRIGGER dbo.trg_VuongPaymentFinancialFreeze ON dbo.tc_payments AFTER INSERT,UPDATE,DELETE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted i FULL JOIN deleted d ON d.id=i.id
 CROSS APPLY(SELECT i.order_id order_id UNION SELECT d.order_id) a JOIN dbo.vw_VuongOrders o ON o.id=a.order_id JOIN dbo.tc_events e WITH(UPDLOCK,HOLDLOCK) ON e.id=o.event_id JOIN dbo.tc_settlements s ON s.event_id=e.id
 WHERE s.status IN('CONFIRMED','PAID') AND (o.accepted_payment_id=COALESCE(i.id,d.id) OR i.status IN('PENDING','UNKNOWN'))
 AND (i.id IS NULL OR d.id IS NULL OR EXISTS(SELECT i.order_id,i.amount,i.status,i.captured_at EXCEPT SELECT d.order_id,d.amount,d.status,d.captured_at)))
 THROW 52709,'CONFIRMED_FINANCIAL_SOURCE_IMMUTABLE',1;
END;
