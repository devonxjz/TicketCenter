
/* Stored Procedure: usp_ExecutePayout */
CREATE   PROCEDURE dbo.usp_ExecutePayout
    @settlement_id uniqueidentifier, @payout_id uniqueidentifier, @actor_id uniqueidentifier,
    @amount decimal(19,0), @reference varchar(100), @verified_result varchar(20)
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp16;
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.tc_user_platform_roles WHERE user_id = @actor_id AND role = 'ADMIN')
            THROW 51560, 'Administrator role required', 1;
        IF @amount <= 0 OR @verified_result NOT IN ('PENDING', 'SUCCEEDED', 'FAILED') THROW 51561, 'Invalid payout input', 1;
        DECLARE @event_id uniqueidentifier, @settlement_status varchar(20), @net decimal(19,0), @current varchar(20),
                @paid decimal(19,0), @pending decimal(19,0);
        SELECT @event_id = event_id, @settlement_status = status, @net = net_payable
        FROM dbo.tc_settlements WITH (UPDLOCK, HOLDLOCK) WHERE id = @settlement_id;
        IF @event_id IS NULL THROW 51562, 'Settlement not found', 1;
        SELECT 1 FROM dbo.tc_events WITH (UPDLOCK, HOLDLOCK) WHERE id = @event_id;
        SELECT @current = status FROM dbo.tc_payouts WITH (UPDLOCK, HOLDLOCK) WHERE id = @payout_id;
        IF @current = 'SUCCEEDED' BEGIN
            SELECT * FROM dbo.vw_SettlementPayoutBalance WHERE settlement_id = @settlement_id;
            IF @started = 1 COMMIT TRANSACTION; RETURN;
        END;
        IF @current IS NULL BEGIN
            IF @settlement_status <> 'CONFIRMED' THROW 51563, 'Only a confirmed settlement accepts a payout', 1;
            SELECT @paid = COALESCE(SUM(CASE WHEN status = 'SUCCEEDED' THEN amount ELSE 0 END), 0),
                   @pending = COALESCE(SUM(CASE WHEN status = 'PENDING' THEN amount ELSE 0 END), 0)
            FROM dbo.tc_payouts WITH (UPDLOCK, HOLDLOCK) WHERE settlement_id = @settlement_id;
            IF @paid + @pending + @amount > @net THROW 51564, 'Payout exceeds available settlement balance', 1;
            INSERT dbo.tc_payouts(id, settlement_id, amount, reference, status, paid_at)
            VALUES (@payout_id, @settlement_id, @amount, @reference, @verified_result,
                    CASE WHEN @verified_result = 'SUCCEEDED' THEN SYSUTCDATETIME() END);
        END ELSE BEGIN
            IF @current <> 'PENDING' THROW 51565, 'Failed payout requires a new payout id', 1;
            IF EXISTS (SELECT 1 FROM dbo.tc_payouts WHERE id = @payout_id AND (amount <> @amount OR reference <> @reference))
                THROW 51566, 'Payout replay payload mismatch', 1;
            UPDATE dbo.tc_payouts SET status = @verified_result,
                   paid_at = CASE WHEN @verified_result = 'SUCCEEDED' THEN SYSUTCDATETIME() ELSE NULL END,
                   version = version + 1 WHERE id = @payout_id;
        END;
        IF (SELECT COALESCE(SUM(amount), 0) FROM dbo.tc_payouts WHERE settlement_id = @settlement_id AND status = 'SUCCEEDED') = @net
            UPDATE dbo.tc_settlements SET status = 'PAID', version = version + 1 WHERE id = @settlement_id AND status = 'CONFIRMED';
        INSERT dbo.tc_audit_logs(actor_id, action, aggregate_type, aggregate_id, detail)
        VALUES (@actor_id, CONCAT('PAYOUT_', @verified_result), 'PAYOUT', @payout_id, @reference);
        IF @started = 1 COMMIT TRANSACTION;
        SELECT * FROM dbo.vw_SettlementPayoutBalance WHERE settlement_id = @settlement_id;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp16;
        THROW;
    END CATCH
END;
