-- ON tc_settlement_order_snapshots

CREATE   TRIGGER dbo.trg_VuongSnapshotFreeze ON dbo.tc_settlement_order_snapshots AFTER INSERT,UPDATE,DELETE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM (SELECT settlement_id FROM inserted UNION SELECT settlement_id FROM deleted) a JOIN dbo.tc_settlements s WITH(UPDLOCK,HOLDLOCK) ON s.id=a.settlement_id WHERE s.status IN('CONFIRMED','PAID')) THROW 52709,'SETTLEMENT_SNAPSHOT_IMMUTABLE',1;
 IF EXISTS(SELECT 1 FROM inserted WHERE gross_amount<0 OR refund_amount<0 OR commission_amount<0 OR net_amount<0 OR refund_amount+commission_amount>gross_amount OR net_amount<>gross_amount-refund_amount-commission_amount) THROW 52702,'INVALID_FINANCIALS',1;
END;
