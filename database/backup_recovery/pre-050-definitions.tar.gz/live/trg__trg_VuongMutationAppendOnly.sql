-- ON tc_finance_mutations

CREATE   TRIGGER dbo.trg_VuongMutationAppendOnly ON dbo.tc_finance_mutations AFTER UPDATE,DELETE AS
BEGIN SET NOCOUNT ON; IF EXISTS(SELECT 1 FROM deleted) THROW 52709,'MUTATION_HISTORY_IMMUTABLE',1; END;
