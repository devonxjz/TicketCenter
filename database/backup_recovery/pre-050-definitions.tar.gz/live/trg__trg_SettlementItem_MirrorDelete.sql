-- ON tc_settlement_items

CREATE   TRIGGER dbo.trg_SettlementItem_MirrorDelete ON dbo.tc_settlement_items AFTER DELETE AS
BEGIN SET NOCOUNT ON;
 DELETE s FROM dbo.tc_settlement_order_snapshots s JOIN deleted d ON d.id=s.id;
END;
