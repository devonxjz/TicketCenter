-- ON tc_users

/* Trigger: trg_tc_users_normalize */
CREATE   TRIGGER dbo.trg_tc_users_normalize
    ON dbo.tc_users AFTER INSERT, UPDATE
    AS
    BEGIN
        SET NOCOUNT ON;
        UPDATE u
        SET normalized_email = LOWER(u.email)
        FROM dbo.tc_users u
        JOIN inserted i ON u.id = i.id
        WHERE u.normalized_email IS NULL OR u.normalized_email <> LOWER(u.email);
    END
