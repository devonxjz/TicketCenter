
/* View: vw_FailedCompensationAttempts */
CREATE   VIEW dbo.vw_FailedCompensationAttempts
AS
    SELECT DISTINCT r.payment_id, p.order_id
    FROM dbo.tc_refunds r
    JOIN dbo.tc_payments p ON p.id = r.payment_id
    WHERE r.purpose = 'PAYMENT_COMPENSATION' AND r.status = 'FAILED'
      AND NOT EXISTS (
          SELECT 1 FROM dbo.tc_refunds active
          WHERE active.payment_id = r.payment_id AND active.purpose = 'PAYMENT_COMPENSATION'
            AND active.status IN ('PENDING', 'UNKNOWN', 'SUCCEEDED'));
