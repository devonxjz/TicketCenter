-- ON tc_seats

/* Trigger: trg_Seat_ProtectPublishedLayout */
CREATE   TRIGGER dbo.trg_Seat_ProtectPublishedLayout ON dbo.tc_seats
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted i LEFT JOIN deleted d ON d.id = i.id
        JOIN dbo.tc_zones z ON z.id = i.zone_id JOIN dbo.tc_events e ON e.id = z.event_id
        WHERE e.status IN ('PUBLISHED', 'CANCELLED')
          AND (d.id IS NULL OR d.zone_id <> i.zone_id OR d.row_name <> i.row_name
               OR d.seat_number <> i.seat_number OR d.label <> i.label)
    ) OR EXISTS (
        SELECT 1 FROM deleted d LEFT JOIN inserted i ON i.id = d.id
        JOIN dbo.tc_zones z ON z.id = d.zone_id JOIN dbo.tc_events e ON e.id = z.event_id
        WHERE e.status IN ('PUBLISHED', 'CANCELLED') AND (i.id IS NULL OR i.zone_id <> d.zone_id)
    ) THROW 51102, 'Published event seat layout is immutable', 1;
END;
