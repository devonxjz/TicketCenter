
/* Stored Procedure: dbo.sp_organization_reject */
CREATE   PROCEDURE dbo.sp_organization_reject
    @organization_id uniqueidentifier,
    @admin_user_id uniqueidentifier,
    @rejected_reason nvarchar(2000)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- Kiểm tra quyền ADMIN trong dbo.tc_user_platform_roles
    IF NOT EXISTS (
        SELECT 1
        FROM dbo.tc_user_platform_roles
        WHERE user_id = @admin_user_id AND role = 'ADMIN'
    )
    BEGIN
        THROW 52610, 'Administrator role required', 1;
    END;

    DECLARE @tran_started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @tran_started = 1
        BEGIN TRANSACTION;
    ELSE
        SAVE TRANSACTION sp_organization_reject_sp;

    BEGIN TRY
        -- Khóa tổ chức WITH (UPDLOCK, ROWLOCK)
        DECLARE @status varchar(30);

        SELECT @status = status
        FROM dbo.tc_organizations WITH (UPDLOCK, ROWLOCK)
        WHERE id = @organization_id;

        -- Nếu không tìm thấy THROW 52611
        IF @status IS NULL
            THROW 52611, 'Organization not found', 1;

        -- Nếu status <> 'PENDING_APPROVAL' THROW 52612, 'ORGANIZATION_ALREADY_PROCESSED', 1;
        IF @status <> 'PENDING_APPROVAL'
            THROW 52612, 'ORGANIZATION_ALREADY_PROCESSED', 1;

        -- Validate @rejected_reason: không rỗng, độ dài từ 10 đến 500 ký tự. Nếu sai THROW 52614
        IF @rejected_reason IS NULL OR LEN(LTRIM(RTRIM(@rejected_reason))) < 10 OR LEN(LTRIM(RTRIM(@rejected_reason))) > 500
            THROW 52614, 'Rejection reason must be between 10 and 500 characters', 1;

        -- Cập nhật dbo.tc_organizations: status = 'REJECTED', decided_at = SYSUTCDATETIME(), updated_at = SYSUTCDATETIME(), rejection_reason = @rejected_reason
        UPDATE dbo.tc_organizations
        SET status = 'REJECTED',
            decided_at = SYSUTCDATETIME(),
            updated_at = SYSUTCDATETIME(),
            rejection_reason = @rejected_reason
        WHERE id = @organization_id;

        -- Ghi dbo.tc_audit_logs
        INSERT INTO dbo.tc_audit_logs (actor_id, action, aggregate_type, aggregate_id, detail)
        VALUES (@admin_user_id, 'ORGANIZATION_REJECTED', 'ORGANIZATION', @organization_id, @rejected_reason);

        IF @tran_started = 1
            COMMIT TRANSACTION;

        SELECT @organization_id AS organization_id,
               CAST('REJECTED' AS varchar(30)) AS status;
    END TRY
    BEGIN CATCH
        IF @tran_started = 1 AND XACT_STATE() <> 0
            ROLLBACK TRANSACTION;
        ELSE IF @tran_started = 0 AND XACT_STATE() = 1
            ROLLBACK TRANSACTION sp_organization_reject_sp;
        THROW;
    END CATCH;
END;
