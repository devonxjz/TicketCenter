
CREATE   TRIGGER dbo.trg_VuongTransferLedger ON dbo.tc_settlement_transfer_logs AFTER INSERT,UPDATE,DELETE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM deleted d LEFT JOIN inserted i ON i.id=d.id WHERE i.id IS NULL) THROW 52709,'PAYOUT_HISTORY_IMMUTABLE',1;
 IF EXISTS(SELECT 1 FROM inserted i LEFT JOIN deleted d ON d.id=i.id WHERE d.id IS NULL AND i.status<>'PENDING') THROW 52709,'PAYOUT_RESERVATION_REQUIRED',1;
 IF EXISTS(SELECT 1 FROM inserted WHERE amount<=0 OR status NOT IN('PENDING','SUCCEEDED','FAILED') OR result<>status OR request_fingerprint IS NULL OR verification_state NOT IN('PENDING','UNKNOWN','SUCCEEDED','FAILED') OR (status='PENDING' AND (processed_at IS NOT NULL OR verification_state NOT IN('PENDING','UNKNOWN'))) OR (status IN('SUCCEEDED','FAILED') AND (processed_at IS NULL OR verification_state<>status))) THROW 52702,'PAYOUT_INVALID',1;
 IF EXISTS(SELECT 1 FROM inserted i JOIN deleted d ON d.id=i.id WHERE EXISTS(SELECT i.settlement_id,i.amount,i.request_fingerprint,i.requested_reference EXCEPT SELECT d.settlement_id,d.amount,d.request_fingerprint,d.requested_reference) OR (d.status IN('SUCCEEDED','FAILED') AND EXISTS(SELECT i.status,i.result,i.provider_reference,i.processed_at,i.verification_state EXCEPT SELECT d.status,d.result,d.provider_reference,d.processed_at,d.verification_state)) OR (d.verification_state='UNKNOWN' AND i.verification_state='PENDING')) THROW 52709,'PAYOUT_HISTORY_IMMUTABLE',1;
 IF EXISTS(SELECT 1 FROM inserted i JOIN dbo.tc_settlements s WITH(UPDLOCK,HOLDLOCK) ON s.id=i.settlement_id WHERE s.status<>'CONFIRMED') THROW 52709,'SETTLEMENT_NOT_CONFIRMED',1;
 UPDATE s SET paid_amount=t.paid,pending_amount=t.pending,status=CASE WHEN t.paid=s.net_payable AND t.pending=0 THEN 'PAID' ELSE 'CONFIRMED' END,updated_at=SYSUTCDATETIME()
 FROM dbo.tc_settlements s JOIN(SELECT DISTINCT settlement_id FROM inserted) a ON a.settlement_id=s.id CROSS APPLY(SELECT COALESCE(SUM(CASE WHEN status='SUCCEEDED' THEN amount ELSE 0 END),0) paid,COALESCE(SUM(CASE WHEN status='PENDING' THEN amount ELSE 0 END),0) pending FROM dbo.tc_settlement_transfer_logs WHERE settlement_id=s.id) t;
END;
