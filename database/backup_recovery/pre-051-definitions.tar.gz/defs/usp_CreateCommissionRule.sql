
CREATE   PROCEDURE dbo.usp_CreateCommissionRule
 @organization_id uniqueidentifier,@actor_id uniqueidentifier,@idempotency_key uniqueidentifier,@rate_percent decimal(12,4),@fixed_fee decimal(19,0),@effective_from datetime2(3),@effective_to datetime2(3),@auth_version int=NULL
AS BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY
 BEGIN TRANSACTION;
 EXEC dbo.usp_VuongRequireAdmin @actor_id,@auth_version;
 IF @idempotency_key IS NULL OR @rate_percent IS NULL OR @rate_percent<0 OR @rate_percent>100 OR @fixed_fee IS NULL OR @fixed_fee<0 OR @effective_from IS NULL OR @effective_to IS NULL OR @effective_from>=@effective_to THROW 52702,'COMMISSION_RULE_INVALID',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_organizations WITH(UPDLOCK,HOLDLOCK) WHERE id=@organization_id) THROW 52704,'ORGANIZATION_NOT_FOUND',1;
 DECLARE @fingerprint binary(32)=HASHBYTES('SHA2_256',CONCAT(CONVERT(varchar(36),@organization_id),'|',@rate_percent,'|',@fixed_fee,'|',CONVERT(varchar(30),@effective_from,126),'|',CONVERT(varchar(30),@effective_to,126))),@rule_id uniqueidentifier,@replay bit=0;
 SELECT @rule_id=resource_id FROM dbo.tc_finance_mutations WITH(UPDLOCK,HOLDLOCK) WHERE idempotency_key=@idempotency_key;
 IF @rule_id IS NOT NULL BEGIN
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_finance_mutations WHERE idempotency_key=@idempotency_key AND actor_id=@actor_id AND operation='COMMISSION_CREATE' AND fingerprint=@fingerprint) THROW 52709,'IDEMPOTENCY_CONFLICT',1;
 SET @replay=1;
 END ELSE BEGIN
 SET @rule_id=NEWID();
 INSERT dbo.tc_commission_rules(id,organization_id,rate_percent,fixed_fee,effective_from,effective_to,created_at,updated_at) VALUES(@rule_id,@organization_id,@rate_percent,@fixed_fee,@effective_from,@effective_to,SYSUTCDATETIME(),SYSUTCDATETIME());
 INSERT dbo.tc_finance_mutations(idempotency_key,actor_id,operation,fingerprint,resource_id,response_json) VALUES(@idempotency_key,@actor_id,'COMMISSION_CREATE',@fingerprint,@rule_id,
 (SELECT @organization_id organizationId,@rate_percent ratePercent,@fixed_fee fixedFee,@effective_from effectiveFrom,@effective_to effectiveTo FOR JSON PATH,WITHOUT_ARRAY_WRAPPER));
 INSERT dbo.vw_VuongAuditLogs(id,created_at,updated_at,actor_id,action,entity_type,entity_id,metadata_json) VALUES(NEWID(),SYSUTCDATETIME(),SYSUTCDATETIME(),@actor_id,'COMMISSION_CREATED','CommissionRule',CONVERT(varchar(36),@rule_id),(SELECT @organization_id organizationId,@rate_percent ratePercent,@fixed_fee fixedFee FOR JSON PATH,WITHOUT_ARRAY_WRAPPER));
 END;
 SELECT c.id rule_id,COALESCE(TRY_CONVERT(uniqueidentifier,JSON_VALUE(m.response_json,'$.organizationId')),c.organization_id) organization_id,
 COALESCE(TRY_CONVERT(decimal(12,4),JSON_VALUE(m.response_json,'$.ratePercent')),c.rate_percent) rate_percent,
 COALESCE(TRY_CONVERT(decimal(19,0),JSON_VALUE(m.response_json,'$.fixedFee')),c.fixed_fee) fixed_fee,
 COALESCE(TRY_CONVERT(datetime2(3),JSON_VALUE(m.response_json,'$.effectiveFrom')),c.effective_from) effective_from,
 COALESCE(TRY_CONVERT(datetime2(3),JSON_VALUE(m.response_json,'$.effectiveTo')),c.effective_to) effective_to,
 (SELECT COUNT_BIG(*) FROM dbo.tc_events WHERE commission_rule_id=c.id) associated_events_count,@replay is_replay FROM dbo.tc_commission_rules c JOIN dbo.tc_finance_mutations m ON m.resource_id=c.id AND m.idempotency_key=@idempotency_key WHERE c.id=@rule_id;
 COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
