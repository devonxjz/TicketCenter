CREATE   PROCEDURE dbo.usp_ReviewRefundRequest
    @request_id uniqueidentifier, @actor_id uniqueidentifier = NULL, @decision varchar(20),
    @rejection_reason nvarchar(1000) = NULL, @retry_failed bit = 0
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @lock_count bigint;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp10;
    BEGIN TRY
        IF @decision NOT IN ('APPROVE', 'REJECT') THROW 51400, 'Invalid refund decision', 1;
        DECLARE @order_id uniqueidentifier, @event_id uniqueidentifier, @reason_type varchar(30), @status varchar(20),
                @event_status varchar(30), @amount decimal(19,0), @refund_id uniqueidentifier, @payment_id uniqueidentifier,
                @now datetime2(3) = SYSUTCDATETIME();
        SELECT @order_id=order_id FROM dbo.tc_refund_obligations WHERE id=@request_id AND purpose='CUSTOMER_REFUND';
        SELECT @event_id=event_id FROM dbo.tc_orders WHERE id=@order_id;
        IF @event_id IS NULL THROW 51401,'Refund request not found',1;
        SELECT @event_status=status FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@event_id;
        IF @actor_id IS NOT NULL SELECT @lock_count=COUNT_BIG(*) FROM dbo.tc_users WITH(UPDLOCK,HOLDLOCK) WHERE id=@actor_id;
        SELECT @payment_id=accepted_payment_id FROM dbo.tc_orders WITH(UPDLOCK,HOLDLOCK) WHERE id=@order_id;
        SELECT @lock_count=COUNT_BIG(*) FROM dbo.tc_payments WITH(UPDLOCK,HOLDLOCK) WHERE id=@payment_id;
        SELECT @reason_type=reason_type,@status=request_status FROM dbo.tc_refund_obligations WITH(UPDLOCK,HOLDLOCK) WHERE id=@request_id;
        SET @now=SYSUTCDATETIME();
        IF @actor_id IS NULL BEGIN
            IF @decision<>'APPROVE' OR @reason_type<>'EVENT_CANCELLATION' OR @event_status<>'CANCELLED'
               OR (COALESCE(IS_ROLEMEMBER('tc_worker'),0)<>1 AND COALESCE(IS_MEMBER('db_owner'),0)<>1) THROW 51402,'System approval only for cancelled event',1;
        END ELSE IF NOT EXISTS(SELECT 1 FROM dbo.tc_users WHERE id=@actor_id AND platform_role='ADMIN' AND status='ACTIVE') THROW 51402,'Administrator role required',1;
        IF @reason_type = 'EVENT_CANCELLATION' AND @event_status <> 'CANCELLED' THROW 51403, 'Cancellation request requires cancelled event', 1;
        IF @status IN ('REJECTED', 'COMPLETED') BEGIN
            IF (@status = 'REJECTED' AND @decision <> 'REJECT') OR (@status = 'COMPLETED' AND @decision <> 'APPROVE')
                THROW 51404, 'Refund request already has the opposite final decision', 1;
            SELECT @request_id request_id, @status request_status, CAST(NULL AS uniqueidentifier) refund_id;
            IF @started = 1 COMMIT TRANSACTION; RETURN;
        END;
        SELECT @lock_count = COUNT_BIG(*) FROM dbo.tc_tickets t WITH (UPDLOCK, HOLDLOCK) JOIN dbo.tc_refund_tickets rt ON rt.ticket_id = t.id
        WHERE rt.refund_id = @request_id;
        IF @decision = 'REJECT' BEGIN
            IF NULLIF(LTRIM(RTRIM(@rejection_reason)), N'') IS NULL THROW 51405, 'Rejection reason is required', 1;
            UPDATE t SET status = CASE WHEN @event_status = 'CANCELLED' THEN 'INVALIDATED' ELSE 'ACTIVE' END, version = t.version + 1
            FROM dbo.tc_tickets t JOIN dbo.tc_refund_tickets rt ON rt.ticket_id = t.id
            WHERE rt.refund_id = @request_id AND t.status = 'REFUND_PENDING';
            UPDATE dbo.tc_refund_tickets SET is_open = 0 WHERE refund_id = @request_id;
            UPDATE dbo.tc_refund_obligations SET status = 'REJECTED', reviewer_id = @actor_id, decided_at = @now,
                   rejection_reason = @rejection_reason, version = version + 1, updated_at = @now WHERE id = @request_id;
        END ELSE BEGIN
            SELECT @amount = SUM(t.paid_amount) FROM dbo.tc_tickets t JOIN dbo.tc_refund_tickets rt ON rt.ticket_id = t.id
            WHERE rt.refund_id = @request_id;
            IF @amount = 0 BEGIN
                SELECT @lock_count = COUNT_BIG(*) FROM dbo.tc_zones z WITH (UPDLOCK, HOLDLOCK) WHERE EXISTS (
                    SELECT 1 FROM dbo.tc_refund_tickets rt JOIN dbo.tc_tickets t ON t.id = rt.ticket_id
                    JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id WHERE rt.refund_id = @request_id AND oi.zone_id = z.id);
                UPDATE s SET status = 'AVAILABLE', version = s.version + 1 FROM dbo.tc_seats s JOIN dbo.tc_order_items oi ON oi.seat_id = s.id
                JOIN dbo.tc_tickets t ON t.order_item_id = oi.id JOIN dbo.tc_refund_tickets rt ON rt.ticket_id = t.id
                WHERE rt.refund_id = @request_id AND s.status = 'SOLD';
                UPDATE z SET sold_quantity = sold_quantity - q.quantity, version = z.version + 1 FROM dbo.tc_zones z JOIN (
                    SELECT oi.zone_id, COUNT_BIG(*) quantity FROM dbo.tc_refund_tickets rt JOIN dbo.tc_tickets t ON t.id = rt.ticket_id
                    JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id WHERE rt.refund_id = @request_id AND oi.seat_id IS NULL GROUP BY oi.zone_id
                ) q ON q.zone_id = z.id;
                UPDATE t SET status = 'REFUNDED', version = t.version + 1 FROM dbo.tc_tickets t
                JOIN dbo.tc_refund_tickets rt ON rt.ticket_id = t.id WHERE rt.refund_id = @request_id;
                UPDATE dbo.tc_refund_tickets SET is_open = 0 WHERE refund_id = @request_id;
                UPDATE dbo.tc_refund_obligations SET status = 'COMPLETED', reviewer_id = @actor_id, decided_at = @now, version = version + 1, updated_at = @now WHERE id = @request_id;
            END ELSE BEGIN
                IF EXISTS (SELECT 1 FROM dbo.tc_refund_transfer_logs WHERE refund_id = @request_id AND status IN ('PENDING', 'UNKNOWN', 'SUCCEEDED')) BEGIN
                    SELECT TOP (1) @refund_id = id FROM dbo.tc_refund_transfer_logs WHERE refund_id = @request_id ORDER BY attempt_no DESC;
                END ELSE BEGIN
                    IF @retry_failed = 0 AND EXISTS (SELECT 1 FROM dbo.tc_refund_transfer_logs WHERE refund_id = @request_id AND status = 'FAILED')
                        THROW 51406, 'Refund retry requires explicit authorization', 1;
                    SELECT @payment_id=accepted_payment_id FROM dbo.tc_orders WHERE id=@order_id;
                    IF NOT EXISTS(SELECT 1 FROM dbo.tc_payments WHERE id=@payment_id AND order_id=@order_id AND status='CAPTURED') SET @payment_id=NULL;
                    IF @payment_id IS NULL THROW 51407, 'Captured payment not found', 1;
                    IF (SELECT COALESCE(SUM(amount),0) FROM dbo.vw_RefundAttemptLedger WHERE payment_id=@payment_id AND status IN('PENDING','UNKNOWN','SUCCEEDED'))+@amount>(SELECT amount FROM dbo.tc_payments WHERE id=@payment_id) THROW 51805,'Refund reservation exceeds captured amount',1;
                    IF EXISTS(SELECT 1 FROM dbo.tc_gateway_refund_receipts WHERE payment_id=@payment_id AND resolution='NEEDS_RECONCILIATION') THROW 51806,'Gateway reconciliation is required before retry',1;
                    SET @refund_id = NEWID();
                    INSERT dbo.tc_refund_transfer_logs(id, refund_id, attempt_no, status, result, created_at)
                    SELECT @refund_id, @request_id, COALESCE(MAX(attempt_no), 0) + 1, 'PENDING', 'PENDING', @now
                    FROM dbo.tc_refund_transfer_logs WHERE refund_id = @request_id;
                    UPDATE dbo.tc_refund_obligations SET payment_id = @payment_id, amount = @amount, status = 'PROCESSING',
                           current_attempt_id = @refund_id, provider_reference = NULL, processed_at = NULL, updated_at = @now
                    WHERE id = @request_id;
                END;
                UPDATE dbo.tc_refund_obligations SET reviewer_id = @actor_id,
                       decided_at = COALESCE(decided_at, @now), version = version + 1, updated_at = @now WHERE id = @request_id;
            END;
        END;
        INSERT dbo.tc_audit_logs(actor_id, action, aggregate_type, aggregate_id, detail)
        VALUES (@actor_id, CONCAT('REFUND_REQUEST_', @decision), 'REFUND_REQUEST', @request_id, @rejection_reason);
        IF @started = 1 COMMIT TRANSACTION;
        SELECT @request_id request_id, request_status, @refund_id refund_id FROM dbo.tc_refund_obligations WHERE id = @request_id;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp10;
        THROW;
    END CATCH
END;
