
/* Stored Procedure: usp_DecideRefundRequest */
CREATE   PROCEDURE dbo.usp_DecideRefundRequest
    @request_id uniqueidentifier,
    @actor_id uniqueidentifier,
    @decision varchar(20),
    @rejection_reason nvarchar(1000) = NULL,
    @retry_failed bit = 0
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.usp_ReviewRefundRequest @request_id, @actor_id, @decision, @rejection_reason, @retry_failed;
END;
