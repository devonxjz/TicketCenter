
/* Trigger: trg_AuditLog_AppendOnly */
CREATE   TRIGGER dbo.trg_AuditLog_AppendOnly ON dbo.tc_audit_logs
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM deleted) THROW 51110, 'Audit log is append-only', 1;
END;
