
CREATE   PROCEDURE dbo.usp_OrderLockCoupons @old_id uniqueidentifier=NULL,@new_id uniqueidentifier=NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF @@TRANCOUNT=0 THROW 51410,'Transaction required',1;
    DECLARE @id uniqueidentifier,@dummy int;
    DECLARE coupon_locks CURSOR LOCAL FAST_FORWARD FOR SELECT id FROM dbo.tc_coupons WHERE id IN(@old_id,@new_id) ORDER BY id;
    OPEN coupon_locks; FETCH NEXT FROM coupon_locks INTO @id;
    WHILE @@FETCH_STATUS=0 BEGIN
        SELECT @dummy=1 FROM dbo.tc_coupons WITH(UPDLOCK,HOLDLOCK) WHERE id=@id;
        FETCH NEXT FROM coupon_locks INTO @id;
    END;
    CLOSE coupon_locks; DEALLOCATE coupon_locks;
END;
