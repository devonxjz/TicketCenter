
CREATE   VIEW dbo.v_refund_tickets AS
SELECT rt.refund_id,t.id ticket_id,t.ticket_code,i.zone_name_snapshot,
       i.seat_label_snapshot,t.paid_amount,t.status
FROM dbo.tc_refund_tickets rt JOIN dbo.tc_tickets t ON t.id=rt.ticket_id
JOIN dbo.tc_order_items i ON i.id=t.order_item_id;
