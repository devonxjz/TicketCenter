
CREATE   PROCEDURE dbo.usp_RecalculateSettlement @event_id uniqueidentifier,@actor_id uniqueidentifier,@auth_version int=NULL,@emit_result bit=1
AS BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY BEGIN TRANSACTION;
 EXEC dbo.usp_VuongRequireAdmin @actor_id,@auth_version;
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@event_id) THROW 52704,'EVENT_NOT_FOUND',1;
 DECLARE @settlement_id uniqueidentifier,@status varchar(20),@lock_count bigint;
 SELECT @settlement_id=id,@status=status FROM dbo.tc_settlements WITH(UPDLOCK,HOLDLOCK) WHERE event_id=@event_id;
 IF @status IS NOT NULL AND @status<>'DRAFT' THROW 52709,'SETTLEMENT_NOT_DRAFT',1;
 -- Lock relevant ranges so ordinary owner writes cannot race confirmation, even if their SP omits the event lock.
 SELECT @lock_count=COUNT_BIG(*) FROM dbo.vw_VuongOrders WITH(UPDLOCK,HOLDLOCK) WHERE event_id=@event_id;
 SELECT @lock_count=COUNT_BIG(*) FROM dbo.vw_VuongPayments p WITH(UPDLOCK,HOLDLOCK) JOIN dbo.vw_VuongOrders o ON o.id=p.order_id WHERE o.event_id=@event_id;
 SELECT @lock_count=COUNT_BIG(*) FROM dbo.vw_VuongRefunds r WITH(UPDLOCK,HOLDLOCK) JOIN dbo.vw_VuongOrders o ON o.id=r.order_id WHERE o.event_id=@event_id;
 SELECT @lock_count=COUNT_BIG(*) FROM dbo.tc_refund_transfer_logs l WITH(UPDLOCK,HOLDLOCK) JOIN dbo.vw_VuongRefunds r ON r.id=l.refund_id JOIN dbo.vw_VuongOrders o ON o.id=r.order_id WHERE o.event_id=@event_id;
 IF EXISTS(SELECT 1 FROM dbo.vw_OrderFinancialSummary WHERE event_id=@event_id AND status='PAID' AND (commission_amount IS NULL OR remaining_amount<0 OR (total_amount>0 AND ticket_revenue=0))) THROW 52702,'INVALID_FINANCIALS',1;
 IF EXISTS(SELECT 1 FROM dbo.vw_OrderFinancialSummary WHERE event_id=@event_id AND status='PAID') BEGIN
 IF @settlement_id IS NULL BEGIN SET @settlement_id=NEWID(); INSERT dbo.tc_settlements(id,event_id,status,gross_revenue,total_refund,total_commission,paid_amount,pending_amount,created_at,updated_at) VALUES(@settlement_id,@event_id,'DRAFT',0,0,0,0,0,SYSUTCDATETIME(),SYSUTCDATETIME()); END;
 DELETE dbo.tc_settlement_order_snapshots WHERE settlement_id=@settlement_id;
 INSERT dbo.tc_settlement_order_snapshots(id,settlement_id,order_id,gross_amount,refund_amount,commission_amount,net_amount,created_at,updated_at)
 SELECT NEWID(),@settlement_id,order_id,ticket_revenue,ticket_refund,commission_amount,net_amount,SYSUTCDATETIME(),SYSUTCDATETIME() FROM dbo.vw_OrderFinancialSummary WHERE event_id=@event_id AND status='PAID';
 EXEC dbo.usp_VuongUpdateSettlementTotals @settlement_id;
 INSERT dbo.vw_VuongAuditLogs(id,created_at,updated_at,actor_id,action,entity_type,entity_id,metadata_json) VALUES(NEWID(),SYSUTCDATETIME(),SYSUTCDATETIME(),@actor_id,'SETTLEMENT_RECALCULATED','Settlement',CONVERT(varchar(36),@settlement_id),(SELECT @event_id eventId FOR JSON PATH,WITHOUT_ARRAY_WRAPPER));
 END ELSE IF @settlement_id IS NOT NULL THROW 52709,'SETTLEMENT_SOURCE_MISSING',1;
 IF @emit_result=1 BEGIN
 IF @settlement_id IS NULL SELECT CAST(NULL AS uniqueidentifier) settlement_id,@event_id event_id,CAST('DRAFT' AS varchar(20)) status,CAST(0 AS decimal(19,0)) gross_revenue,CAST(0 AS decimal(19,0)) total_refund,CAST(0 AS decimal(19,0)) total_commission,CAST(0 AS decimal(19,0)) net_payable,CAST(0 AS decimal(19,0)) paid_amount,CAST(0 AS decimal(19,0)) pending_amount,CAST(0 AS decimal(19,0)) available_to_pay,CAST(NULL AS datetime2(3)) confirmed_at,CAST(0 AS bit) is_replay;
 ELSE SELECT settlement_id,event_id,status,gross_revenue,total_refund,total_commission,net_payable,paid_amount,pending_amount,available_to_pay,confirmed_at,CAST(0 AS bit) is_replay FROM dbo.vw_SettlementPayoutBalance WHERE settlement_id=@settlement_id;
 END;
 COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
