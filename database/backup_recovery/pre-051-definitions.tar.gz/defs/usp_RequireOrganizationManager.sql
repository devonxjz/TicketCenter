
CREATE   PROCEDURE dbo.usp_RequireOrganizationManager @actor_id uniqueidentifier,@organization_id uniqueidentifier
AS BEGIN SET NOCOUNT ON;
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_organization_memberships m JOIN dbo.tc_users u ON u.id=m.user_id
 WHERE m.user_id=@actor_id AND m.organization_id=@organization_id AND m.role='MANAGER' AND m.active=1 AND u.status='ACTIVE')
 THROW 51810,'Active manager of this organization required',1;
END;
