
CREATE   PROCEDURE dbo.usp_ConfirmSettlement @settlement_id uniqueidentifier,@actor_id uniqueidentifier,@auth_version int=NULL
AS BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY BEGIN TRANSACTION;
 EXEC dbo.usp_VuongRequireAdmin @actor_id,@auth_version;
 DECLARE @event_id uniqueidentifier,@status varchar(20),@replay bit=0,@lock_count bigint;
 SELECT @event_id=event_id FROM dbo.tc_settlements WHERE id=@settlement_id;
 IF @event_id IS NULL THROW 52704,'SETTLEMENT_NOT_FOUND',1;
 SELECT @lock_count=COUNT_BIG(*) FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@event_id;
 SELECT @status=status FROM dbo.tc_settlements WITH(UPDLOCK,HOLDLOCK) WHERE id=@settlement_id;
 IF @status IN('CONFIRMED','PAID') SET @replay=1;
 ELSE BEGIN
 EXEC dbo.usp_RecalculateSettlement @event_id,@actor_id,@auth_version,0;
 SELECT @lock_count=COUNT_BIG(*) FROM dbo.tc_outbox WITH(UPDLOCK,HOLDLOCK) WHERE event_type='EVENT_CANCELLED';
 IF EXISTS(SELECT 1 FROM dbo.fn_GetSettlementBlockers(@event_id,SYSUTCDATETIME())) THROW 52709,'SETTLEMENT_BLOCKED',1;
 UPDATE dbo.tc_settlements SET status=CASE WHEN net_payable=0 THEN 'PAID' ELSE 'CONFIRMED' END,confirmed_at=SYSUTCDATETIME(),updated_at=SYSUTCDATETIME() WHERE id=@settlement_id;
 INSERT dbo.vw_VuongAuditLogs(id,created_at,updated_at,actor_id,action,entity_type,entity_id,metadata_json) VALUES(NEWID(),SYSUTCDATETIME(),SYSUTCDATETIME(),@actor_id,'SETTLEMENT_CONFIRMED','Settlement',CONVERT(varchar(36),@settlement_id),(SELECT @event_id eventId FOR JSON PATH,WITHOUT_ARRAY_WRAPPER));
 END;
 SELECT settlement_id,event_id,status,gross_revenue,total_refund,total_commission,net_payable,paid_amount,pending_amount,available_to_pay,confirmed_at,@replay is_replay FROM dbo.vw_SettlementPayoutBalance WHERE settlement_id=@settlement_id;
 COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
