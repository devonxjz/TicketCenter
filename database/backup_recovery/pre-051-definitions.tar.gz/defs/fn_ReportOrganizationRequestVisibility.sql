
CREATE   FUNCTION dbo.fn_ReportOrganizationRequestVisibility(@applicant uniqueidentifier)
RETURNS TABLE WITH SCHEMABINDING AS RETURN
 SELECT 1 permitted WHERE USER_NAME()=N'dbo' OR COALESCE(IS_MEMBER('db_owner'),0)=1
 OR COALESCE(IS_ROLEMEMBER('tc_auth'),0)=1 OR COALESCE(IS_ROLEMEMBER('tc_platform_admin'),0)=1
 OR @applicant=TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'actor_id'));
