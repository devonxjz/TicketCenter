
CREATE   PROCEDURE dbo.usp_ReadHoldOptions @actor_id uniqueidentifier,@auth_version int,@event_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON; SET LOCK_TIMEOUT 10000;
    IF @@TRANCOUNT<>0 THROW 51310,'Facade requires autocommit',1;
    EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @dummy int;
        SELECT @dummy=1 FROM dbo.tc_events WITH(HOLDLOCK) WHERE id=@event_id;
        SELECT @dummy=1 FROM dbo.tc_users WITH(HOLDLOCK) WHERE id=@actor_id;
        EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
        DECLARE @now datetime2(3)=SYSUTCDATETIME(),@payload nvarchar(max);
        IF NOT EXISTS(SELECT 1 FROM dbo.tc_events e JOIN dbo.tc_organizations o WITH(HOLDLOCK) ON o.id=e.organization_id
            WHERE e.id=@event_id AND e.status='PUBLISHED' AND o.status='APPROVED' AND @now>=e.sale_start AND @now<e.sale_end)
            THROW 51304,'Event not found or not on sale',1;
        SELECT @payload=(SELECT LOWER(CONVERT(char(36),e.id)) eventId,e.title,CONVERT(varchar(23),e.sale_end,126)+'Z' saleEnd,
            CONVERT(varchar(23),@now,126)+'Z' serverTime,JSON_QUERY(COALESCE((SELECT LOWER(CONVERT(char(36),z.id)) id,z.name,z.type,
                CONVERT(varchar(30),z.price) unitPrice,CASE WHEN z.type='STANDING' THEN z.capacity-z.held_quantity-z.sold_quantity END availableStanding,
                JSON_QUERY(COALESCE((SELECT LOWER(CONVERT(char(36),s.id)) id,s.label FROM dbo.tc_seats s
                    WHERE s.zone_id=z.id AND s.status='AVAILABLE' ORDER BY s.row_name,s.seat_number FOR JSON PATH),N'[]')) availableSeats
                FROM dbo.tc_zones z WHERE z.event_id=e.id ORDER BY z.id FOR JSON PATH,INCLUDE_NULL_VALUES),N'[]')) zones
            FROM dbo.tc_events e WHERE e.id=@event_id FOR JSON PATH,WITHOUT_ARRAY_WRAPPER);
        COMMIT;
        SELECT @payload response_payload;
    END TRY BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        THROW;
    END CATCH;
END;
