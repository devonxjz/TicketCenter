
CREATE   VIEW dbo.v_refundable_orders AS
SELECT o.id order_id,o.order_code,o.user_id owner_id,o.status order_status,e.title event_name,
       e.status event_status,e.start_time
FROM dbo.tc_orders o JOIN dbo.tc_events e ON e.id=o.event_id;
