
CREATE   PROCEDURE dbo.sp_refund_reject @refund_id uniqueidentifier,@admin_user_id uniqueidentifier,
 @reject_reason nvarchar(1000),@idempotency_key uniqueidentifier,@expected_auth_version int
AS BEGIN SET NOCOUNT ON;
 EXEC dbo.sp_admin_refund_decide @refund_id,@admin_user_id,@expected_auth_version,'REJECT',NULL,@reject_reason,@idempotency_key;
END;
