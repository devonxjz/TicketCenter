
CREATE   PROCEDURE dbo.usp_EventReceipt
 @actor_id uniqueidentifier,@actor_version int,@scope varchar(30),@idempotency_key varchar(128),@request_hash char(64)
AS
BEGIN
 SET NOCOUNT ON;
 DECLARE @organization_id uniqueidentifier,@event_id uniqueidentifier=NULL,@admin bit=CASE WHEN @scope='EVENT_REVIEW' THEN 1 ELSE 0 END;
 SELECT @organization_id=organization_id FROM dbo.tc_event_command_receipts
  WHERE actor_id=@actor_id AND scope=@scope AND idempotency_key=@idempotency_key;
 EXEC dbo.usp_EventAuthorize @actor_id,@actor_version,@admin,@organization_id OUTPUT,@event_id OUTPUT;
 IF EXISTS(SELECT 1 FROM dbo.tc_event_command_receipts WHERE actor_id=@actor_id AND scope=@scope
  AND idempotency_key=@idempotency_key AND request_hash<>@request_hash) THROW 52009,'Idempotency payload conflict',1;
 SELECT status_code,response_json,organization_id,event_id,cleanup_json FROM dbo.tc_event_command_receipts
  WHERE actor_id=@actor_id AND scope=@scope AND idempotency_key=@idempotency_key;
END;
