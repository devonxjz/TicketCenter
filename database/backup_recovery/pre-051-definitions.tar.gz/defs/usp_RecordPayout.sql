
CREATE   PROCEDURE dbo.usp_RecordPayout
 @settlement_id uniqueidentifier,@payout_id uniqueidentifier,@actor_id uniqueidentifier,@amount decimal(19,0),@reference nvarchar(200)=NULL,@verified_result varchar(20)=NULL,@fingerprint varbinary(32)=NULL,@auth_version int=NULL
AS BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY BEGIN TRANSACTION;
 EXEC dbo.usp_VuongRequireAdmin @actor_id,@auth_version;
 IF @payout_id IS NULL OR @amount IS NULL OR @amount<=0 OR (@verified_result IS NOT NULL AND @verified_result NOT IN('SUCCEEDED','FAILED','UNKNOWN')) THROW 52702,'PAYOUT_INVALID',1;
 IF @fingerprint IS NULL SET @fingerprint=HASHBYTES('SHA2_256',CONCAT(CONVERT(varchar(36),@settlement_id),'|',@amount,'|',COALESCE(@reference,'')));
 IF DATALENGTH(@fingerprint)<>32 THROW 52702,'PAYOUT_INVALID',1;
 DECLARE @old varchar(30),@replay bit=0,@state varchar(20),@net decimal(19,0),@paid decimal(19,0),@pending decimal(19,0);
 SELECT @state=status,@net=net_payable,@paid=paid_amount,@pending=pending_amount FROM dbo.tc_settlements WITH(UPDLOCK,HOLDLOCK) WHERE id=@settlement_id;
 IF @state IS NULL THROW 52704,'SETTLEMENT_NOT_FOUND',1;
 SELECT @old=status FROM dbo.tc_settlement_transfer_logs WITH(UPDLOCK,HOLDLOCK) WHERE id=@payout_id;
 IF @old IS NOT NULL BEGIN
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_settlement_transfer_logs WHERE id=@payout_id AND settlement_id=@settlement_id AND amount=@amount AND request_fingerprint=@fingerprint AND (@verified_result IS NOT NULL OR requested_reference=@reference OR (requested_reference IS NULL AND @reference IS NULL))) THROW 52709,'PAYOUT_TERMS_CONFLICT',1;
 IF @old=@verified_result AND NOT EXISTS(SELECT 1 FROM dbo.tc_settlement_transfer_logs WHERE id=@payout_id AND (provider_reference=@reference OR (provider_reference IS NULL AND @reference IS NULL))) THROW 52709,'PAYOUT_RESULT_CONFLICT',1;
 IF @verified_result IS NULL OR (@old=@verified_result) OR (@verified_result='UNKNOWN' AND @old='PENDING' AND EXISTS(SELECT 1 FROM dbo.tc_settlement_transfer_logs WHERE id=@payout_id AND verification_state='UNKNOWN')) SET @replay=1;
 ELSE IF @old IN('SUCCEEDED','FAILED') THROW 52709,'PAYOUT_RESULT_CONFLICT',1;
 ELSE BEGIN
 UPDATE dbo.tc_settlement_transfer_logs SET status=CASE WHEN @verified_result='UNKNOWN' THEN 'PENDING' ELSE @verified_result END,result=CASE WHEN @verified_result='UNKNOWN' THEN 'PENDING' ELSE @verified_result END,
 verification_state=@verified_result,provider_reference=CASE WHEN @verified_result='UNKNOWN' THEN provider_reference ELSE @reference END,processed_at=CASE WHEN @verified_result='UNKNOWN' THEN NULL ELSE SYSUTCDATETIME() END WHERE id=@payout_id;
 INSERT dbo.vw_VuongAuditLogs(id,created_at,updated_at,actor_id,action,entity_type,entity_id,metadata_json) VALUES(NEWID(),SYSUTCDATETIME(),SYSUTCDATETIME(),@actor_id,'PAYOUT_RESULT','SettlementTransferLog',CONVERT(varchar(36),@payout_id),(SELECT @settlement_id settlementId,@amount amount,@verified_result result FOR JSON PATH,WITHOUT_ARRAY_WRAPPER));
 END;
 END ELSE BEGIN
 IF @verified_result IS NOT NULL THROW 52709,'PAYOUT_RESERVATION_REQUIRED',1;
 IF @state<>'CONFIRMED' THROW 52709,'SETTLEMENT_NOT_CONFIRMED',1;
 -- PENDING can mean the provider already transferred money but its result was not committed.
 -- Reconcile/replay that same ID before allowing a second provider attempt.
 IF EXISTS(SELECT 1 FROM dbo.tc_settlement_transfer_logs WHERE settlement_id=@settlement_id AND status='PENDING') THROW 52709,'PAYOUT_RECONCILIATION_REQUIRED',1;
 IF @net-@paid-@pending<@amount THROW 52709,'PAYOUT_EXCEEDS_BALANCE',1;
 INSERT dbo.tc_settlement_transfer_logs(id,settlement_id,amount,status,result,request_fingerprint,requested_reference,verification_state,created_at)
 VALUES(@payout_id,@settlement_id,@amount,'PENDING','PENDING',@fingerprint,@reference,'PENDING',SYSUTCDATETIME());
 INSERT dbo.vw_VuongAuditLogs(id,created_at,updated_at,actor_id,action,entity_type,entity_id,metadata_json) VALUES(NEWID(),SYSUTCDATETIME(),SYSUTCDATETIME(),@actor_id,'PAYOUT_RESERVED','SettlementTransferLog',CONVERT(varchar(36),@payout_id),(SELECT @settlement_id settlementId,@amount amount FOR JSON PATH,WITHOUT_ARRAY_WRAPPER));
 END;
 SELECT l.id payout_id,l.settlement_id,l.amount,l.status,l.verification_state,l.provider_reference,l.processed_at,@replay is_replay,
 s.status settlement_status,s.net_payable,s.paid_amount,s.pending_amount,CAST(s.net_payable-s.paid_amount-s.pending_amount AS decimal(19,0)) available_to_pay
 FROM dbo.tc_settlement_transfer_logs l JOIN dbo.tc_settlements s ON s.id=l.settlement_id WHERE l.id=@payout_id;
 COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
