
CREATE   PROCEDURE dbo.usp_HoldSnapshot
    @hold_id uniqueidentifier,@outcome varchar(20),@payload nvarchar(max) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @payload=(SELECT LOWER(CONVERT(char(36),h.id)) id, LOWER(CONVERT(char(36),h.event_id)) eventId,e.title eventTitle,
        CONVERT(varchar(23),h.created_at,126)+'Z' createdAt,CONVERT(varchar(23),h.expires_at,126)+'Z' expiresAt,
        @outcome outcome,JSON_QUERY((SELECT LOWER(CONVERT(char(36),i.zone_id)) zoneId,
            LOWER(CONVERT(char(36),i.seat_id)) seatId,z.name zoneName,s.label seatLabel,i.quantity,CONVERT(varchar(30),i.unit_price) unitPrice
            FROM dbo.tc_ticket_hold_items i JOIN dbo.tc_zones z ON z.id=i.zone_id LEFT JOIN dbo.tc_seats s ON s.id=i.seat_id WHERE i.hold_id=h.id ORDER BY i.zone_id,i.seat_id
            FOR JSON PATH,INCLUDE_NULL_VALUES)) items
        FROM dbo.tc_ticket_holds h JOIN dbo.tc_events e ON e.id=h.event_id WHERE h.id=@hold_id FOR JSON PATH,WITHOUT_ARRAY_WRAPPER);
END;
