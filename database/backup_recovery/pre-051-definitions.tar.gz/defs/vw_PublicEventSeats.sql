
CREATE   VIEW dbo.vw_PublicEventSeats AS
 SELECT s.id,s.zone_id,s.row_name,s.seat_number,s.label,s.status
 FROM dbo.tc_seats s JOIN dbo.tc_zones z ON z.id=s.zone_id
 JOIN dbo.tc_events e ON e.id=z.event_id WHERE e.status='PUBLISHED';
