CREATE   VIEW dbo.vw_RefundWorkerCandidates AS
 SELECT l.id attempt_id,l.refund_id,o.amount,l.provider_reference,
 CASE WHEN d.attempt_id IS NULL AND l.status='PENDING' AND l.provider_reference IS NULL THEN 'EXECUTE' ELSE 'QUERY' END work_kind,
 l.created_at
 FROM dbo.tc_refund_transfer_logs l
 JOIN dbo.tc_refund_obligations o ON o.id=l.refund_id AND o.current_attempt_id=l.id
 LEFT JOIN dbo.tc_refund_dispatches d ON d.attempt_id=l.id
 WHERE l.status IN('PENDING','UNKNOWN') AND o.amount>0
 AND (d.lease_until IS NULL OR d.lease_until<=SYSUTCDATETIME())
 AND (d.attempt_id IS NULL OR d.next_query_at<=SYSUTCDATETIME());
