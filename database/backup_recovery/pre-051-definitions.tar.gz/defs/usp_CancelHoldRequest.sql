
CREATE   PROCEDURE dbo.usp_CancelHoldRequest
    @actor_id uniqueidentifier,@auth_version int,@request_key uniqueidentifier,@fingerprint varchar(64),@hold_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.usp_HoldMutation @actor_id,@auth_version,@request_key,@fingerprint,'CANCEL',@hold_id=@hold_id;
END;
