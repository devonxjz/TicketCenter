
/* Trigger: trg_Zone_ProtectPublishedLayout */
CREATE   TRIGGER dbo.trg_Zone_ProtectPublishedLayout ON dbo.tc_zones
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted i LEFT JOIN deleted d ON d.id = i.id
        JOIN dbo.tc_events e ON e.id = i.event_id
        WHERE e.status IN ('PUBLISHED', 'CANCELLED')
          AND (d.id IS NULL OR d.event_id <> i.event_id OR d.name <> i.name OR d.type <> i.type
               OR ISNULL(d.capacity, -1) <> ISNULL(i.capacity, -1))
    ) OR EXISTS (
        SELECT 1 FROM deleted d LEFT JOIN inserted i ON i.id = d.id
        JOIN dbo.tc_events e ON e.id = d.event_id
        WHERE e.status IN ('PUBLISHED', 'CANCELLED')
          AND (i.id IS NULL OR i.event_id <> d.event_id)
    ) THROW 51101, 'Published event zone layout is immutable', 1;
END;
