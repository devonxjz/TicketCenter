
CREATE   VIEW dbo.vw_JpaOrganizationRequests AS
SELECT id,organization_id,applicant_id requester_id,requested_at submitted_at,decided_at resolved_at,
 rejection_reason,requested_at created_at,COALESCE(decided_at,requested_at) updated_at
FROM dbo.tc_organization_requests;
