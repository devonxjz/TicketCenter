
/* View: vw_CouponUsage */
CREATE   VIEW dbo.vw_CouponUsage
AS
WITH u AS (
    SELECT coupon_id,
           SUM(CASE WHEN status = 'RESERVED' THEN 1 ELSE 0 END) reserved_uses,
           SUM(CASE WHEN status = 'CONSUMED' THEN 1 ELSE 0 END) consumed_uses,
           SUM(CASE WHEN status = 'RELEASED' THEN 1 ELSE 0 END) released_uses
    FROM dbo.tc_coupon_redemptions GROUP BY coupon_id
)
SELECT c.id coupon_id, c.organization_id, c.code, c.active, c.valid_from, c.valid_to, c.max_uses,
       COALESCE(u.reserved_uses, 0) reserved_uses, COALESCE(u.consumed_uses, 0) consumed_uses,
       COALESCE(u.released_uses, 0) released_uses,
       CASE WHEN c.max_uses > COALESCE(u.reserved_uses, 0) + COALESCE(u.consumed_uses, 0)
            THEN c.max_uses - COALESCE(u.reserved_uses, 0) - COALESCE(u.consumed_uses, 0) ELSE 0 END available_uses
FROM dbo.tc_coupons c LEFT JOIN u ON u.coupon_id = c.id;
