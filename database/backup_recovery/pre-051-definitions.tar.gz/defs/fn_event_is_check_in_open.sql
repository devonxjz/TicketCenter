
/* Function: fn_event_is_check_in_open */
CREATE   FUNCTION dbo.fn_event_is_check_in_open
(@event_id uniqueidentifier,@now datetime2(7))
RETURNS bit
AS
BEGIN
    DECLARE @open bit=0;
    SELECT @open=1 FROM dbo.tc_events
    WHERE id=@event_id AND status='PUBLISHED'
      AND @now>=DATEADD(minute,-60,start_time) AND @now<end_time;
    RETURN @open;
END;
