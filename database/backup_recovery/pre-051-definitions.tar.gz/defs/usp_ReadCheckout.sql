
CREATE   PROCEDURE dbo.usp_ReadCheckout @actor_id uniqueidentifier,@auth_version int,@hold_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF @@TRANCOUNT<>0 THROW 51410,'Facade owns transaction',1;
    BEGIN TRANSACTION;
    BEGIN TRY
        DECLARE @event_id uniqueidentifier,@owner_id uniqueidentifier,@order_id uniqueidentifier,@now datetime2(3),@order nvarchar(max),@payload nvarchar(max);
        SELECT @event_id=event_id,@owner_id=user_id FROM dbo.tc_ticket_holds WHERE id=@hold_id;
        EXEC dbo.usp_HoldLockSelection @actor_id,@event_id,N'[]',@hold_id,@include_active=0;
        EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
        IF @owner_id IS NOT NULL AND @owner_id<>@actor_id THROW 51403,'Hold owner required',1;
        IF @owner_id IS NULL THROW 51400,'Hold not found',1;
        SELECT @order_id=id FROM dbo.tc_orders WHERE hold_id=@hold_id;
        IF EXISTS(SELECT 1 FROM dbo.tc_orders WHERE id=@order_id AND user_id<>@actor_id) THROW 51403,'Order owner required',1;
        DECLARE @coupon uniqueidentifier,@payment_dummy int;
        SELECT @coupon=coupon_id FROM dbo.tc_orders WHERE id=@order_id;
        EXEC dbo.usp_OrderLockCoupons @coupon,NULL;
        SELECT @payment_dummy=1 FROM dbo.tc_payments WITH(UPDLOCK,HOLDLOCK) WHERE order_id=@order_id;
        SELECT @now=SYSUTCDATETIME();
        IF @order_id IS NOT NULL EXEC dbo.usp_OrderSnapshot @order_id,1,@now,@order OUTPUT;
        SELECT @payload=(SELECT CONVERT(varchar(23),@now,126)+'Z' serverTime,JSON_QUERY(@order) [order] FOR JSON PATH,WITHOUT_ARRAY_WRAPPER,INCLUDE_NULL_VALUES);
        COMMIT; SELECT @payload response_payload;
    END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
