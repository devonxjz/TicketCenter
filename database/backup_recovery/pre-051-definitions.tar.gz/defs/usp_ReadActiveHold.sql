
CREATE   PROCEDURE dbo.usp_ReadActiveHold @actor_id uniqueidentifier,@auth_version int
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON; SET LOCK_TIMEOUT 10000;
    IF @@TRANCOUNT<>0 THROW 51310,'Facade requires autocommit',1;
    EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
    BEGIN TRY
        BEGIN TRANSACTION;
        EXEC dbo.usp_HoldLockSelection @actor_id,NULL,N'[]';
        EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
        DECLARE @hold uniqueidentifier,@payload nvarchar(max),@now datetime2(3)=SYSUTCDATETIME();
        SELECT @hold=h.id FROM dbo.tc_ticket_holds h JOIN dbo.tc_events e ON e.id=h.event_id
            JOIN dbo.tc_organizations o WITH(HOLDLOCK) ON o.id=e.organization_id
            WHERE h.user_id=@actor_id AND h.status='ACTIVE' AND h.expires_at>@now AND e.status='PUBLISHED' AND o.status='APPROVED';
        IF @hold IS NOT NULL BEGIN
            EXEC dbo.usp_HoldSnapshot @hold,'ACTIVE',@payload OUTPUT;
            SET @payload=JSON_MODIFY(JSON_MODIFY(@payload,'$.outcome',NULL),'$.status','ACTIVE');
        END;
        SELECT @payload=(SELECT CONVERT(varchar(23),@now,126)+'Z' serverTime,JSON_QUERY(@payload) hold
            FOR JSON PATH,WITHOUT_ARRAY_WRAPPER,INCLUDE_NULL_VALUES);
        COMMIT;
        SELECT @payload response_payload;
    END TRY BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        THROW;
    END CATCH;
END;
