
CREATE   VIEW dbo.vw_OrderTicketQuantity AS
 SELECT i.order_id,COALESCE(SUM(i.quantity),0) quantity
 FROM dbo.tc_order_items i JOIN dbo.tc_orders o ON o.id=i.order_id GROUP BY i.order_id;
