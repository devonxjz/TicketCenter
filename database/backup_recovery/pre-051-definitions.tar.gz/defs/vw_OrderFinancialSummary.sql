
CREATE   VIEW dbo.vw_OrderFinancialSummary AS
WITH financial AS (
SELECT o.id order_id,o.buyer_id owner_id,o.event_id,e.organization_id,o.status,o.paid_at,o.subtotal_amount,o.discount_amount,o.total_amount,
 CAST(CASE WHEN o.status='PAID' AND (o.total_amount=0 OR (p.id IS NOT NULL AND p.status='CAPTURED' AND p.order_id=o.id AND p.amount=o.total_amount)) THEN o.total_amount ELSE 0 END AS decimal(19,0)) ticket_revenue,
 CAST(CASE WHEN o.status='PAID' THEN COALESCE(r.ticket_refund,0) ELSE 0 END AS decimal(19,0)) ticket_refund,
 CAST(CASE WHEN o.status='PAID' AND (o.total_amount=0 OR (p.id IS NOT NULL AND p.status='CAPTURED' AND p.order_id=o.id AND p.amount=o.total_amount)) THEN o.total_amount-COALESCE(r.ticket_refund,0) ELSE 0 END AS decimal(19,0)) remaining_amount,
 dbo.fn_CalculateCommission(CASE WHEN o.status='PAID' AND (o.total_amount=0 OR (p.status='CAPTURED' AND p.order_id=o.id AND p.amount=o.total_amount)) THEN o.total_amount-COALESCE(r.ticket_refund,0) ELSE 0 END,c.rate_percent,c.fixed_fee) commission_amount,
 CAST(CASE WHEN o.status='PAID' AND (o.total_amount=0 OR (p.status='CAPTURED' AND p.order_id=o.id AND p.amount=o.total_amount)) THEN o.total_amount-COALESCE(r.ticket_refund,0) ELSE 0 END-
 dbo.fn_CalculateCommission(CASE WHEN o.status='PAID' AND (o.total_amount=0 OR (p.status='CAPTURED' AND p.order_id=o.id AND p.amount=o.total_amount)) THEN o.total_amount-COALESCE(r.ticket_refund,0) ELSE 0 END,c.rate_percent,c.fixed_fee) AS decimal(19,0)) net_amount,
 CAST(COALESCE(pc.amount,0) AS decimal(19,0)) compensation_captured,CAST(COALESCE(r.compensation_refund,0) AS decimal(19,0)) compensation_refund
FROM dbo.vw_VuongOrders o JOIN dbo.tc_events e ON e.id=o.event_id LEFT JOIN dbo.vw_VuongPayments p ON p.id=o.accepted_payment_id
LEFT JOIN dbo.tc_commission_rules c ON c.id=e.commission_rule_id
OUTER APPLY(SELECT SUM(CASE WHEN purpose='CUSTOMER_REFUND' THEN amount ELSE 0 END) ticket_refund,SUM(CASE WHEN purpose='PAYMENT_COMPENSATION' THEN amount ELSE 0 END) compensation_refund FROM dbo.vw_VuongRefunds WHERE order_id=o.id AND status='COMPLETED') r
OUTER APPLY(SELECT SUM(amount) amount FROM dbo.vw_VuongPayments WHERE order_id=o.id AND status='CAPTURED' AND (o.accepted_payment_id IS NULL OR id<>o.accepted_payment_id)) pc
)
/* Preserve retained owner column names with the approved accepted-payment and
   obligation semantics. This does not authorize the old mutation procedures. */
SELECT f.*,ticket_revenue ticket_gross_amount,ticket_refund ticket_refund_amount,
 ticket_refund successful_ticket_refund_amount,remaining_amount remaining_ticket_amount,
 compensation_refund compensation_refund_amount,ticket_revenue+compensation_captured captured_amount,
 COALESCE(t.issued_ticket_amount,0) issued_ticket_amount
FROM financial f OUTER APPLY(SELECT SUM(t.paid_amount) issued_ticket_amount FROM dbo.tc_tickets t
 JOIN dbo.tc_order_items i ON i.id=t.order_item_id WHERE i.order_id=f.order_id) t;
