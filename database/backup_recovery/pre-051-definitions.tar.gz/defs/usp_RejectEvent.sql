
CREATE   PROCEDURE dbo.usp_RejectEvent @event_id uniqueidentifier,@actor_id uniqueidentifier,@reason nvarchar(1000)
AS BEGIN SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY BEGIN TRANSACTION;
 IF NULLIF(LTRIM(RTRIM(@reason)),N'') IS NULL THROW 51814,'Rejection reason required',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_user_platform_roles pr JOIN dbo.tc_users u ON u.id=pr.user_id WHERE pr.user_id=@actor_id AND pr.role='ADMIN' AND u.status='ACTIVE') THROW 51815,'Active administrator required',1;
 UPDATE dbo.tc_events SET status='REJECTED',version=version+1 WHERE id=@event_id AND status='PENDING_APPROVAL';
 IF @@ROWCOUNT<>1 THROW 51812,'Event is not awaiting approval',1;
 INSERT dbo.tc_audit_logs(actor_id,action,aggregate_type,aggregate_id,detail) VALUES(@actor_id,'EVENT_REJECTED','EVENT',@event_id,@reason);
 COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
