
/* View: vw_OrganizationMembers */
CREATE   VIEW dbo.vw_OrganizationMembers
AS
SELECT m.id membership_id, m.organization_id, m.user_id, u.email, u.full_name,
       m.role, m.active, u.status user_status, m.joined_at
FROM dbo.tc_organization_memberships m JOIN dbo.tc_users u ON u.id = m.user_id;
