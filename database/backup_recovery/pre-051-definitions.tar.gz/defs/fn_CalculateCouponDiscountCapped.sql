
CREATE   FUNCTION dbo.fn_CalculateCouponDiscountCapped(@subtotal decimal(19,0),@coupon_id uniqueidentifier)
RETURNS decimal(19,0) AS BEGIN
 DECLARE @discount decimal(19,0),@cap decimal(19,0);
 SELECT @discount=dbo.fn_CalculateCouponDiscount(@subtotal,discount_type,percentage_value,fixed_amount),@cap=max_discount_amount FROM dbo.tc_coupons WHERE id=@coupon_id;
 RETURN CASE WHEN @cap IS NOT NULL AND @cap<@discount THEN @cap ELSE @discount END;
END;
