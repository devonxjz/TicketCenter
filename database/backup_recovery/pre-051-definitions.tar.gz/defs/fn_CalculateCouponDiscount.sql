
/* Function: fn_CalculateCouponDiscount */
CREATE   FUNCTION dbo.fn_CalculateCouponDiscount(
    @subtotal decimal(19,0), @discount_type varchar(30),
    @percentage decimal(5,2), @fixed_amount decimal(19,0)
)
RETURNS decimal(19,0)
AS
BEGIN
    IF @subtotal IS NULL OR @subtotal < 0 RETURN NULL;
    DECLARE @cap decimal(19,0) = FLOOR(@subtotal * 0.30);
    IF @discount_type = 'PERCENTAGE' AND @percentage > 0 AND @percentage <= 30 AND @fixed_amount IS NULL
        RETURN FLOOR(@subtotal * @percentage / 100.0);
    IF @discount_type = 'FIXED_AMOUNT' AND @fixed_amount > 0 AND @percentage IS NULL
        RETURN CASE WHEN @fixed_amount < @cap THEN @fixed_amount ELSE @cap END;
    RETURN NULL;
END;
