
CREATE   PROCEDURE dbo.usp_AssertOrderAccess
    @order_id uniqueidentifier
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @session_actor uniqueidentifier = TRY_CONVERT(uniqueidentifier, SESSION_CONTEXT(N'actor_id'));
    IF @session_actor IS NULL
        THROW 51403, 'A current verified owner is required.', 1;

    DECLARE @owner_id uniqueidentifier;
    SELECT @owner_id = user_id FROM dbo.tc_orders WHERE id = @order_id;
    IF @owner_id IS NULL
        THROW 51404, 'Order was not found.', 1;
    IF @owner_id <> @session_actor
        THROW 51403, 'A current verified owner is required.', 1;
END;
