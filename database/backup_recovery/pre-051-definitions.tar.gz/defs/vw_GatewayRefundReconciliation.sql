
CREATE   VIEW dbo.vw_GatewayRefundReconciliation AS
 SELECT id,refund_id,payment_id,observed_status,provider_reference,reason,received_at
 FROM dbo.tc_gateway_refund_receipts WHERE resolution='NEEDS_RECONCILIATION';
