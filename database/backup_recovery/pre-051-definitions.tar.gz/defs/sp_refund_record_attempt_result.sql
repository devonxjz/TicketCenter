CREATE   PROCEDURE dbo.sp_refund_record_attempt_result
 @attempt_id uniqueidentifier,@lease_token uniqueidentifier,@status varchar(20),@provider_reference nvarchar(200)=NULL,@error_message nvarchar(500)=NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 DECLARE @started bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END;
 IF @started=1 BEGIN TRAN; ELSE SAVE TRAN khanh05_result;
 BEGIN TRY
  IF COALESCE(IS_ROLEMEMBER('tc_worker'),0)<>1 AND COALESCE(IS_MEMBER('db_owner'),0)<>1 THROW 53500,'Worker principal required',1;
  IF @status IS NULL OR @status NOT IN('SUCCEEDED','FAILED','UNKNOWN') THROW 53502,'Invalid gateway result',1;
  -- Token check is optimistic; the financial SP owns the established lock order. Ledger is
  -- fenced again after that call. A competing query can only observe the same durable attempt.
  IF NOT EXISTS(SELECT 1 FROM dbo.tc_refund_dispatches WHERE attempt_id=@attempt_id AND lease_token=@lease_token)
   THROW 53503,'Dispatch lease superseded',1;
  IF @status='UNKNOWN' AND NULLIF(@provider_reference,N'') IS NULL BEGIN
   DECLARE @payment uniqueidentifier,@request uniqueidentifier,@order uniqueidentifier,@event uniqueidentifier,@count bigint;
   SELECT @payment=payment_id,@request=refund_id FROM dbo.vw_RefundAttemptLedger WHERE attempt_id=@attempt_id;
   SELECT @order=order_id FROM dbo.tc_payments WHERE id=@payment;
   SELECT @event=event_id FROM dbo.tc_orders WHERE id=@order;
   SELECT @count=COUNT_BIG(*) FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@event;
   SELECT @count=COUNT_BIG(*) FROM dbo.tc_orders WITH(UPDLOCK,HOLDLOCK) WHERE id=@order;
   SELECT @count=COUNT_BIG(*) FROM dbo.tc_payments WITH(UPDLOCK,HOLDLOCK) WHERE id=@payment;
   IF @request IS NOT NULL SELECT @count=COUNT_BIG(*) FROM dbo.tc_refund_obligations WITH(UPDLOCK,HOLDLOCK) WHERE id=@request;
   UPDATE dbo.tc_refund_transfer_logs SET status='UNKNOWN',result='UNKNOWN' WHERE id=@attempt_id AND status IN('PENDING','UNKNOWN');
   IF @@ROWCOUNT=1 UPDATE dbo.tc_refund_obligations SET status='NEEDS_RECONCILIATION',current_attempt_id=@attempt_id,updated_at=SYSUTCDATETIME() WHERE id=@request;
  END ELSE BEGIN
   DECLARE @payload nvarchar(max)=(SELECT @status status,@provider_reference providerReference FOR JSON PATH,WITHOUT_ARRAY_WRAPPER);
   EXEC dbo.usp_ApplyRefundResult @attempt_id,@payload;
  END;
  UPDATE dbo.tc_refund_dispatches SET lease_token=NULL,lease_until=NULL,next_query_at=DATEADD(minute,15,SYSUTCDATETIME()),last_error=@error_message
   WHERE attempt_id=@attempt_id AND lease_token=@lease_token;
  IF @@ROWCOUNT<>1 THROW 53503,'Dispatch lease superseded',1;
  IF @started=1 COMMIT;
 END TRY BEGIN CATCH
  IF @started=1 AND XACT_STATE()<>0 ROLLBACK; ELSE IF @started=0 AND XACT_STATE()=1 ROLLBACK TRAN khanh05_result;
  THROW;
 END CATCH
END;
