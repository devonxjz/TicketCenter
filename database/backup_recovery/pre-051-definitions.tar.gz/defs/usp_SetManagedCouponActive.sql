
CREATE   PROCEDURE dbo.usp_SetManagedCouponActive
    @coupon_id uniqueidentifier, @actor_id uniqueidentifier, @auth_version int, @active bit
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @organization_id uniqueidentifier;
    SELECT @organization_id=organization_id FROM dbo.tc_coupons WHERE id=@coupon_id;
    IF @organization_id IS NULL THROW 51523,'Coupon not found',1;
    EXEC dbo.usp_CouponAdminAuthorize @actor_id,@auth_version,@organization_id;
    UPDATE dbo.tc_coupons SET active=@active,version=version+1
    WHERE id=@coupon_id AND organization_id=@organization_id;
    IF @@ROWCOUNT<>1 THROW 51523,'Coupon not found',1;
END;
