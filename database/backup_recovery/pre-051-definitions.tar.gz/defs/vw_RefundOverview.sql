
/* View: vw_RefundOverview */
/* Canonical view name. Legacy view remains available during transition. */
CREATE   VIEW dbo.vw_RefundOverview
AS
WITH ticket_totals AS (
    SELECT refund_id, COUNT_BIG(*) ticket_count,
           SUM(CASE WHEN is_open = 1 THEN 1 ELSE 0 END) open_ticket_count
    FROM dbo.tc_refund_tickets GROUP BY refund_id
), attempt_totals AS (
    SELECT refund_id, COUNT_BIG(*) attempt_count,
           SUM(CASE WHEN status = 'SUCCEEDED' THEN 1 ELSE 0 END) succeeded_attempt_count,
           MAX(created_at) latest_attempt_at
    FROM dbo.tc_refund_transfer_logs GROUP BY refund_id
)
SELECT r.id refund_id, r.order_id, o.event_id, e.organization_id, r.payment_id,
       r.purpose, r.reason_type, r.reason, r.rejection_reason, r.amount, r.status,
       r.current_attempt_id, r.provider_reference, r.processed_at, r.created_at,
       COALESCE(t.ticket_count, 0) ticket_count,
       COALESCE(t.open_ticket_count, 0) open_ticket_count,
       COALESCE(a.attempt_count, 0) attempt_count,
       COALESCE(a.succeeded_attempt_count, 0) succeeded_attempt_count,
       a.latest_attempt_at
FROM dbo.tc_refund_obligations r
LEFT JOIN dbo.tc_orders o ON o.id = r.order_id
LEFT JOIN dbo.tc_events e ON e.id = o.event_id
LEFT JOIN ticket_totals t ON t.refund_id = r.id
LEFT JOIN attempt_totals a ON a.refund_id = r.id;
