
CREATE   PROCEDURE dbo.usp_VuongRequireAdmin @actor_id uniqueidentifier,@auth_version int=NULL AS
BEGIN
 SET NOCOUNT ON;
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_users WITH(HOLDLOCK) WHERE id=@actor_id AND status='ACTIVE' AND platform_role='ADMIN' AND (@auth_version IS NULL OR auth_version=@auth_version))
 THROW 52701,'ADMIN_REQUIRED',1;
END;
