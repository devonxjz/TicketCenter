
CREATE   PROCEDURE dbo.usp_CouponAdminAuthorize
    @actor_id uniqueidentifier, @auth_version int, @organization_id uniqueidentifier=NULL
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS(SELECT 1 FROM dbo.tc_users
                  WHERE id=@actor_id AND auth_version=@auth_version AND status='ACTIVE')
        THROW 51520,'Current session required',1;
    IF ISNULL(IS_ROLEMEMBER('tc_platform_admin'),0)=1
       AND EXISTS(SELECT 1 FROM dbo.tc_user_platform_roles
                  WHERE user_id=@actor_id AND role='ADMIN') RETURN;
    IF @organization_id IS NOT NULL AND ISNULL(IS_ROLEMEMBER('tc_manager'),0)=1
       AND EXISTS(SELECT 1 FROM dbo.tc_organization_memberships WITH (HOLDLOCK)
                  WHERE user_id=@actor_id AND organization_id=@organization_id
                    AND role='MANAGER' AND active=1) RETURN;
    THROW 51521,'Organization manager or platform admin required',1;
END;
