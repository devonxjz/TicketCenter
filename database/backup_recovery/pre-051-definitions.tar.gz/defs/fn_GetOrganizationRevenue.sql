
CREATE   FUNCTION dbo.fn_GetOrganizationRevenue(@organization_id uniqueidentifier,@from_utc datetime2(3),@to_utc datetime2(3))
RETURNS TABLE AS RETURN
SELECT e.id event_id,e.organization_id,COALESCE(f.paid_order_count,0) paid_order_count,
 CAST(COALESCE(f.gross_revenue,0) AS decimal(19,0)) gross_revenue,CAST(COALESCE(f.total_refund,0) AS decimal(19,0)) total_refund,
 CAST(COALESCE(f.gross_revenue-f.total_refund,0) AS decimal(19,0)) remaining_amount,CAST(COALESCE(f.total_commission,0) AS decimal(19,0)) total_commission,
 CAST(COALESCE(f.gross_revenue-f.total_refund-f.total_commission,0) AS decimal(19,0)) net_payable
FROM dbo.tc_events e OUTER APPLY (
 SELECT COUNT_BIG(*) paid_order_count,SUM(o.total_amount) gross_revenue,SUM(COALESCE(r.amount,0)) total_refund,
 SUM(dbo.fn_CalculateCommission(o.total_amount-COALESCE(r.amount,0),c.rate_percent,c.fixed_fee)) total_commission
 FROM dbo.vw_VuongOrders o LEFT JOIN dbo.vw_VuongPayments p ON p.id=o.accepted_payment_id LEFT JOIN dbo.tc_commission_rules c ON c.id=e.commission_rule_id
 OUTER APPLY(SELECT SUM(r.amount) amount FROM dbo.vw_VuongRefunds r WHERE r.order_id=o.id AND r.purpose='CUSTOMER_REFUND' AND EXISTS
 (SELECT 1 FROM dbo.tc_refund_transfer_logs l WHERE l.refund_id=r.id AND l.result='SUCCEEDED' AND l.processed_at<@to_utc)) r
 WHERE o.event_id=e.id AND o.status='PAID' AND o.paid_at>=@from_utc AND o.paid_at<@to_utc AND
 (o.total_amount=0 OR (p.status='CAPTURED' AND p.order_id=o.id AND p.amount=o.total_amount))) f
WHERE (@organization_id IS NULL OR e.organization_id=@organization_id) AND @from_utc<@to_utc;
