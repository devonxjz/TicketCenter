
CREATE   FUNCTION dbo.fn_GetOrganizationCashFlow(@organization_id uniqueidentifier,@from_utc datetime2(3),@to_utc datetime2(3))
RETURNS TABLE AS RETURN
SELECT e.id event_id,e.organization_id,CAST(COALESCE(p.ticket_captured,0) AS decimal(19,0)) ticket_captured,
 CAST(COALESCE(p.compensation_captured,0) AS decimal(19,0)) compensation_captured,CAST(COALESCE(r.ticket_refund,0) AS decimal(19,0)) ticket_refund,
 CAST(COALESCE(r.compensation_refund,0) AS decimal(19,0)) compensation_refund,
 CAST(COALESCE(p.ticket_captured,0)+COALESCE(p.compensation_captured,0)-COALESCE(r.ticket_refund,0)-COALESCE(r.compensation_refund,0) AS decimal(19,0)) net_cash_flow
FROM dbo.tc_events e OUTER APPLY(SELECT SUM(CASE WHEN p.id=o.accepted_payment_id THEN p.amount ELSE 0 END) ticket_captured,
 SUM(CASE WHEN o.accepted_payment_id IS NULL OR p.id<>o.accepted_payment_id THEN p.amount ELSE 0 END) compensation_captured
 FROM dbo.vw_VuongPayments p JOIN dbo.vw_VuongOrders o ON o.id=p.order_id WHERE o.event_id=e.id AND p.status='CAPTURED' AND p.paid_at>=@from_utc AND p.paid_at<@to_utc) p
OUTER APPLY(SELECT SUM(CASE WHEN r.purpose='CUSTOMER_REFUND' THEN r.amount ELSE 0 END) ticket_refund,SUM(CASE WHEN r.purpose='PAYMENT_COMPENSATION' THEN r.amount ELSE 0 END) compensation_refund
 FROM dbo.vw_VuongRefunds r JOIN dbo.vw_VuongOrders o ON o.id=r.order_id WHERE o.event_id=e.id AND EXISTS
 (SELECT 1 FROM dbo.tc_refund_transfer_logs l WHERE l.refund_id=r.id AND l.result='SUCCEEDED' AND l.processed_at>=@from_utc AND l.processed_at<@to_utc)) r
WHERE (@organization_id IS NULL OR e.organization_id=@organization_id) AND @from_utc<@to_utc;
