
CREATE   FUNCTION dbo.fn_ReadOwnMemberships()
RETURNS TABLE AS RETURN
 SELECT user_id,organization_id,role,active FROM dbo.tc_organization_memberships
 WHERE user_id=TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'actor_id'));
