
CREATE   PROCEDURE dbo.usp_SubmitEvent @event_id uniqueidentifier,@actor_id uniqueidentifier,@expected_version bigint
AS BEGIN SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @org uniqueidentifier;
 SELECT @org=organization_id FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@event_id;
 EXEC dbo.usp_RequireOrganizationManager @actor_id,@org;
 UPDATE dbo.tc_events SET status='PENDING_APPROVAL',version=version+1 WHERE id=@event_id AND status IN('DRAFT','REJECTED') AND version=@expected_version;
 IF @@ROWCOUNT<>1 THROW 51813,'Event version or state conflict',1;
 INSERT dbo.tc_audit_logs(actor_id,action,aggregate_type,aggregate_id) VALUES(@actor_id,'EVENT_SUBMITTED','EVENT',@event_id);
 COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
