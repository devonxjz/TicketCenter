
CREATE   PROCEDURE dbo.usp_CanManageCouponOrganization
    @actor_id uniqueidentifier, @auth_version int, @organization_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CAST(CASE WHEN EXISTS(SELECT 1 FROM dbo.tc_users
                                 WHERE id=@actor_id AND auth_version=@auth_version AND status='ACTIVE')
        AND (ISNULL(IS_ROLEMEMBER('tc_platform_admin'),0)=1
             AND EXISTS(SELECT 1 FROM dbo.tc_user_platform_roles
                        WHERE user_id=@actor_id AND role='ADMIN')
             OR @organization_id IS NOT NULL AND ISNULL(IS_ROLEMEMBER('tc_manager'),0)=1
             AND EXISTS(SELECT 1 FROM dbo.tc_organization_memberships
                        WHERE user_id=@actor_id AND organization_id=@organization_id
                          AND role='MANAGER' AND active=1))
        THEN 1 ELSE 0 END AS bit) AS allowed;
END;
