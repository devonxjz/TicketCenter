
CREATE   FUNCTION dbo.fn_ReportOrganizationVisibility(@organization uniqueidentifier,@public bit)
RETURNS TABLE WITH SCHEMABINDING AS RETURN
 SELECT 1 permitted WHERE @public=1 OR USER_NAME()=N'dbo' OR COALESCE(IS_MEMBER('db_owner'),0)=1
 OR COALESCE(IS_ROLEMEMBER('tc_platform_admin'),0)=1 OR COALESCE(IS_ROLEMEMBER('tc_worker'),0)=1
 OR EXISTS(SELECT 1 FROM dbo.tc_organization_memberships m JOIN dbo.tc_users u ON u.id=m.user_id
 WHERE m.organization_id=@organization AND m.user_id=TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'actor_id')) AND m.active=1 AND u.status='ACTIVE');
