CREATE   VIEW dbo.vw_VuongRefunds AS
 SELECT r.id,r.order_id,r.amount,r.purpose,r.status,r.current_attempt_id,r.processed_at
 FROM dbo.tc_refund_obligations r WHERE NOT (
 r.purpose='PAYMENT_COMPENSATION' AND r.status='RETRYABLE' AND EXISTS (
 SELECT 1 FROM dbo.tc_refund_transfer_logs failed JOIN dbo.tc_payments p ON p.id=r.payment_id
 WHERE failed.id=r.id AND failed.refund_id=r.id AND failed.status='FAILED'
 AND p.order_id=r.order_id AND p.status='CAPTURED' AND r.amount<=p.amount
 AND p.amount>0 AND p.amount<=(SELECT COALESCE(SUM(done.amount),0)
 FROM dbo.tc_refund_obligations done WHERE done.payment_id=p.id AND done.order_id=r.order_id
 AND done.purpose='PAYMENT_COMPENSATION' AND done.status='COMPLETED' AND done.processed_at IS NOT NULL
 AND EXISTS(SELECT 1 FROM dbo.tc_refund_transfer_logs l WHERE l.refund_id=done.id
 AND l.id=done.current_attempt_id AND l.result='SUCCEEDED' AND l.processed_at IS NOT NULL))));
