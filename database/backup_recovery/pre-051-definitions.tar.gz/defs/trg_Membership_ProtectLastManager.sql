
/* Trigger: trg_Membership_ProtectLastManager */
CREATE   TRIGGER dbo.trg_Membership_ProtectLastManager ON dbo.tc_organization_memberships
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM (SELECT organization_id FROM deleted UNION SELECT organization_id FROM inserted) x
        WHERE NOT EXISTS (
            SELECT 1 FROM dbo.tc_organization_memberships m WITH (UPDLOCK, HOLDLOCK)
            JOIN dbo.tc_users u ON u.id = m.user_id
            WHERE m.organization_id = x.organization_id AND m.role = 'MANAGER'
              AND m.active = 1 AND u.status = 'ACTIVE'
        )
    ) THROW 51106, 'Organization must retain an active manager', 1;
END;
