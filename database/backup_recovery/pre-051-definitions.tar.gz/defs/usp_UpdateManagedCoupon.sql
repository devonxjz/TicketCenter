
CREATE   PROCEDURE dbo.usp_UpdateManagedCoupon
    @coupon_id uniqueidentifier, @actor_id uniqueidentifier, @auth_version int,
    @max_uses int=NULL, @valid_to datetime2(3)=NULL, @max_discount_amount decimal(19,0)=NULL
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @organization_id uniqueidentifier;
    SELECT @organization_id=organization_id FROM dbo.tc_coupons WHERE id=@coupon_id;
    IF @organization_id IS NULL THROW 51523,'Coupon not found',1;
    EXEC dbo.usp_CouponAdminAuthorize @actor_id,@auth_version,@organization_id;
    UPDATE dbo.tc_coupons SET max_uses=COALESCE(@max_uses,max_uses),
           valid_to=COALESCE(@valid_to,valid_to),
           max_discount_amount=COALESCE(@max_discount_amount,max_discount_amount),version=version+1
    WHERE id=@coupon_id AND organization_id=@organization_id;
    IF @@ROWCOUNT<>1 THROW 51523,'Coupon not found',1;
END;
