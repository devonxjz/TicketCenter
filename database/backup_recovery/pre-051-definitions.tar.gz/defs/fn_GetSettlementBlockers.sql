
CREATE   FUNCTION dbo.fn_GetSettlementBlockers(@event_id uniqueidentifier,@now_utc datetime2(3)) RETURNS TABLE AS RETURN
SELECT CAST('EVENT_NOT_ENDED' AS varchar(40)) blocker_type,e.id object_id,CAST('Scheduled event end has not passed' AS nvarchar(200)) detail FROM dbo.tc_events e WHERE e.id=@event_id AND e.end_time>@now_utc
UNION ALL SELECT 'ORDER_PAYMENT',id,'Order payment is unresolved' FROM dbo.vw_VuongOrders WHERE event_id=@event_id AND status='PENDING_PAYMENT'
UNION ALL SELECT 'PAYMENT',p.id,'Capture is pending or unknown' FROM dbo.vw_VuongPayments p JOIN dbo.vw_VuongOrders o ON o.id=p.order_id WHERE o.event_id=@event_id AND p.status IN('PENDING','UNKNOWN')
UNION ALL SELECT 'REFUND',r.id,'Refund obligation is unresolved' FROM dbo.vw_VuongRefunds r JOIN dbo.vw_VuongOrders o ON o.id=r.order_id WHERE o.event_id=@event_id AND r.status NOT IN('COMPLETED','REJECTED')
UNION ALL SELECT 'REFUND_VERIFICATION',r.id,'Completed positive refund lacks a verified successful transfer' FROM dbo.vw_VuongRefunds r JOIN dbo.vw_VuongOrders o ON o.id=r.order_id WHERE o.event_id=@event_id AND r.status='COMPLETED' AND r.amount>0 AND
 (NOT EXISTS(SELECT 1 FROM dbo.tc_refund_transfer_logs l WHERE l.refund_id=r.id AND l.result='SUCCEEDED' AND l.processed_at IS NOT NULL) OR
 (r.current_attempt_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.tc_refund_transfer_logs l WHERE l.id=r.current_attempt_id AND l.refund_id=r.id AND l.result='SUCCEEDED' AND l.processed_at IS NOT NULL)))
UNION ALL SELECT 'CANCELLATION_WORK',x.id,'Cancellation outbox work is unfinished' FROM dbo.tc_outbox x WHERE x.event_type='EVENT_CANCELLED' AND x.status<>'PUBLISHED' AND TRY_CONVERT(uniqueidentifier,JSON_VALUE(CASE WHEN ISJSON(x.payload)=1 THEN x.payload ELSE '{}' END,'$.eventId'))=@event_id
UNION ALL SELECT 'CANCELLED_REVENUE',f.order_id,'Cancelled order still has unrefunded ticket revenue' FROM dbo.vw_OrderFinancialSummary f JOIN dbo.tc_events e ON e.id=f.event_id WHERE e.id=@event_id AND e.status='CANCELLED' AND f.remaining_amount>0
UNION ALL SELECT 'INVALID_FINANCIALS',f.order_id,'Accepted order or commission financial data is invalid' FROM dbo.vw_OrderFinancialSummary f WHERE f.event_id=@event_id AND f.status='PAID' AND (f.commission_amount IS NULL OR f.remaining_amount<0 OR (f.total_amount>0 AND f.ticket_revenue=0));
