/* ---- C. rewritten views / functions / procedures (write canonical tables directly) ---- */
CREATE   VIEW dbo.vw_RefundAttemptLedger AS
/* One row per transfer attempt with the financial terms of its obligation.
   Amount, payment and purpose live on the obligation; the attempt only records the transfer. */
SELECT l.id attempt_id,l.refund_id,o.order_id,o.payment_id,o.purpose,o.amount,l.attempt_no,
       l.status,l.provider_reference,l.created_at,l.processed_at
FROM dbo.tc_refund_transfer_logs l JOIN dbo.tc_refund_obligations o ON o.id=l.refund_id;
