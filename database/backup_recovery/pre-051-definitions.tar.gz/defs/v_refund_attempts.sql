
CREATE   VIEW dbo.v_refund_attempts AS
SELECT refund_id,id attempt_id,attempt_no,status,created_at,processed_at
FROM dbo.tc_refund_transfer_logs;
