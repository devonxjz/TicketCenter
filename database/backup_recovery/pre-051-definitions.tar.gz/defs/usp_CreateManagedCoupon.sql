
CREATE   PROCEDURE dbo.usp_CreateManagedCoupon
    @organization_id uniqueidentifier, @actor_id uniqueidentifier, @auth_version int,
    @code varchar(80), @discount_type varchar(30), @percentage_value decimal(5,2)=NULL,
    @fixed_amount decimal(19,0)=NULL, @max_discount_amount decimal(19,0)=NULL,
    @max_uses int, @valid_from datetime2(3), @valid_to datetime2(3)
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.usp_CouponAdminAuthorize @actor_id,@auth_version,@organization_id;
    DECLARE @id uniqueidentifier=NEWID();
    INSERT dbo.tc_coupons(id,organization_id,code,discount_type,percentage_value,fixed_amount,
                          max_discount_amount,max_uses,valid_from,valid_to,active,version)
    VALUES(@id,@organization_id,@code,@discount_type,@percentage_value,@fixed_amount,
           @max_discount_amount,@max_uses,@valid_from,@valid_to,1,0);
    SELECT @id AS id;
END;
