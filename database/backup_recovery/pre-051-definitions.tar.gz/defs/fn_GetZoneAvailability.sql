
/* Function: fn_GetZoneAvailability */
CREATE   FUNCTION dbo.fn_GetZoneAvailability(@zone_id uniqueidentifier)
RETURNS TABLE
AS RETURN (SELECT * FROM dbo.vw_ZoneInventory WHERE zone_id = @zone_id);
