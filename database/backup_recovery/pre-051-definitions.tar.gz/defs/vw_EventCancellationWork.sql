CREATE   VIEW dbo.vw_EventCancellationWork
AS
    SELECT h.event_id, CAST('HOLD' AS varchar(10)) work_type, h.id work_id
    FROM dbo.tc_ticket_holds h
    JOIN dbo.tc_events e ON e.id = h.event_id
    WHERE e.status = 'CANCELLED' AND h.status = 'ACTIVE'
      AND NOT EXISTS (SELECT 1 FROM dbo.tc_orders o WHERE o.hold_id = h.id)
      AND EXISTS (
          SELECT 1 FROM dbo.tc_outbox x
          WHERE x.event_type = 'EVENT_CANCELLED' AND x.aggregate_id = h.event_id
            AND x.status <> 'PUBLISHED')
    UNION ALL
    SELECT o.event_id, CAST('ORDER' AS varchar(10)), o.id
    FROM dbo.tc_orders o
    JOIN dbo.tc_events e ON e.id = o.event_id
    WHERE e.status = 'CANCELLED'
      AND EXISTS (
          SELECT 1 FROM dbo.tc_outbox x
          WHERE x.event_type = 'EVENT_CANCELLED' AND x.aggregate_id = o.event_id
            AND x.status <> 'PUBLISHED')
      AND (
          EXISTS (SELECT 1 FROM dbo.tc_ticket_holds h WHERE h.id = o.hold_id AND h.status = 'ACTIVE')
          OR EXISTS (
              SELECT 1 FROM dbo.tc_tickets t
              JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id
              WHERE oi.order_id = o.id AND t.status = 'ACTIVE')
          OR EXISTS (
              SELECT 1 FROM dbo.tc_refund_obligations rr
              WHERE rr.order_id = o.id AND rr.purpose = 'CUSTOMER_REFUND' AND rr.status = 'REQUESTED'));
