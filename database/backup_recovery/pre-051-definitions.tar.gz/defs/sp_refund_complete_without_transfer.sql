
-- Valid zero refunds are completed by SP10 in its approval transaction, without any attempt.
CREATE   PROCEDURE dbo.sp_refund_complete_without_transfer @refund_id uniqueidentifier AS
BEGIN
 SET NOCOUNT ON;
 IF COALESCE(IS_ROLEMEMBER('tc_worker'),0)<>1 AND COALESCE(IS_MEMBER('db_owner'),0)<>1 THROW 53500,'Worker principal required',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_refund_obligations WHERE id=@refund_id AND amount=0 AND status='COMPLETED' AND current_attempt_id IS NULL)
  THROW 53504,'Zero refund must complete atomically through approval',1;
 SELECT @refund_id refund_id,CAST('COMPLETED' AS varchar(30)) status;
END;
