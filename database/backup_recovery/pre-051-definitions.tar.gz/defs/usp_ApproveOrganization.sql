
/* Stored Procedure: usp_ApproveOrganization */
/* Canonical names delegate to the proven legacy transaction paths. */
CREATE   PROCEDURE dbo.usp_ApproveOrganization
    @organization_id uniqueidentifier,
    @actor_id uniqueidentifier,
    @initial_commission_policy nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM dbo.tc_organization_requests WHERE id = @organization_id)
    BEGIN
        EXEC dbo.usp_ApproveOrganizationRequest
            @request_id = @organization_id,
            @actor_id = @actor_id,
            @initial_commission_policy = @initial_commission_policy;
        RETURN;
    END;

    SET XACT_ABORT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.tc_user_platform_roles WHERE user_id = @actor_id AND role = 'ADMIN')
            THROW 52610, 'Administrator role required', 1;

        DECLARE @status varchar(30), @requester_id uniqueidentifier,
                @rate decimal(7,4), @fixed decimal(19,0),
                @effective_from datetime2(3), @effective_to datetime2(3);
        SELECT @status = status, @requester_id = requester_id
        FROM dbo.tc_organizations WITH (UPDLOCK, HOLDLOCK) WHERE id = @organization_id;
        IF @status IS NULL THROW 52611, 'Organization not found', 1;
        IF @status = 'APPROVED' BEGIN COMMIT; SELECT @organization_id organization_id, @status status; RETURN; END;
        IF @status <> 'PENDING_APPROVAL' THROW 52612, 'Organization is not pending approval', 1;

        SELECT @rate = TRY_CONVERT(decimal(7,4), JSON_VALUE(@initial_commission_policy, '$.ratePercent')),
               @fixed = TRY_CONVERT(decimal(19,0), JSON_VALUE(@initial_commission_policy, '$.fixedFee')),
               @effective_from = TRY_CONVERT(datetime2(3), JSON_VALUE(@initial_commission_policy, '$.effectiveFrom')),
               @effective_to = TRY_CONVERT(datetime2(3), JSON_VALUE(@initial_commission_policy, '$.effectiveTo'));
        IF ISJSON(@initial_commission_policy) <> 1 OR @rate IS NULL OR @fixed IS NULL
           OR @effective_from IS NULL OR @effective_to IS NULL
            THROW 52613, 'Invalid initial commission policy', 1;

        INSERT dbo.tc_commission_rules(organization_id, rate_percent, fixed_fee, effective_from, effective_to)
        VALUES (@organization_id, @rate, @fixed, @effective_from, @effective_to);
        IF @requester_id IS NOT NULL AND NOT EXISTS (
            SELECT 1 FROM dbo.tc_organization_memberships
            WHERE user_id = @requester_id AND organization_id = @organization_id
        )
            INSERT dbo.tc_organization_memberships(user_id, organization_id, role)
            VALUES (@requester_id, @organization_id, 'MANAGER');
        UPDATE dbo.tc_organizations
        SET status = 'APPROVED', decided_at = SYSUTCDATETIME(), updated_at = SYSUTCDATETIME(), rejection_reason = NULL
        WHERE id = @organization_id;
        INSERT dbo.tc_audit_logs(actor_id, action, aggregate_type, aggregate_id)
        VALUES (@actor_id, 'ORGANIZATION_APPROVED', 'ORGANIZATION', @organization_id);
        COMMIT;
        SELECT @organization_id organization_id, CAST('APPROVED' AS varchar(30)) status;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0 ROLLBACK;
        THROW;
    END CATCH;
END;
