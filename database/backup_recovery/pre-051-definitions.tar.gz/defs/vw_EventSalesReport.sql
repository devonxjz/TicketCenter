
CREATE   VIEW dbo.vw_EventSalesReport AS
SELECT e.id event_id,e.organization_id,e.title event_title,e.status event_status,e.end_time,
 COALESCE(f.paid_order_count,0) paid_order_count,COALESCE(t.ticket_count,0) ticket_count,COALESCE(t.valid_ticket_count,0) valid_ticket_count,COALESCE(t.refunded_ticket_count,0) refunded_ticket_count,
 CAST(CASE WHEN s.status IN('CONFIRMED','PAID') THEN s.gross_revenue ELSE COALESCE(f.gross_revenue,0) END AS decimal(19,0)) gross_revenue,
 CAST(CASE WHEN s.status IN('CONFIRMED','PAID') THEN s.total_refund ELSE COALESCE(f.total_refund,0) END AS decimal(19,0)) total_refund,
 CAST(CASE WHEN s.status IN('CONFIRMED','PAID') THEN s.total_commission ELSE COALESCE(f.total_commission,0) END AS decimal(19,0)) total_commission,
 CAST(CASE WHEN s.status IN('CONFIRMED','PAID') THEN s.net_payable ELSE COALESCE(f.net_payable,0) END AS decimal(19,0)) net_payable,
 s.id settlement_id,s.status settlement_status,CAST(CASE WHEN s.status IN('CONFIRMED','PAID') THEN 1 ELSE 0 END AS bit) is_confirmed
FROM dbo.tc_events e LEFT JOIN dbo.tc_settlements s ON s.event_id=e.id
OUTER APPLY(SELECT COUNT_BIG(*) paid_order_count,SUM(ticket_revenue) gross_revenue,SUM(ticket_refund) total_refund,SUM(commission_amount) total_commission,SUM(net_amount) net_payable FROM dbo.vw_OrderFinancialSummary WHERE event_id=e.id AND status='PAID') f
OUTER APPLY(SELECT COUNT_BIG(*) ticket_count,SUM(CASE WHEN t.status IN('ACTIVE','USED') THEN CONVERT(bigint,1) ELSE 0 END) valid_ticket_count,SUM(CASE WHEN t.status='REFUNDED' THEN CONVERT(bigint,1) ELSE 0 END) refunded_ticket_count FROM dbo.tc_tickets t JOIN dbo.tc_order_items i ON i.id=t.order_item_id JOIN dbo.vw_VuongOrders o ON o.id=i.order_id WHERE o.event_id=e.id) t;
