
CREATE   VIEW dbo.vw_SettlementPayoutBalance AS
SELECT s.id settlement_id,s.event_id,e.organization_id,s.status,s.gross_revenue,s.total_refund,s.total_commission,
 s.net_payable,s.paid_amount,s.pending_amount,CAST(s.net_payable-s.paid_amount-s.pending_amount AS decimal(19,0)) available_to_pay,s.confirmed_at
FROM dbo.tc_settlements s JOIN dbo.tc_events e ON e.id=s.event_id;
