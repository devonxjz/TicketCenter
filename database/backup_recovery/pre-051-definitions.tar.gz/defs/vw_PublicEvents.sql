
/* View: vw_PublicEvents */
CREATE   VIEW dbo.vw_PublicEvents
AS
SELECT e.id event_id, e.organization_id, e.category_id, e.title, e.description,
       COALESCE(e.event_image, CONVERT(varchar(2048), e.cover_image_url)) cover_image_url,
       e.venue_name, e.venue_address, e.sale_start, e.sale_end,
       e.start_time, e.end_time, MIN(z.price) minimum_price
FROM dbo.tc_events e
LEFT JOIN dbo.tc_zones z ON z.event_id = e.id
WHERE e.status = 'PUBLISHED'
GROUP BY e.id, e.organization_id, e.category_id, e.title, e.description,
         e.event_image, e.cover_image_url, e.venue_name, e.venue_address,
         e.sale_start, e.sale_end, e.start_time, e.end_time;
