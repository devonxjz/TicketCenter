
CREATE   PROCEDURE dbo.usp_SaveEventDraft
 @event_id uniqueidentifier,@organization_id uniqueidentifier,@actor_id uniqueidentifier,@create bit,@expected_version bigint,
 @category_id uniqueidentifier=NULL,@title nvarchar(200)=NULL,@description nvarchar(max)=NULL,
 @venue_name nvarchar(200)=NULL,@venue_address nvarchar(500)=NULL,@sale_start datetime2(3)=NULL,@sale_end datetime2(3)=NULL,
 @start_time datetime2(3)=NULL,@end_time datetime2(3)=NULL,@image_url varchar(2048)=NULL,@image_public_id varchar(255)=NULL,@cover_only bit=0
AS BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 DECLARE @started bit=CASE WHEN @@TRANCOUNT=0 THEN 1 ELSE 0 END,@status varchar(30),@version bigint;
 IF @started=1 BEGIN TRANSACTION;
 BEGIN TRY
  EXEC dbo.usp_RequireOrganizationManager @actor_id,@organization_id;
  IF @create=1 BEGIN
   IF @cover_only=1 THROW 51811,'Draft fields required',1;
   INSERT dbo.tc_events(id,organization_id,category_id,title,description,venue_name,venue_address,sale_start,sale_end,start_time,end_time,status,version,event_image,event_image_public_id,cover_image_url)
   VALUES(@event_id,@organization_id,@category_id,@title,@description,@venue_name,@venue_address,@sale_start,@sale_end,@start_time,@end_time,'DRAFT',0,@image_url,@image_public_id,@image_url);
  END ELSE BEGIN
   SELECT @status=status,@version=version FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@event_id AND organization_id=@organization_id;
   IF @status IS NULL OR @status NOT IN('DRAFT','REJECTED','PUBLISHED') OR (@status='PUBLISHED' AND @cover_only<>1) THROW 51812,'Only editable drafts or the cover of a published event may be changed',1;
   IF @version<>@expected_version THROW 51813,'Event version conflict',1;
   UPDATE dbo.tc_events SET
    category_id=CASE WHEN @cover_only=1 THEN category_id ELSE @category_id END,
    title=CASE WHEN @cover_only=1 THEN title ELSE @title END,description=CASE WHEN @cover_only=1 THEN description ELSE @description END,
    venue_name=CASE WHEN @cover_only=1 THEN venue_name ELSE @venue_name END,venue_address=CASE WHEN @cover_only=1 THEN venue_address ELSE @venue_address END,
    sale_start=CASE WHEN @cover_only=1 THEN sale_start ELSE @sale_start END,sale_end=CASE WHEN @cover_only=1 THEN sale_end ELSE @sale_end END,
    start_time=CASE WHEN @cover_only=1 THEN start_time ELSE @start_time END,end_time=CASE WHEN @cover_only=1 THEN end_time ELSE @end_time END,
    event_image=COALESCE(@image_url,event_image),cover_image_url=COALESCE(@image_url,cover_image_url),event_image_public_id=COALESCE(@image_public_id,event_image_public_id),version=version+1
   WHERE id=@event_id;
  END;
  INSERT dbo.tc_audit_logs(actor_id,action,aggregate_type,aggregate_id) VALUES(@actor_id,CASE WHEN @create=1 THEN 'EVENT_DRAFT_CREATED' ELSE 'EVENT_DRAFT_UPDATED' END,'EVENT',@event_id);
  IF @started=1 COMMIT;
 END TRY BEGIN CATCH IF @started=1 AND XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
