
/* Stored Procedure: usp_CancelEvent */
CREATE   PROCEDURE dbo.usp_CancelEvent @event_id uniqueidentifier, @actor_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @lock_count bigint;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp13;
    BEGIN TRY
        DECLARE @old_actor sql_variant=SESSION_CONTEXT(N'actor_id');
        EXEC sys.sp_set_session_context @key=N'actor_id',@value=@actor_id;
        IF NOT EXISTS (SELECT 1 FROM dbo.tc_user_platform_roles WHERE user_id = @actor_id AND role = 'ADMIN')
            THROW 51530, 'Administrator role required', 1;
        DECLARE @status varchar(30), @start datetime2(3);
        SELECT @status = status, @start = start_time
        FROM dbo.tc_events WITH (UPDLOCK, HOLDLOCK) WHERE id = @event_id;
        IF @status IS NULL THROW 51531, 'Event not found', 1;
        IF @status = 'CANCELLED' BEGIN
            SELECT @event_id event_id, @status status;
            IF @started = 1 COMMIT TRANSACTION;
        EXEC sys.sp_set_session_context @key=N'actor_id',@value=@old_actor; RETURN;
        END;
        IF @status <> 'PUBLISHED' OR SYSUTCDATETIME() >= @start
            THROW 51532, 'Only a future published event can be cancelled', 1;
        UPDATE dbo.tc_events SET status = 'CANCELLED', version = version + 1 WHERE id = @event_id;
        INSERT dbo.tc_outbox(event_type, aggregate_type, aggregate_id, payload, idempotency_key)
        VALUES ('EVENT_CANCELLED', 'EVENT', @event_id,
                CONCAT(N'{"eventId":"', @event_id, N'"}'), CONCAT('event-cancelled:', @event_id));
        IF @started = 1 COMMIT TRANSACTION;
        EXEC sys.sp_set_session_context @key=N'actor_id',@value=@old_actor;
        SELECT @event_id event_id, CAST('CANCELLED' AS varchar(30)) status;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp13;
        EXEC sys.sp_set_session_context @key=N'actor_id',@value=@old_actor;
        THROW;
    END CATCH
END;
