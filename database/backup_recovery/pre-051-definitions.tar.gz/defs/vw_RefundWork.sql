CREATE   VIEW dbo.vw_RefundWork
AS
    SELECT attempt_id id, amount, status, provider_reference, created_at
    FROM dbo.vw_RefundAttemptLedger
    WHERE status IN ('PENDING', 'UNKNOWN');
