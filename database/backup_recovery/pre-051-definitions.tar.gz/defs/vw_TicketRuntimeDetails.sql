
CREATE   VIEW dbo.vw_TicketRuntimeDetails AS
 SELECT t.id,t.ticket_code,t.paid_amount,t.status,t.issued_at,t.version,
        i.order_id,i.zone_name_snapshot,i.seat_label_snapshot,
        o.order_code,o.user_id buyer_id,e.id event_id,e.title event_title,
        e.venue_name,e.venue_address,e.start_time,e.end_time
 FROM dbo.tc_tickets t JOIN dbo.tc_order_items i ON i.id=t.order_item_id
 JOIN dbo.tc_orders o ON o.id=i.order_id JOIN dbo.tc_events e ON e.id=o.event_id;
