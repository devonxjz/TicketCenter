
CREATE   VIEW dbo.tc_refund_attempts AS
 SELECT l.id attempt_id,l.refund_id,l.attempt_no attempt_number,l.status,l.provider_reference provider_ref,l.result,l.created_at,l.processed_at,
 COALESCE(l.failure_reason,d.last_error) error_message
 FROM dbo.tc_refund_transfer_logs l LEFT JOIN dbo.tc_refund_dispatches d ON d.attempt_id=l.id;
