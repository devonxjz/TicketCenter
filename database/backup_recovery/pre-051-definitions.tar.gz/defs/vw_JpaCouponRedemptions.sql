
CREATE   VIEW dbo.vw_JpaCouponRedemptions AS
SELECT r.id,r.coupon_id,r.order_id,o.user_id,r.status
FROM dbo.tc_coupon_redemptions r JOIN dbo.tc_orders o ON o.id=r.order_id;
