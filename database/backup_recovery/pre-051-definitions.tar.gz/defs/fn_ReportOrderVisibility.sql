
CREATE   FUNCTION dbo.fn_ReportOrderVisibility(@owner uniqueidentifier,@event uniqueidentifier)
RETURNS TABLE WITH SCHEMABINDING AS RETURN
 SELECT 1 permitted WHERE
 COALESCE(IS_MEMBER('db_owner'),0)=1 OR USER_NAME()=N'dbo'
 OR COALESCE(IS_ROLEMEMBER('tc_platform_admin'),0)=1 OR COALESCE(IS_ROLEMEMBER('tc_worker'),0)=1
 OR COALESCE(IS_ROLEMEMBER('tc_checkin'),0)=1
 OR @owner=TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'actor_id'))
 OR (COALESCE(IS_ROLEMEMBER('tc_manager'),0)=1 AND EXISTS(
 SELECT 1 FROM dbo.tc_events e JOIN dbo.tc_organization_memberships m ON m.organization_id=e.organization_id
 JOIN dbo.tc_users u ON u.id=m.user_id
 WHERE e.id=@event AND m.user_id=TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'actor_id')) AND m.role='MANAGER' AND m.active=1 AND u.status='ACTIVE'));
