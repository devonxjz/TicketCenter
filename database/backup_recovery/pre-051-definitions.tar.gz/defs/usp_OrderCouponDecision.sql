
CREATE   PROCEDURE dbo.usp_OrderCouponDecision
    @order_id uniqueidentifier,@coupon_code nvarchar(80),@now datetime2(3),@new_coupon uniqueidentifier OUTPUT,
    @reason varchar(30) OUTPUT,@discount decimal(19,0) OUTPUT,@remaining int OUTPUT,@valid_until datetime2(3) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @org uniqueidentifier,@subtotal decimal(19,0),@max int,@used int,@active bit,@from datetime2(3),@to datetime2(3),@own bit=0;
    SELECT @org=e.organization_id,@subtotal=o.subtotal_amount,@valid_until=h.expires_at
        FROM dbo.tc_orders o JOIN dbo.tc_events e ON e.id=o.event_id JOIN dbo.tc_ticket_holds h ON h.id=o.hold_id WHERE o.id=@order_id;
    SELECT @new_coupon=id,@active=active,@from=valid_from,@to=valid_to,@max=max_uses,
        @discount=dbo.fn_CalculateCouponDiscountCapped(@subtotal,id)
        FROM dbo.tc_coupons WHERE organization_id=@org AND code=@coupon_code;
    IF @new_coupon IS NULL BEGIN SET @reason=CASE WHEN EXISTS(SELECT 1 FROM dbo.tc_coupons WHERE code=@coupon_code AND organization_id<>@org) THEN 'WRONG_ORGANIZATION' ELSE 'NOT_FOUND' END; SET @remaining=0; RETURN; END;
    SELECT @used=COUNT(*) FROM dbo.tc_coupon_redemptions WHERE coupon_id=@new_coupon AND status IN('RESERVED','CONSUMED');
    IF EXISTS(SELECT 1 FROM dbo.tc_coupon_redemptions WHERE order_id=@order_id AND coupon_id=@new_coupon AND status='RESERVED') SET @own=1;
    SET @remaining=CASE WHEN @max>@used THEN @max-@used ELSE 0 END;
    IF @own=1 BEGIN
        SELECT @discount=discount_amount FROM dbo.tc_orders WHERE id=@order_id;
        SET @reason='ELIGIBLE'; RETURN;
    END;
    SET @valid_until=CASE WHEN @to<@valid_until THEN @to ELSE @valid_until END;
    SET @reason=CASE WHEN @active=0 THEN 'INACTIVE' WHEN @now<@from THEN 'NOT_STARTED' WHEN @now>=@to THEN 'EXPIRED'
        WHEN @discount IS NULL THEN 'INVALID_CONFIGURATION' WHEN @remaining=0 AND @own=0 THEN 'QUOTA_EXHAUSTED' ELSE 'ELIGIBLE' END;
END;
