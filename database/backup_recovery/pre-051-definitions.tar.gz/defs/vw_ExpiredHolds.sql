
CREATE   VIEW dbo.vw_ExpiredHolds AS
 SELECT id,user_id,event_id,expires_at FROM dbo.tc_ticket_holds WHERE status='ACTIVE' AND expires_at<=SYSUTCDATETIME();
