
CREATE   PROCEDURE dbo.usp_ReadManagedCoupon
    @coupon_id uniqueidentifier, @actor_id uniqueidentifier, @auth_version int
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @organization_id uniqueidentifier;
    SELECT @organization_id=organization_id FROM dbo.tc_coupons WHERE id=@coupon_id;
    IF @organization_id IS NULL THROW 51523,'Coupon not found',1;
    EXEC dbo.usp_CouponAdminAuthorize @actor_id,@auth_version,@organization_id;
    SELECT c.id,c.organization_id,o.name AS org_name,c.code,c.discount_type,
           c.percentage_value,c.fixed_amount,c.max_discount_amount,c.max_uses,
           u.reserved_uses,u.consumed_uses,u.available_uses,
           c.valid_from,c.valid_to,c.active,c.version
    FROM dbo.tc_coupons c JOIN dbo.vw_CouponUsage u ON u.coupon_id=c.id
    JOIN dbo.tc_organizations o ON o.id=c.organization_id WHERE c.id=@coupon_id;
END;
