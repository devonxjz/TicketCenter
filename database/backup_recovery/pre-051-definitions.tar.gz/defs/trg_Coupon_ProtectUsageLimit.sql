
/* Trigger: trg_Coupon_ProtectUsageLimit */
CREATE   TRIGGER dbo.trg_Coupon_ProtectUsageLimit ON dbo.tc_coupons
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted i
        WHERE i.max_uses < (SELECT COUNT_BIG(*) FROM dbo.tc_coupon_redemptions r WITH (UPDLOCK, HOLDLOCK)
                            WHERE r.coupon_id = i.id AND r.status IN ('RESERVED', 'CONSUMED'))
    ) THROW 51107, 'Coupon max uses is below current usage', 1;
END;
