
/* Function: fn_GetCouponEligibility */
CREATE   FUNCTION dbo.fn_GetCouponEligibility(
    @coupon_id uniqueidentifier, @organization_id uniqueidentifier,
    @subtotal decimal(19,0), @now_utc datetime2(3)
)
RETURNS TABLE
AS RETURN (
    SELECT c.id coupon_id,
       CASE WHEN c.organization_id <> @organization_id THEN CAST(0 AS bit)
            WHEN c.active = 0 THEN CAST(0 AS bit)
            WHEN @now_utc < c.valid_from OR @now_utc >= c.valid_to THEN CAST(0 AS bit)
            WHEN u.available_uses <= 0 THEN CAST(0 AS bit) ELSE CAST(1 AS bit) END is_eligible,
       CASE WHEN c.organization_id <> @organization_id THEN 'WRONG_ORGANIZATION'
            WHEN c.active = 0 THEN 'INACTIVE'
            WHEN @now_utc < c.valid_from THEN 'NOT_STARTED' WHEN @now_utc >= c.valid_to THEN 'EXPIRED'
            WHEN u.available_uses <= 0 THEN 'QUOTA_EXHAUSTED' ELSE 'ELIGIBLE' END reason,
       u.available_uses,
       dbo.fn_CalculateCouponDiscount(@subtotal, c.discount_type, c.percentage_value, c.fixed_amount) preview_discount
    FROM dbo.tc_coupons c JOIN dbo.vw_CouponUsage u ON u.coupon_id = c.id WHERE c.id = @coupon_id
);
