
CREATE   FUNCTION dbo.fn_ReportCouponVisibility(@organization uniqueidentifier)
RETURNS TABLE WITH SCHEMABINDING AS RETURN
 SELECT 1 permitted WHERE USER_NAME()=N'dbo' OR COALESCE(IS_MEMBER('db_owner'),0)=1
 OR COALESCE(IS_ROLEMEMBER('tc_platform_admin'),0)=1 OR COALESCE(IS_ROLEMEMBER('tc_worker'),0)=1
 -- Buyer has only eligibility/procedure access; code-containing aggregates are denied above.
 OR COALESCE(IS_ROLEMEMBER('tc_buyer'),0)=1
 OR EXISTS(SELECT 1 FROM dbo.tc_organization_memberships m JOIN dbo.tc_users u ON u.id=m.user_id
 WHERE m.organization_id=@organization AND m.user_id=TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'actor_id')) AND m.role='MANAGER' AND m.active=1 AND u.status='ACTIVE');
