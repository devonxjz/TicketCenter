
CREATE   PROCEDURE dbo.usp_ListManagedCoupons
    @actor_id uniqueidentifier, @auth_version int, @organization_id uniqueidentifier=NULL,
    @page int=1, @size int=20
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.usp_CouponAdminAuthorize @actor_id,@auth_version,@organization_id;
    IF @page IS NULL OR @size IS NULL OR @page<1 OR @size<1 OR @size>100
       OR @page>1+2147483647/@size THROW 51522,'Invalid page',1;
    DECLARE @offset int=(@page-1)*@size;
    SELECT c.id,c.organization_id,o.name AS org_name,c.code,c.discount_type,
           c.percentage_value,c.fixed_amount,c.max_discount_amount,c.max_uses,
           u.reserved_uses,u.consumed_uses,u.available_uses,
           c.valid_from,c.valid_to,c.active,c.version
    FROM dbo.tc_coupons c JOIN dbo.vw_CouponUsage u ON u.coupon_id=c.id
    JOIN dbo.tc_organizations o ON o.id=c.organization_id
    WHERE @organization_id IS NULL OR c.organization_id=@organization_id
    ORDER BY c.valid_from DESC,c.id DESC OFFSET @offset ROWS FETCH NEXT @size ROWS ONLY;
END;
