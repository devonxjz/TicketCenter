
CREATE   PROCEDURE dbo.usp_CompleteFreeOrder @order_id uniqueidentifier,@actor_id uniqueidentifier,@ticket_codes nvarchar(max)
AS BEGIN SET NOCOUNT ON;
 EXEC dbo.usp_ApplyPaymentResult @order_id=@order_id,@actor_id=@actor_id,@payment_id=NULL,@verified_result=N'{"status":"CAPTURED"}',@ticket_codes=@ticket_codes;
END;
