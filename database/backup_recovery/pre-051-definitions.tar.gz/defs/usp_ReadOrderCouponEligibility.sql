
CREATE   PROCEDURE dbo.usp_ReadOrderCouponEligibility @actor_id uniqueidentifier,@auth_version int,@order_id uniqueidentifier,@coupon_code nvarchar(80)
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF @@TRANCOUNT<>0 THROW 51410,'Facade owns transaction',1;
    BEGIN TRANSACTION;
    BEGIN TRY
        DECLARE @event_id uniqueidentifier,@hold_id uniqueidentifier,@owner_id uniqueidentifier,@old_coupon uniqueidentifier,@new_coupon uniqueidentifier,
            @locked_new uniqueidentifier,@org uniqueidentifier,@now datetime2(3),@reason varchar(30),@discount decimal(19,0),@remaining int,@valid_until datetime2(3),@payload nvarchar(max);
        SELECT @event_id=event_id,@hold_id=hold_id,@owner_id=user_id,@old_coupon=coupon_id FROM dbo.tc_orders WHERE id=@order_id;
        EXEC dbo.usp_HoldLockSelection @actor_id,@event_id,N'[]',@hold_id,@include_active=0;
        EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
        IF @owner_id IS NULL THROW 51404,'Order not found',1;
        IF @owner_id<>@actor_id THROW 51403,'Order owner required',1;
        SELECT @org=organization_id FROM dbo.tc_events WHERE id=@event_id;
        SELECT @old_coupon=coupon_id FROM dbo.tc_orders WHERE id=@order_id;
        SELECT @new_coupon=id FROM dbo.tc_coupons WHERE organization_id=@org AND code=@coupon_code;
        SET @locked_new=@new_coupon;
        EXEC dbo.usp_OrderLockCoupons @old_coupon,@new_coupon;
        DECLARE @quota_dummy int;
        SELECT @quota_dummy=COUNT(*) FROM dbo.tc_coupon_redemptions WITH(UPDLOCK,HOLDLOCK) WHERE coupon_id=@new_coupon AND status IN('RESERVED','CONSUMED');
        IF EXISTS(SELECT 1 FROM dbo.tc_payments WITH(UPDLOCK,HOLDLOCK) WHERE order_id=@order_id AND status IN('PENDING','UNKNOWN')) THROW 51407,'Payment unresolved',1;
        SET @now=SYSUTCDATETIME();
        IF NOT EXISTS(SELECT 1 FROM dbo.tc_orders o JOIN dbo.tc_ticket_holds h ON h.id=o.hold_id WHERE o.id=@order_id AND o.status='PENDING_PAYMENT' AND h.status='ACTIVE' AND h.expires_at>@now)
            THROW 51406,'Order is terminal or expired',1;
        IF NOT EXISTS(SELECT 1 FROM dbo.tc_events WHERE id=@event_id AND status='PUBLISHED' AND @now>=sale_start AND @now<sale_end) THROW 51406,'Event is not on sale',1;
        EXEC dbo.usp_OrderCouponDecision @order_id,@coupon_code,@now,@new_coupon OUTPUT,@reason OUTPUT,@discount OUTPUT,@remaining OUTPUT,@valid_until OUTPUT;
        IF ISNULL(@new_coupon,'00000000-0000-0000-0000-000000000000')<>ISNULL(@locked_new,'00000000-0000-0000-0000-000000000000') THROW 51309,'Coupon preflight changed',1;
        SELECT @payload=(SELECT CONVERT(varchar(23),@now,126)+'Z' serverTime,LOWER(CONVERT(char(36),@order_id)) orderId,@coupon_code couponCode,
            CAST(CASE WHEN @reason='ELIGIBLE' THEN 1 ELSE 0 END AS bit) eligible,@reason reason,@remaining remainingUses,
            CASE WHEN @reason='ELIGIBLE' THEN CONVERT(varchar(30),@discount) END discountAmount,
            CASE WHEN @reason='ELIGIBLE' THEN (SELECT CONVERT(varchar(30),subtotal_amount-@discount) FROM dbo.tc_orders WHERE id=@order_id) END totalAmount,
            CASE WHEN @reason='ELIGIBLE' THEN CONVERT(varchar(23),@valid_until,126)+'Z' END validUntil FOR JSON PATH,WITHOUT_ARRAY_WRAPPER,INCLUDE_NULL_VALUES);
        COMMIT; SELECT @payload response_payload;
    END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
