
CREATE   VIEW dbo.v_refunds AS
SELECT r.id refund_id,r.order_id,o.user_id owner_id,e.title event_name,r.amount,r.status,
       r.reason,r.rejection_reason,r.created_at,r.processed_at,r.current_attempt_id,
       (SELECT COUNT(*) FROM dbo.tc_refund_tickets rt WHERE rt.refund_id=r.id) ticket_count
FROM dbo.tc_refund_obligations r JOIN dbo.tc_orders o ON o.id=r.order_id
JOIN dbo.tc_events e ON e.id=o.event_id WHERE r.purpose='CUSTOMER_REFUND';
