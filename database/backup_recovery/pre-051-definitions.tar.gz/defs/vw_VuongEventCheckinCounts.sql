CREATE   VIEW dbo.vw_VuongEventCheckinCounts AS
 SELECT o.event_id,COUNT_BIG(DISTINCT t.id) tickets_checked_in_count
 FROM dbo.tc_ticket_check_in_logs l JOIN dbo.tc_tickets t ON t.id=l.ticket_id
 JOIN dbo.tc_order_items i ON i.id=t.order_item_id JOIN dbo.vw_VuongOrders o ON o.id=i.order_id
 WHERE l.result='SUCCESS' AND l.event_id=o.event_id GROUP BY o.event_id;