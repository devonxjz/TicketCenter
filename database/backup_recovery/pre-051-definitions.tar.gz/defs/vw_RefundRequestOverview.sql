CREATE   VIEW dbo.vw_RefundRequestOverview
AS
WITH requested AS (
    SELECT rt.refund_id, COUNT_BIG(*) ticket_count, SUM(t.paid_amount) requested_amount
    FROM dbo.tc_refund_tickets rt JOIN dbo.tc_tickets t ON t.id = rt.ticket_id
    GROUP BY rt.refund_id
), attempts AS (
    SELECT refund_id, SUM(CASE WHEN status = 'SUCCEEDED' THEN amount ELSE 0 END) refunded_amount,
           SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) pending_attempts,
           SUM(CASE WHEN status = 'UNKNOWN' THEN 1 ELSE 0 END) unknown_attempts,
           SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) failed_attempts
    FROM dbo.vw_RefundAttemptLedger WHERE purpose = 'CUSTOMER_REFUND' GROUP BY refund_id
)
SELECT rr.id refund_request_id, o.user_id owner_id, o.event_id, e.organization_id,
       rr.reason_type, rr.reason, rr.request_status status, rr.created_at requested_at, rr.decided_at,
       COALESCE(q.ticket_count, 0) ticket_count, COALESCE(q.requested_amount, 0) requested_amount,
       COALESCE(a.refunded_amount, 0) refunded_amount, COALESCE(a.pending_attempts, 0) pending_attempts,
       COALESCE(a.unknown_attempts, 0) unknown_attempts, COALESCE(a.failed_attempts, 0) failed_attempts
FROM dbo.tc_refund_obligations rr JOIN dbo.tc_orders o ON o.id = rr.order_id
JOIN dbo.tc_events e ON e.id = o.event_id LEFT JOIN requested q ON q.refund_id = rr.id
LEFT JOIN attempts a ON a.refund_id = rr.id
WHERE rr.purpose = 'CUSTOMER_REFUND';
