
CREATE   PROCEDURE dbo.usp_OrderSnapshot @order_id uniqueidentifier,@checkout bit=0,@now datetime2(3)=NULL,@payload nvarchar(max) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT @payload=(SELECT LOWER(CONVERT(char(36),o.id)) orderId,o.order_code orderCode,
        LOWER(CONVERT(char(36),o.user_id)) userId,LOWER(CONVERT(char(36),o.event_id)) eventId,
        LOWER(CONVERT(char(36),o.hold_id)) holdId,o.status,CONVERT(varchar(23),h.expires_at,126)+'Z' expiresAt,
        CONVERT(varchar(30),o.subtotal_amount) subtotal,CONVERT(varchar(30),o.discount_amount) discountAmount,
        CONVERT(varchar(30),o.total_amount) totalAmount,c.code appliedCouponCode,o.version,
        JSON_QUERY((SELECT LOWER(CONVERT(char(36),i.id)) orderItemId,LOWER(CONVERT(char(36),i.zone_id)) zoneId,
            LOWER(CONVERT(char(36),i.seat_id)) seatId,i.zone_name_snapshot zoneName,i.seat_label_snapshot seatLabel,
            i.quantity,CONVERT(varchar(30),i.unit_price) unitPrice,CONVERT(varchar(30),i.unit_price*i.quantity) lineTotal
            FROM dbo.tc_order_items i WHERE i.order_id=o.id ORDER BY i.id FOR JSON PATH,INCLUDE_NULL_VALUES)) items,
        CASE WHEN @checkout=1 THEN h.status END holdStatus,
        CASE WHEN @checkout=1 THEN CASE WHEN EXISTS(SELECT 1 FROM dbo.tc_payments WHERE order_id=o.id AND status='UNKNOWN') THEN 'UNKNOWN'
            WHEN EXISTS(SELECT 1 FROM dbo.tc_payments WHERE order_id=o.id AND status='PENDING') THEN 'PAYMENT_PENDING' ELSE 'CLEAR' END END paymentResolution,
        CASE WHEN @checkout=1 THEN CAST(CASE WHEN o.status='PENDING_PAYMENT' AND h.status='ACTIVE' AND h.expires_at>@now
            AND e.status='PUBLISHED' AND @now>=e.sale_start AND @now<e.sale_end
            AND NOT EXISTS(SELECT 1 FROM dbo.tc_payments WHERE order_id=o.id AND status IN('PENDING','UNKNOWN')) THEN 1 ELSE 0 END AS bit) END canEditCoupon
        FROM dbo.tc_orders o JOIN dbo.tc_ticket_holds h ON h.id=o.hold_id JOIN dbo.tc_events e ON e.id=o.event_id
        LEFT JOIN dbo.tc_coupons c ON c.id=o.coupon_id WHERE o.id=@order_id FOR JSON PATH,WITHOUT_ARRAY_WRAPPER,INCLUDE_NULL_VALUES);
    IF @checkout=0 SET @payload=JSON_MODIFY(JSON_MODIFY(JSON_MODIFY(@payload,'$.holdStatus',NULL),'$.paymentResolution',NULL),'$.canEditCoupon',NULL);
END;
