
CREATE   TRIGGER dbo.trg_Ticket_AssignSeat ON dbo.tc_tickets AFTER INSERT,UPDATE AS
BEGIN SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted t JOIN dbo.tc_order_items i ON i.id=t.order_item_id WHERE t.seat_id IS NOT NULL AND (i.seat_id IS NULL OR t.seat_id<>i.seat_id)) THROW 51821,'Ticket seat must match issued order item',1;
 UPDATE t SET seat_id=i.seat_id FROM dbo.tc_tickets t JOIN inserted n ON n.id=t.id JOIN dbo.tc_order_items i ON i.id=t.order_item_id WHERE t.seat_id IS NULL AND i.seat_id IS NOT NULL;
END;
