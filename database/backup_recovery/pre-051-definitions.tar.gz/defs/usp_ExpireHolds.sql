
CREATE   PROCEDURE dbo.usp_ExpireHolds @batch_size int=50
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON; SET LOCK_TIMEOUT 5000;
    IF @@TRANCOUNT<>0 THROW 51310,'Facade requires autocommit',1;
    IF @batch_size NOT BETWEEN 1 AND 100 THROW 51300,'Invalid batch size',1;
    DECLARE @candidates TABLE(id uniqueidentifier PRIMARY KEY);
    INSERT @candidates SELECT TOP(@batch_size) id FROM dbo.tc_ticket_holds
        WHERE status='ACTIVE' AND expires_at<=SYSUTCDATETIME() ORDER BY expires_at,id;
    DECLARE @changes TABLE(actorId uniqueidentifier,eventId uniqueidentifier,holdId uniqueidentifier,version bigint);
    DECLARE @id uniqueidentifier,@actor uniqueidentifier,@event uniqueidentifier,@status varchar(20),@expires datetime2(3),@version bigint,@changed bit;
    DECLARE candidates CURSOR LOCAL FAST_FORWARD FOR SELECT id FROM @candidates ORDER BY id;
    OPEN candidates; FETCH NEXT FROM candidates INTO @id;
    WHILE @@FETCH_STATUS=0 BEGIN
        BEGIN TRY
            SET @changed=0;
            SELECT @actor=user_id,@event=event_id FROM dbo.tc_ticket_holds WHERE id=@id;
            BEGIN TRANSACTION;
            EXEC dbo.usp_HoldLockSelection @actor,@event,N'[]',@id,@include_active=0;
            SELECT @status=status,@expires=expires_at FROM dbo.tc_ticket_holds WHERE id=@id;
            IF @status='ACTIVE' AND @expires<=SYSUTCDATETIME() BEGIN
                EXEC dbo.usp_ReleaseTicketHold @id,@actor,'EXPIRED',@suppress_result=1;
                SELECT @actor=user_id,@event=event_id,@version=version,@changed=1 FROM dbo.tc_ticket_holds WHERE id=@id AND status='RELEASED';
            END;
            COMMIT;
            IF @changed=1 INSERT @changes VALUES(@actor,@event,@id,@version);
        END TRY BEGIN CATCH
            IF XACT_STATE()<>0 ROLLBACK;
            IF ERROR_NUMBER() NOT IN(1205,1222,51309) THROW;
        END CATCH;
        FETCH NEXT FROM candidates INTO @id;
    END;
    CLOSE candidates; DEALLOCATE candidates;
    SELECT COALESCE((SELECT LOWER(CONVERT(char(36),actorId)) actorId,LOWER(CONVERT(char(36),eventId)) eventId,
        LOWER(CONVERT(char(36),holdId)) holdId,version FROM @changes FOR JSON PATH),N'[]') changes_payload;
END;
