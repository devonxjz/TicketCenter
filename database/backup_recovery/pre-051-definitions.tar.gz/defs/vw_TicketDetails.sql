
/* View: vw_TicketDetails */
CREATE   VIEW dbo.vw_TicketDetails
AS
SELECT t.id ticket_id, o.user_id owner_id, o.id order_id, o.event_id, e.organization_id,
       e.title event_title, e.venue_name, e.venue_address, e.start_time, e.end_time,
       oi.zone_name_snapshot, oi.seat_label_snapshot, t.paid_amount, t.status, t.issued_at
FROM dbo.tc_tickets t JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id
JOIN dbo.tc_orders o ON o.id = oi.order_id JOIN dbo.tc_events e ON e.id = o.event_id;
