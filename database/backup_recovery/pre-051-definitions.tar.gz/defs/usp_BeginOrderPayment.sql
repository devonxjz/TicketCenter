
/* Stored Procedure: usp_BeginOrderPayment */
CREATE   PROCEDURE dbo.usp_BeginOrderPayment @order_id uniqueidentifier, @actor_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @lock_count bigint;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp08;
    BEGIN TRY
        DECLARE @event_id uniqueidentifier, @hold_id uniqueidentifier, @amount decimal(19,0), @payment_id uniqueidentifier,
                @txn_ref varchar(100), @now datetime2(3) = SYSUTCDATETIME();
        SELECT @event_id=event_id,@hold_id=hold_id FROM dbo.tc_orders WHERE id=@order_id AND user_id=@actor_id;
        IF @event_id IS NULL THROW 51280,'Order cannot begin payment',1;
        SELECT @lock_count=COUNT_BIG(*) FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@event_id;
        SELECT @lock_count=COUNT_BIG(*) FROM dbo.tc_ticket_holds WITH(UPDLOCK,HOLDLOCK) WHERE id=@hold_id;
        SET @now=SYSUTCDATETIME();
        SELECT @amount=o.total_amount FROM dbo.tc_orders o WITH(UPDLOCK,HOLDLOCK) JOIN dbo.tc_ticket_holds h ON h.id=o.hold_id
        WHERE o.id=@order_id AND o.user_id=@actor_id AND o.status='PENDING_PAYMENT' AND h.status='ACTIVE' AND h.expires_at>@now;
        IF @amount IS NULL THROW 51280,'Order cannot begin payment',1;
        IF NOT EXISTS(SELECT 1 FROM dbo.tc_events WHERE id=@event_id AND status='PUBLISHED' AND @now>=sale_start AND @now<sale_end) THROW 51281,'Event is unavailable for payment',1;
        IF @amount = 0 THROW 51282, 'Zero-value order must use the free completion flow', 1;
        SELECT TOP (1) @payment_id = id, @txn_ref = txn_ref FROM dbo.tc_payments WITH (UPDLOCK, HOLDLOCK)
        WHERE order_id = @order_id AND status IN ('PENDING', 'UNKNOWN') ORDER BY created_at DESC;
        IF @payment_id IS NULL BEGIN
            SET @payment_id = NEWID(); SET @txn_ref = CONCAT('PAY-', REPLACE(CONVERT(varchar(36), @payment_id), '-', ''));
            INSERT dbo.tc_payments(id, order_id, txn_ref, amount) VALUES (@payment_id, @order_id, @txn_ref, @amount);
        END;
        IF @started = 1 COMMIT TRANSACTION;
        SELECT @payment_id payment_id, @txn_ref txn_ref, @amount amount, CAST('VND' AS char(3)) currency;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp08;
        THROW;
    END CATCH
END;
