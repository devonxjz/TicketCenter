
CREATE   PROCEDURE dbo.usp_EventAuthorize
 @actor_id uniqueidentifier,@actor_version int,@admin bit,
 @organization_id uniqueidentifier OUTPUT,@event_id uniqueidentifier OUTPUT,@zone_id uniqueidentifier=NULL,@lock_authority bit=1
AS
BEGIN
 SET NOCOUNT ON;
 IF @zone_id IS NOT NULL BEGIN
  DECLARE @zone_event uniqueidentifier;
  SELECT @zone_event=event_id FROM dbo.tc_zones WHERE id=@zone_id;
  IF @zone_event IS NULL THROW 52004,'Zone not found',1;
  IF @event_id IS NOT NULL AND @event_id<>@zone_event THROW 52003,'Wrong event scope',1;
  SET @event_id=@zone_event;
 END;
 IF @event_id IS NOT NULL BEGIN
  DECLARE @owner uniqueidentifier;
  IF @lock_authority=1 SELECT @owner=organization_id FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@event_id;
  ELSE SELECT @owner=organization_id FROM dbo.tc_events WITH(READCOMMITTEDLOCK) WHERE id=@event_id;
  IF @owner IS NULL THROW 52004,'Event not found',1;
  IF @organization_id IS NOT NULL AND @organization_id<>@owner THROW 52003,'Wrong organization scope',1;
  SET @organization_id=@owner;
 END;
 -- An Event-scoped operation locks Event before retaining current authority.
 -- Unscoped/preflight checks retain no User lock before later Event discovery.
 IF @lock_authority=1 AND @event_id IS NOT NULL BEGIN
  IF NOT EXISTS(SELECT 1 FROM dbo.tc_users WITH(HOLDLOCK) WHERE id=@actor_id AND status='ACTIVE' AND auth_version=@actor_version)
   THROW 52001,'Current session is not valid',1;
 END ELSE IF NOT EXISTS(SELECT 1 FROM dbo.tc_users WITH(READCOMMITTEDLOCK) WHERE id=@actor_id AND status='ACTIVE' AND auth_version=@actor_version)
  THROW 52001,'Current session is not valid',1;
 IF @admin=1 BEGIN
  IF NOT EXISTS(SELECT 1 FROM dbo.tc_users WITH(READCOMMITTEDLOCK) WHERE id=@actor_id AND platform_role='ADMIN')
   THROW 52003,'Administrator role required',1;
 END ELSE IF @organization_id IS NOT NULL BEGIN
  IF NOT EXISTS(SELECT 1 FROM dbo.tc_organization_memberships m WITH(HOLDLOCK)
   JOIN dbo.tc_organizations o ON o.id=m.organization_id
   WHERE m.user_id=@actor_id AND m.organization_id=@organization_id AND m.role='MANAGER' AND m.active=1 AND o.status='APPROVED')
   THROW 52003,'Current manager membership required',1;
 END;
END;
