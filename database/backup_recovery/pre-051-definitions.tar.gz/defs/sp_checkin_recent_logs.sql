
CREATE   PROCEDURE dbo.sp_checkin_recent_logs
 @event_id uniqueidentifier,@staff_user_id uniqueidentifier,@limit int=20
AS
BEGIN
 SET NOCOUNT ON;
 IF @limit<1 OR @limit>100 THROW 53204,'Invalid log limit',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_events WHERE id=@event_id) THROW 53202,'Event not found',1;
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_events e JOIN dbo.tc_organization_memberships m ON m.organization_id=e.organization_id
  JOIN dbo.tc_users u ON u.id=m.user_id WHERE e.id=@event_id AND m.user_id=@staff_user_id AND u.status='ACTIVE'
  AND m.active=1 AND m.role IN('MANAGER','CHECK_IN_STAFF')) THROW 53201,'Active event staff membership required',1;
 SELECT TOP(@limit) l.id,l.ticket_id,l.result,l.scanned_at,u.full_name staff_name,
  CASE WHEN o.event_id=l.event_id THEN i.zone_name_snapshot END zone_name,
  CASE WHEN o.event_id=l.event_id THEN i.seat_label_snapshot END seat_label
 FROM dbo.tc_ticket_check_in_logs l LEFT JOIN dbo.tc_users u ON u.id=l.actor_id
 LEFT JOIN dbo.tc_tickets t ON t.id=l.ticket_id LEFT JOIN dbo.tc_order_items i ON i.id=t.order_item_id
 LEFT JOIN dbo.tc_orders o ON o.id=i.order_id
 WHERE l.event_id=@event_id ORDER BY l.scanned_at DESC,l.id;
END;
