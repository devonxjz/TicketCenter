
CREATE   PROCEDURE dbo.usp_HoldAuthorize @actor_id uniqueidentifier, @auth_version int
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS(SELECT 1 FROM dbo.tc_users WHERE id=@actor_id AND auth_version=@auth_version)
        THROW 51301,'Current session required',1;
    IF NOT EXISTS(SELECT 1 FROM dbo.tc_users WHERE id=@actor_id AND status='ACTIVE' AND email_verified_at IS NOT NULL)
        THROW 51303,'Active verified user required',1;
END;
