
CREATE   FUNCTION dbo.fn_GetEventCheckInWindow(@event_id uniqueidentifier,@now_utc datetime2(3))
RETURNS TABLE AS RETURN (
 SELECT id event_id,DATEADD(minute,-60,start_time) opens_at,end_time closes_at,
 CASE WHEN status='CANCELLED' THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END is_cancelled,
 CASE WHEN status='PUBLISHED' AND @now_utc>=DATEADD(minute,-60,start_time) AND @now_utc<end_time THEN CAST(1 AS bit) ELSE CAST(0 AS bit) END is_open
 FROM dbo.tc_events WHERE id=@event_id);
