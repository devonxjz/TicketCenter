
CREATE   VIEW dbo.vw_PaymentsToReconcile AS
 SELECT p.id,p.order_id,p.txn_ref,p.amount,p.status,p.provider_reference,p.created_at,p.captured_at,o.event_id,h.expires_at hold_expires_at
 FROM dbo.tc_payments p JOIN dbo.tc_orders o ON o.id=p.order_id JOIN dbo.tc_ticket_holds h ON h.id=o.hold_id
 WHERE p.status IN('PENDING','UNKNOWN') AND p.created_at<DATEADD(minute,-5,SYSUTCDATETIME());
