
/* Stored Procedure: usp_ApproveOrganizationRequest */
CREATE   PROCEDURE dbo.usp_ApproveOrganizationRequest
    @request_id uniqueidentifier, @actor_id uniqueidentifier, @initial_commission_policy nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp01;
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM dbo.tc_user_platform_roles WHERE user_id = @actor_id AND role = 'ADMIN')
            THROW 51201, 'Administrator role required', 1;
        DECLARE @status varchar(30), @organization_id uniqueidentifier, @applicant_id uniqueidentifier,
                @name nvarchar(200), @email nvarchar(320), @phone nvarchar(30), @description nvarchar(2000);
        SELECT @status = status, @organization_id = organization_id, @applicant_id = applicant_id,
               @name = name, @email = contact_email, @phone = contact_phone, @description = description
        FROM dbo.tc_organization_requests WITH (UPDLOCK, HOLDLOCK) WHERE id = @request_id;
        IF @status IS NULL THROW 51202, 'Organization request not found', 1;
        IF @status = 'APPROVED' BEGIN
            SELECT @organization_id organization_id, @status status;
            IF @started = 1 COMMIT TRANSACTION; RETURN;
        END;
        IF @status <> 'PENDING' THROW 51203, 'Organization request is already rejected', 1;
        DECLARE @rate decimal(7,4) = TRY_CONVERT(decimal(7,4), JSON_VALUE(@initial_commission_policy, '$.ratePercent')),
                @fixed decimal(19,0) = TRY_CONVERT(decimal(19,0), JSON_VALUE(@initial_commission_policy, '$.fixedFee')),
                @from datetime2(3) = TRY_CONVERT(datetime2(3), JSON_VALUE(@initial_commission_policy, '$.effectiveFrom')),
                @to datetime2(3) = TRY_CONVERT(datetime2(3), JSON_VALUE(@initial_commission_policy, '$.effectiveTo'));
        IF ISJSON(@initial_commission_policy) <> 1 OR @rate IS NULL OR @fixed IS NULL OR @from IS NULL OR @to IS NULL
            THROW 51204, 'Invalid initial commission policy', 1;
        SET @organization_id = NEWID();
        INSERT dbo.tc_organizations(id, name, contact_email, contact_phone, description)
        VALUES (@organization_id, @name, @email, @phone, @description);
        INSERT dbo.tc_commission_rules(organization_id, rate_percent, fixed_fee, effective_from, effective_to)
        VALUES (@organization_id, @rate, @fixed, @from, @to);
        INSERT dbo.tc_organization_memberships(user_id, organization_id, role) VALUES (@applicant_id, @organization_id, 'MANAGER');
        UPDATE dbo.tc_organization_requests SET reviewer_id = @actor_id, organization_id = @organization_id,
               status = 'APPROVED', decided_at = SYSUTCDATETIME(), rejection_reason = NULL, version = version + 1
        WHERE id = @request_id;
        INSERT dbo.tc_audit_logs(actor_id, action, aggregate_type, aggregate_id)
        VALUES (@actor_id, 'ORGANIZATION_REQUEST_APPROVED', 'ORGANIZATION_REQUEST', @request_id);
        IF @started = 1 COMMIT TRANSACTION;
        SELECT @organization_id organization_id, CAST('APPROVED' AS varchar(30)) status;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp01;
        THROW;
    END CATCH
END;
