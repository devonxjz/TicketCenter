CREATE   VIEW dbo.vw_EventCancellationExceptions
AS
    SELECT o.event_id, CAST('USED_TICKET' AS varchar(40)) exception_type,
           t.id exception_id, o.id order_id, t.status
    FROM dbo.tc_tickets t
    JOIN dbo.tc_order_items oi ON oi.id = t.order_item_id
    JOIN dbo.tc_orders o ON o.id = oi.order_id
    JOIN dbo.tc_events e ON e.id = o.event_id
    WHERE e.status = 'CANCELLED' AND t.status = 'USED'
    UNION ALL
    SELECT o.event_id, CAST('REFUND_RESULT' AS varchar(40)),
           r.id, o.id, r.status
    FROM dbo.tc_refund_transfer_logs r
    JOIN dbo.tc_refund_obligations rr ON rr.id = r.refund_id
    JOIN dbo.tc_orders o ON o.id = rr.order_id
    JOIN dbo.tc_events e ON e.id = o.event_id
    WHERE e.status = 'CANCELLED' AND rr.reason_type = 'EVENT_CANCELLATION'
      AND r.status IN ('FAILED', 'UNKNOWN');
