
/* Stored Procedure: usp_RequestTicketRefund */
CREATE   PROCEDURE dbo.usp_RequestTicketRefund
    @order_id uniqueidentifier,
    @actor_id uniqueidentifier,
    @ticket_ids nvarchar(max),
    @reason_type varchar(30),
    @reason nvarchar(2000)
AS
BEGIN
    SET NOCOUNT ON;
    IF @reason_type <> 'CUSTOMER_REQUEST'
        THROW 52620, 'Only CUSTOMER_REQUEST is accepted from a buyer', 1;
    EXEC dbo.usp_CreateRefundRequest
        @order_id = @order_id, @actor_id = @actor_id, @ticket_ids = @ticket_ids, @reason = @reason;
END;
