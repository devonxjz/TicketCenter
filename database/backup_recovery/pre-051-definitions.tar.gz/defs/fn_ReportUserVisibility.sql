
CREATE   FUNCTION dbo.fn_ReportUserVisibility(@user uniqueidentifier)
RETURNS TABLE WITH SCHEMABINDING AS RETURN
 SELECT 1 permitted WHERE
 COALESCE(IS_MEMBER('db_owner'),0)=1 OR USER_NAME()=N'dbo'
 OR COALESCE(IS_ROLEMEMBER('tc_auth'),0)=1 OR COALESCE(IS_ROLEMEMBER('tc_platform_admin'),0)=1
 OR COALESCE(IS_ROLEMEMBER('tc_worker'),0)=1 OR COALESCE(IS_ROLEMEMBER('tc_checkin'),0)=1
 OR @user=TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'actor_id'))
 OR (COALESCE(IS_ROLEMEMBER('tc_manager'),0)=1 AND EXISTS(
 SELECT 1 FROM dbo.tc_organization_memberships member JOIN dbo.tc_organization_memberships manager ON manager.organization_id=member.organization_id
 WHERE member.user_id=@user AND member.active=1 AND manager.user_id=TRY_CONVERT(uniqueidentifier,SESSION_CONTEXT(N'actor_id')) AND manager.role='MANAGER' AND manager.active=1));
