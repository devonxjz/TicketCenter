
CREATE   PROCEDURE dbo.usp_CreateHoldRequest
    @actor_id uniqueidentifier,@auth_version int,@request_key uniqueidentifier,@fingerprint varchar(64),
    @event_id uniqueidentifier,@selections nvarchar(max)
AS
BEGIN
    SET NOCOUNT ON;
    EXEC dbo.usp_HoldMutation @actor_id,@auth_version,@request_key,@fingerprint,'CREATE',@event_id,@selections;
END;
