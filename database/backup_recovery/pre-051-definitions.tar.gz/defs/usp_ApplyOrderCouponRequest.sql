
CREATE   PROCEDURE dbo.usp_ApplyOrderCouponRequest
    @actor_id uniqueidentifier,@auth_version int,@key uniqueidentifier,@fingerprint varchar(64),@order_id uniqueidentifier,@coupon_code nvarchar(80)=NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF @@TRANCOUNT<>0 THROW 51410,'Facade owns transaction',1;
    BEGIN TRANSACTION;
    BEGIN TRY
        DECLARE @payload nvarchar(max),@saved_fingerprint varchar(200),@saved_target uniqueidentifier,@event_id uniqueidentifier,@hold_id uniqueidentifier,
            @owner_id uniqueidentifier,@old_coupon uniqueidentifier,@new_coupon uniqueidentifier,@locked_new uniqueidentifier,@org uniqueidentifier,
            @now datetime2(3),@expires datetime2(3),@reason varchar(30),@discount decimal(19,0)=0,@remaining int,@valid_until datetime2(3);
        SELECT @payload=response_payload,@saved_fingerprint=fingerprint,@saved_target=target_id FROM dbo.tc_request_idempotency WITH(UPDLOCK,HOLDLOCK)
            WHERE actor_id=@actor_id AND operation='ORDER_MUTATION' AND idempotency_key=CONVERT(varchar(36),@key);
        SELECT @event_id=event_id,@hold_id=hold_id,@owner_id=user_id FROM dbo.tc_orders WHERE id=@order_id;
        EXEC dbo.usp_HoldLockSelection @actor_id,@event_id,N'[]',@hold_id,@include_active=0;
        EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
        IF @owner_id IS NULL THROW 51404,'Order not found',1;
        IF @owner_id<>@actor_id THROW 51403,'Order owner required',1;
        IF @payload IS NOT NULL BEGIN
            IF @saved_fingerprint<>@fingerprint OR @saved_target<>@order_id THROW 51408,'Changed request for key',1;
            SELECT @expires=expires_at FROM dbo.tc_ticket_holds WHERE id=@hold_id; COMMIT; SELECT @payload response_payload,CAST(1 AS bit) replayed,CONVERT(varchar(36),@hold_id) hold_id,CONVERT(varchar(23),@expires,126)+'Z' expires_at; RETURN;
        END;
        SELECT @old_coupon=coupon_id FROM dbo.tc_orders WHERE id=@order_id;
        SELECT @org=organization_id FROM dbo.tc_events WHERE id=@event_id;
        SELECT @old_coupon=coupon_id FROM dbo.tc_orders WHERE id=@order_id;
        SELECT @new_coupon=id FROM dbo.tc_coupons WHERE organization_id=@org AND code=@coupon_code;
        SET @locked_new=@new_coupon;
        EXEC dbo.usp_OrderLockCoupons @old_coupon,@new_coupon;
        DECLARE @quota_dummy int;
        SELECT @quota_dummy=COUNT(*) FROM dbo.tc_coupon_redemptions WITH(UPDLOCK,HOLDLOCK) WHERE coupon_id=@new_coupon AND status IN('RESERVED','CONSUMED');
        IF @coupon_code IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.tc_coupons WHERE id=@locked_new AND organization_id=@org AND code=@coupon_code)
            BEGIN IF @locked_new IS NOT NULL THROW 51309,'Coupon preflight changed',1; END;
        IF EXISTS(SELECT 1 FROM dbo.tc_payments WITH(UPDLOCK,HOLDLOCK) WHERE order_id=@order_id AND status IN('PENDING','UNKNOWN'))
            THROW 51407,'Payment unresolved',1;
        SET @now=SYSUTCDATETIME();
        SELECT @expires=expires_at FROM dbo.tc_ticket_holds WHERE id=@hold_id AND status='ACTIVE';
        IF @expires IS NULL OR @expires<=@now OR NOT EXISTS(SELECT 1 FROM dbo.tc_orders WHERE id=@order_id AND status='PENDING_PAYMENT')
            THROW 51406,'Order is terminal or expired',1;
        IF NOT EXISTS(SELECT 1 FROM dbo.tc_events WHERE id=@event_id AND status='PUBLISHED' AND @now>=sale_start AND @now<sale_end)
            THROW 51406,'Event is not on sale',1;
        IF @coupon_code IS NOT NULL BEGIN
            EXEC dbo.usp_OrderCouponDecision @order_id,@coupon_code,@now,@new_coupon OUTPUT,@reason OUTPUT,@discount OUTPUT,@remaining OUTPUT,@valid_until OUTPUT;
            IF ISNULL(@new_coupon,'00000000-0000-0000-0000-000000000000')<>ISNULL(@locked_new,'00000000-0000-0000-0000-000000000000') THROW 51309,'Coupon preflight changed',1;
            IF @reason<>'ELIGIBLE' BEGIN
                DECLARE @error nvarchar(2048)=CONCAT('COUPON_',@reason);
                THROW 51405,@error,1;
            END;
        END;
        IF @old_coupon<>@new_coupon OR @old_coupon IS NULL AND @new_coupon IS NOT NULL OR @old_coupon IS NOT NULL AND @new_coupon IS NULL BEGIN
            IF EXISTS(SELECT 1 FROM dbo.tc_coupon_redemptions WHERE order_id=@order_id)
                UPDATE dbo.tc_coupon_redemptions SET coupon_id=COALESCE(@new_coupon,coupon_id),status=CASE WHEN @new_coupon IS NULL THEN 'RELEASED' ELSE 'RESERVED' END,
                    reserved_at=CASE WHEN @new_coupon IS NULL THEN reserved_at ELSE @now END,expires_at=CASE WHEN @new_coupon IS NULL THEN expires_at ELSE @expires END,
                    consumed_at=NULL,released_at=CASE WHEN @new_coupon IS NULL THEN @now ELSE NULL END WHERE order_id=@order_id;
            ELSE IF @new_coupon IS NOT NULL INSERT dbo.tc_coupon_redemptions(coupon_id,order_id,reserved_at,expires_at) VALUES(@new_coupon,@order_id,@now,@expires);
            UPDATE dbo.tc_orders SET coupon_id=@new_coupon,discount_amount=@discount,total_amount=subtotal_amount-@discount,version=version+1 WHERE id=@order_id;
        END;
        SELECT @payload=(SELECT LOWER(CONVERT(char(36),o.id)) orderId,c.code appliedCouponCode,CONVERT(varchar(30),o.subtotal_amount) subtotal,
            CONVERT(varchar(30),o.discount_amount) discountAmount,CONVERT(varchar(30),o.total_amount) totalAmount,o.version
            FROM dbo.tc_orders o LEFT JOIN dbo.tc_coupons c ON c.id=o.coupon_id WHERE o.id=@order_id FOR JSON PATH,WITHOUT_ARRAY_WRAPPER,INCLUDE_NULL_VALUES);
        INSERT dbo.tc_request_idempotency(actor_id,operation,idempotency_key,target_id,fingerprint,response_payload,expires_at)
            VALUES(@actor_id,'ORDER_MUTATION',CONVERT(varchar(36),@key),@order_id,@fingerprint,@payload,DATEADD(second,600,@now));
        COMMIT; SELECT @payload response_payload,CAST(0 AS bit) replayed,CONVERT(varchar(36),@hold_id) hold_id,CONVERT(varchar(23),@expires,126)+'Z' expires_at;
    END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
