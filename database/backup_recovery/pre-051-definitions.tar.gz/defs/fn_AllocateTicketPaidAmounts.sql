
/* Function: fn_AllocateTicketPaidAmounts */
CREATE   FUNCTION dbo.fn_AllocateTicketPaidAmounts(@order_id uniqueidentifier)
RETURNS TABLE
AS RETURN (
    WITH n AS (SELECT 1 n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
               UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8),
    units AS (
        SELECT oi.id order_item_id, n.n ticket_ordinal, oi.unit_price,
               o.subtotal_amount, o.discount_amount, o.total_amount,
               CAST(CASE WHEN o.subtotal_amount = 0 THEN 0
                    ELSE o.discount_amount * oi.unit_price / o.subtotal_amount END AS decimal(38,12)) raw_discount
        FROM dbo.tc_order_items oi JOIN dbo.tc_orders o ON o.id = oi.order_id
        JOIN n ON n.n <= oi.quantity WHERE o.id = @order_id
    ), base AS (
        SELECT *, FLOOR(raw_discount) base_discount, raw_discount - FLOOR(raw_discount) remainder,
               SUM(FLOOR(raw_discount)) OVER () allocated_base
        FROM units
    ), ranked AS (
        SELECT *, ROW_NUMBER() OVER (ORDER BY remainder DESC, order_item_id, ticket_ordinal) remainder_rank
        FROM base
    )
    SELECT order_item_id, ticket_ordinal, unit_price original_amount,
           CAST(base_discount + CASE WHEN remainder_rank <= discount_amount - allocated_base THEN 1 ELSE 0 END AS decimal(19,0)) discount_amount,
           CAST(unit_price - base_discount - CASE WHEN remainder_rank <= discount_amount - allocated_base THEN 1 ELSE 0 END AS decimal(19,0)) paid_amount
    FROM ranked
);
