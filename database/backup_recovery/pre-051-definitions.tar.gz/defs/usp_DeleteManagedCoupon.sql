
CREATE   PROCEDURE dbo.usp_DeleteManagedCoupon
    @coupon_id uniqueidentifier, @actor_id uniqueidentifier, @auth_version int
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        DECLARE @organization_id uniqueidentifier;
        SELECT @organization_id=organization_id FROM dbo.tc_coupons WITH (UPDLOCK,HOLDLOCK) WHERE id=@coupon_id;
        IF @organization_id IS NULL THROW 51523,'Coupon not found',1;
        EXEC dbo.usp_CouponAdminAuthorize @actor_id,@auth_version,@organization_id;
        IF EXISTS(SELECT 1 FROM dbo.tc_coupon_redemptions WITH (UPDLOCK,HOLDLOCK) WHERE coupon_id=@coupon_id)
           OR EXISTS(SELECT 1 FROM dbo.tc_orders WITH (UPDLOCK,HOLDLOCK) WHERE coupon_id=@coupon_id)
            THROW 51524,'Coupon is in use',1;
        DELETE dbo.tc_coupons WHERE id=@coupon_id AND organization_id=@organization_id;
        COMMIT TRANSACTION;
    END TRY BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
