
CREATE   PROCEDURE dbo.usp_EventRead
 @actor_id uniqueidentifier,@actor_version int,@admin bit=0,@kind varchar(30),
 @organization_id uniqueidentifier=NULL,@event_id uniqueidentifier=NULL,@zone_id uniqueidentifier=NULL,
 @status varchar(30)=NULL,@page int=1,@page_size int=20
AS
BEGIN
 SET NOCOUNT ON;
 IF @page<1 OR @page_size<1 OR @page_size>100 OR CONVERT(bigint,@page-1)*@page_size>1000000 THROW 52000,'Invalid page',1;
 IF @status IS NOT NULL AND @status NOT IN('DRAFT','PENDING_APPROVAL','REJECTED','PUBLISHED','CANCELLED') THROW 52000,'Invalid status',1;
 EXEC dbo.usp_EventAuthorize @actor_id,@actor_version,@admin,@organization_id OUTPUT,@event_id OUTPUT,@zone_id;
 IF @kind='DETAIL' BEGIN SET @status=NULL;SET @page=1;SET @page_size=1;END;
 IF @kind='AUTHORIZE' BEGIN
  SELECT @organization_id organization_id,@event_id event_id; RETURN;
 END;
 IF @kind='COVER_CONTEXT' BEGIN
  SELECT organization_id,status,version,event_image_public_id,COALESCE(event_image,cover_image_url) FROM dbo.tc_events WHERE id=@event_id; RETURN;
 END;
 IF @kind='ORGANIZATIONS' BEGIN
  SELECT CONCAT('{"data":',COALESCE((SELECT LOWER(CONVERT(varchar(36),o.id)) organizationId,o.name FROM dbo.tc_organizations o
   JOIN dbo.tc_organization_memberships m ON m.organization_id=o.id
   WHERE m.user_id=@actor_id AND m.active=1 AND m.role='MANAGER' AND o.status='APPROVED'
   ORDER BY o.name,o.id FOR JSON PATH),'[]'),'}') json; RETURN;
 END;
 IF @kind='RULES' BEGIN
  IF @admin<>1 OR @event_id IS NULL THROW 52003,'Admin event scope required',1;
  SELECT CONCAT('{"data":',COALESCE((SELECT LOWER(CONVERT(varchar(36),r.id)) commissionRuleId,CONVERT(varchar(30),r.rate_percent) ratePercent,
   CONVERT(varchar(40),r.fixed_fee) fixedFee,CONVERT(varchar(30),r.effective_from,126)+'Z' effectiveFrom,
   CONVERT(varchar(30),r.effective_to,126)+'Z' effectiveTo FROM dbo.tc_commission_rules r
   JOIN dbo.tc_events e ON e.organization_id=r.organization_id
   WHERE e.id=@event_id AND r.effective_from<=SYSUTCDATETIME() AND r.effective_to>SYSUTCDATETIME()
   AND r.effective_from<=e.start_time AND r.effective_to>e.start_time ORDER BY r.effective_from,r.id FOR JSON PATH),'[]'),'}') json; RETURN;
 END;
 IF @kind='LAYOUT' BEGIN
  IF @event_id IS NULL THROW 52000,'Event required',1;
  SELECT CONCAT('{"data":',COALESCE((SELECT LOWER(CONVERT(varchar(36),z.zone_id)) zoneId,LOWER(CONVERT(varchar(36),z.event_id)) eventId,z.name,z.type zoneType,
   CONVERT(varchar(40),z.price) basePrice,z.capacity totalCapacity,z.held_quantity heldQuantity,z.sold_quantity soldQuantity,
   z.available_quantity availableSeats,JSON_QUERY((SELECT LOWER(CONVERT(varchar(36),s.id)) seatId,s.row_name rowName,s.seat_number seatNumber,
    s.label seatLabel,s.status FROM dbo.tc_seats s WHERE s.zone_id=z.zone_id ORDER BY LEN(s.row_name),s.row_name,s.seat_number,s.id FOR JSON PATH)) seats
   FROM dbo.vw_ZoneInventory z WHERE z.event_id=@event_id ORDER BY z.name,z.zone_id FOR JSON PATH),'[]'),'}') json; RETURN;
 END;
 IF @kind NOT IN('LIST','DETAIL') THROW 52000,'Invalid read operation',1;
 IF @admin=0 AND @organization_id IS NULL THROW 52003,'Organization scope required',1;
 DECLARE @total bigint=(SELECT COUNT_BIG(*) FROM dbo.tc_events WHERE (@admin=1 OR organization_id=@organization_id)
   AND (@status IS NULL OR status=@status) AND (@event_id IS NULL OR id=@event_id));
 IF @kind='DETAIL' AND @event_id IS NULL THROW 52000,'Event required',1;
 DECLARE @data nvarchar(max)=(SELECT LOWER(CONVERT(varchar(36),e.id)) eventId,LOWER(CONVERT(varchar(36),e.organization_id)) organizationId,o.name organizationName,
  LOWER(CONVERT(varchar(36),e.category_id)) categoryId,c.name category,e.title,e.description,e.venue_name venueName,e.venue_address venueAddress,
  COALESCE(e.event_image,e.cover_image_url) coverImageUrl,e.status,e.rejection_reason rejectionReason,e.version,
  CONVERT(varchar(30),e.sale_start,126)+'Z' saleStartTime,CONVERT(varchar(30),e.sale_end,126)+'Z' saleEndTime,
  CONVERT(varchar(30),e.start_time,126)+'Z' startTime,CONVERT(varchar(30),e.end_time,126)+'Z' endTime,
  CONVERT(varchar(30),e.created_at,126)+'Z' createdAt,
  (SELECT COUNT_BIG(*) FROM dbo.tc_zones z WHERE z.event_id=e.id) totalZones,
  COALESCE((SELECT SUM(CONVERT(bigint,capacity)) FROM dbo.vw_ZoneInventory z WHERE z.event_id=e.id),0) totalCapacity
  FROM dbo.tc_events e JOIN dbo.tc_organizations o ON o.id=e.organization_id JOIN dbo.tc_event_categories c ON c.id=e.category_id
  WHERE (@admin=1 OR e.organization_id=@organization_id) AND (@status IS NULL OR e.status=@status)
  AND (@event_id IS NULL OR e.id=@event_id) ORDER BY e.created_at DESC,e.id
  OFFSET (@page-1)*@page_size ROWS FETCH NEXT @page_size ROWS ONLY FOR JSON PATH,INCLUDE_NULL_VALUES);
 IF @kind='DETAIL' BEGIN
  IF JSON_QUERY(@data,'$[0]') IS NULL THROW 52004,'Event no longer exists',1;
  SELECT CONCAT('{"data":',JSON_QUERY(@data,'$[0]'),'}') json;
 END;
 ELSE SELECT CONCAT('{"data":',COALESCE(@data,'[]'),',"page":',@page,',"pageSize":',@page_size,',"total":',@total,
  ',"totalPages":',@total/@page_size+CASE WHEN @total%@page_size=0 THEN 0 ELSE 1 END,'}') json;
END;
