
CREATE   PROCEDURE dbo.sp_refund_approve @refund_id uniqueidentifier,@admin_user_id uniqueidentifier,
 @admin_note nvarchar(500)=NULL,@idempotency_key uniqueidentifier,@expected_auth_version int
AS BEGIN SET NOCOUNT ON;
 EXEC dbo.sp_admin_refund_decide @refund_id,@admin_user_id,@expected_auth_version,'APPROVE',@admin_note,NULL,@idempotency_key;
END;
