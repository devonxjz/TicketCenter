
CREATE   PROCEDURE dbo.usp_AddMember @organization_id uniqueidentifier,@actor_id uniqueidentifier,@user_id uniqueidentifier,@role varchar(30)
AS BEGIN SET NOCOUNT ON; SET XACT_ABORT ON;
 BEGIN TRY BEGIN TRANSACTION;
 DECLARE @lock_count bigint;
 SELECT @lock_count=COUNT_BIG(*) FROM dbo.tc_organizations WITH(UPDLOCK,HOLDLOCK) WHERE id=@organization_id;
 EXEC dbo.usp_RequireOrganizationManager @actor_id,@organization_id;
 IF @role IS NULL OR @role NOT IN('MANAGER','CHECK_IN_STAFF') THROW 51816,'Invalid organization role',1;
 EXEC dbo.usp_RequireActiveMember @user_id;
 INSERT dbo.tc_organization_memberships(user_id,organization_id,role,active) VALUES(@user_id,@organization_id,@role,1);
 INSERT dbo.tc_audit_logs(actor_id,action,aggregate_type,aggregate_id,detail) VALUES(@actor_id,'MEMBER_ADDED','ORGANIZATION',@organization_id,CONVERT(varchar(36),@user_id));
 COMMIT;
 END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
