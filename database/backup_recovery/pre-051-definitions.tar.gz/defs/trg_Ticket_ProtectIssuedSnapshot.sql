
/* Trigger: trg_Ticket_ProtectIssuedSnapshot */
CREATE   TRIGGER dbo.trg_Ticket_ProtectIssuedSnapshot ON dbo.tc_tickets
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM inserted i JOIN deleted d ON d.id = i.id
        WHERE i.order_item_id <> d.order_item_id OR i.ticket_code <> d.ticket_code
           OR i.qr_secret_hash <> d.qr_secret_hash OR i.paid_amount <> d.paid_amount
           OR i.issued_at <> d.issued_at
    ) THROW 51108, 'Issued ticket snapshot is immutable', 1;
END;
