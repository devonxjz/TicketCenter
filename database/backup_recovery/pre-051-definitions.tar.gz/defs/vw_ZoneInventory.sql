
/* View: vw_ZoneInventory */
CREATE   VIEW dbo.vw_ZoneInventory
AS
WITH seated AS (
    SELECT zone_id, COUNT_BIG(*) capacity,
           SUM(CASE WHEN status = 'HELD' THEN 1 ELSE 0 END) held,
           SUM(CASE WHEN status = 'SOLD' THEN 1 ELSE 0 END) sold,
           SUM(CASE WHEN status = 'AVAILABLE' THEN 1 ELSE 0 END) available
    FROM dbo.tc_seats GROUP BY zone_id
)
SELECT z.id zone_id, z.event_id, e.organization_id, z.name, z.type, z.price,
       CASE WHEN z.type = 'SEATED' THEN COALESCE(s.capacity, 0) ELSE z.capacity END capacity,
       CASE WHEN z.type = 'SEATED' THEN COALESCE(s.held, 0) ELSE z.held_quantity END held_quantity,
       CASE WHEN z.type = 'SEATED' THEN COALESCE(s.sold, 0) ELSE z.sold_quantity END sold_quantity,
       CASE WHEN z.type = 'SEATED' THEN COALESCE(s.available, 0)
            ELSE z.capacity - z.held_quantity - z.sold_quantity END available_quantity
FROM dbo.tc_zones z
JOIN dbo.tc_events e ON e.id = z.event_id
LEFT JOIN seated s ON s.zone_id = z.id;
