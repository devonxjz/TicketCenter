
CREATE   VIEW dbo.vw_PaymentRuntimeDetails AS
 SELECT p.id payment_id,p.order_id,o.user_id,p.txn_ref,p.amount,p.currency,
        p.status payment_status,o.status order_status,o.total_amount,p.captured_at AS paid_at,
        p.created_at,o.order_code,h.expires_at
 FROM dbo.tc_payments p JOIN dbo.tc_orders o ON o.id=p.order_id
 JOIN dbo.tc_ticket_holds h ON h.id=o.hold_id;
