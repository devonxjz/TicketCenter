
CREATE   VIEW dbo.v_refundable_ticket_options AS
SELECT o.id order_id,o.user_id owner_id,t.id ticket_id,t.ticket_code,i.zone_name_snapshot,
       i.seat_label_snapshot,t.paid_amount,t.status,
       CAST(CASE WHEN EXISTS(SELECT 1 FROM dbo.tc_refund_tickets rt WHERE rt.ticket_id=t.id AND rt.is_open=1)
         THEN 1 ELSE 0 END AS bit) has_open_refund
FROM dbo.tc_tickets t JOIN dbo.tc_order_items i ON i.id=t.order_item_id
JOIN dbo.tc_orders o ON o.id=i.order_id;
