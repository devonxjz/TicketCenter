
CREATE   FUNCTION dbo.fn_CalculateCommission(@remaining_amount decimal(19,0),@rate_percent decimal(12,4),@fixed_fee decimal(19,0))
RETURNS decimal(19,0) AS
BEGIN
 IF @remaining_amount IS NULL OR @rate_percent IS NULL OR @fixed_fee IS NULL OR @remaining_amount<0 OR @rate_percent<0 OR @rate_percent>100 OR @fixed_fee<0 RETURN NULL;
 IF @remaining_amount=0 RETURN 0;
 DECLARE @fee decimal(38,4)=ROUND(CAST(@remaining_amount AS decimal(23,0))*@rate_percent/100,0)+@fixed_fee;
 RETURN CONVERT(decimal(19,0),CASE WHEN @fee>@remaining_amount THEN @remaining_amount ELSE @fee END);
END;
