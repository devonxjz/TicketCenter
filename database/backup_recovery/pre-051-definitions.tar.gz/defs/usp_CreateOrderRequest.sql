
CREATE   PROCEDURE dbo.usp_CreateOrderRequest
    @actor_id uniqueidentifier,@auth_version int,@key uniqueidentifier,@fingerprint varchar(64),@hold_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF @@TRANCOUNT<>0 THROW 51410,'Facade owns transaction',1;
    BEGIN TRANSACTION;
    BEGIN TRY
        DECLARE @payload nvarchar(max),@saved_fingerprint varchar(200),@saved_target uniqueidentifier,
            @event_id uniqueidentifier,@owner_id uniqueidentifier,@order_id uniqueidentifier,@now datetime2(3),@expires datetime2(3),@subtotal decimal(19,0);
        SELECT @payload=response_payload,@saved_fingerprint=fingerprint,@saved_target=target_id FROM dbo.tc_request_idempotency WITH(UPDLOCK,HOLDLOCK)
            WHERE actor_id=@actor_id AND operation='ORDER_MUTATION' AND idempotency_key=CONVERT(varchar(36),@key);
        SELECT @event_id=event_id,@owner_id=user_id FROM dbo.tc_ticket_holds WHERE id=@hold_id;
        EXEC dbo.usp_HoldLockSelection @actor_id,@event_id,N'[]',@hold_id,@include_active=0;
        EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
        IF @owner_id IS NOT NULL AND @owner_id<>@actor_id THROW 51403,'Hold owner required',1;
        IF @owner_id IS NULL THROW 51400,'Hold not found',1;
        IF EXISTS(SELECT 1 FROM dbo.tc_orders WHERE hold_id=@hold_id AND user_id<>@actor_id) THROW 51403,'Order owner required',1;
        IF @payload IS NOT NULL BEGIN
            IF @saved_fingerprint<>@fingerprint OR @saved_target<>@hold_id THROW 51408,'Changed request for key',1;
            SELECT @expires=expires_at FROM dbo.tc_ticket_holds WHERE id=@hold_id;
            COMMIT;
            SELECT @payload response_payload,CAST(1 AS bit) replayed,CONVERT(varchar(36),@hold_id) hold_id,CONVERT(varchar(23),@expires,126)+'Z' expires_at;
            RETURN;
        END;
        SELECT @order_id=id FROM dbo.tc_orders WITH(UPDLOCK,HOLDLOCK) WHERE hold_id=@hold_id;
        DECLARE @existing_coupon uniqueidentifier,@payment_dummy int;
        SELECT @existing_coupon=coupon_id FROM dbo.tc_orders WHERE id=@order_id;
        EXEC dbo.usp_OrderLockCoupons @existing_coupon,NULL;
        SELECT @payment_dummy=1 FROM dbo.tc_payments WITH(UPDLOCK,HOLDLOCK) WHERE order_id=@order_id;
        IF EXISTS(SELECT 1 FROM dbo.tc_payments WHERE order_id=@order_id AND status IN('PENDING','UNKNOWN')) THROW 51407,'Payment unresolved',1;
        SET @now=SYSUTCDATETIME();
        SELECT @expires=expires_at FROM dbo.tc_ticket_holds WHERE id=@hold_id AND status='ACTIVE';
        IF @expires IS NULL OR @expires<=@now THROW 51400,'Active unexpired Hold required',1;
        IF NOT EXISTS(SELECT 1 FROM dbo.tc_events WHERE id=@event_id AND status='PUBLISHED' AND @now>=sale_start AND @now<sale_end)
            THROW 51406,'Event is not on sale',1;
        SELECT @order_id=id FROM dbo.tc_orders WITH(UPDLOCK,HOLDLOCK) WHERE hold_id=@hold_id;
        IF @order_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM dbo.tc_orders WHERE id=@order_id AND user_id=@actor_id AND status='PENDING_PAYMENT')
            THROW 51406,'Order is terminal',1;
        IF @order_id IS NULL BEGIN
            SELECT @subtotal=SUM(unit_price*quantity) FROM dbo.tc_ticket_hold_items WHERE hold_id=@hold_id;
            IF @subtotal IS NULL THROW 51400,'Hold has no items',1;
            SET @order_id=NEWID();
            INSERT dbo.tc_orders(id,user_id,event_id,hold_id,order_code,subtotal_amount,discount_amount,total_amount)
                VALUES(@order_id,@actor_id,@event_id,@hold_id,CONCAT('ORD-',REPLACE(CONVERT(varchar(36),@order_id),'-','')),@subtotal,0,@subtotal);
            INSERT dbo.tc_order_items(order_id,zone_id,seat_id,quantity,unit_price,zone_name_snapshot,seat_label_snapshot)
                SELECT @order_id,i.zone_id,i.seat_id,i.quantity,i.unit_price,z.name,s.label
                FROM dbo.tc_ticket_hold_items i JOIN dbo.tc_zones z ON z.id=i.zone_id LEFT JOIN dbo.tc_seats s ON s.id=i.seat_id WHERE i.hold_id=@hold_id;
        END;
        EXEC dbo.usp_OrderSnapshot @order_id,@payload=@payload OUTPUT;
        INSERT dbo.tc_request_idempotency(actor_id,operation,idempotency_key,target_id,fingerprint,response_payload,expires_at)
            VALUES(@actor_id,'ORDER_MUTATION',CONVERT(varchar(36),@key),@hold_id,@fingerprint,@payload,DATEADD(second,600,@now));
        COMMIT;
        SELECT @payload response_payload,CAST(0 AS bit) replayed,CONVERT(varchar(36),@hold_id) hold_id,CONVERT(varchar(23),@expires,126)+'Z' expires_at;
    END TRY BEGIN CATCH IF XACT_STATE()<>0 ROLLBACK; THROW; END CATCH;
END;
