
CREATE   VIEW dbo.vw_BuyerOrderItems AS
SELECT oi.order_id, oi.id, oi.zone_name_snapshot, oi.seat_label_snapshot,
       oi.quantity, oi.unit_price, oi.quantity * oi.unit_price AS line_total
FROM dbo.tc_order_items oi
JOIN dbo.tc_orders o ON o.id = oi.order_id;
