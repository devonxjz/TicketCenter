
-- it returns no personal data and has no direct runtime EXECUTE grant.
CREATE   PROCEDURE dbo.usp_RequireActiveMember @user_id uniqueidentifier WITH EXECUTE AS OWNER
AS BEGIN SET NOCOUNT ON;
 IF NOT EXISTS(SELECT 1 FROM dbo.tc_users WHERE id=@user_id AND status='ACTIVE') THROW 51817,'Active member required',1;
END;
