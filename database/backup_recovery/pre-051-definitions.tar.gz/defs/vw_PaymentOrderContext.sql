
CREATE   VIEW dbo.vw_PaymentOrderContext AS
 SELECT o.id order_id,o.user_id,o.order_code,o.total_amount,o.status order_status,
        h.expires_at,h.status hold_status,e.status event_status
 FROM dbo.tc_orders o JOIN dbo.tc_ticket_holds h ON h.id=o.hold_id
 JOIN dbo.tc_events e ON e.id=o.event_id;
