CREATE   VIEW dbo.vw_FailedCompensationAttempts
AS
    SELECT DISTINCT r.payment_id, r.order_id
    FROM dbo.vw_RefundAttemptLedger r
    WHERE r.purpose = 'PAYMENT_COMPENSATION' AND r.status = 'FAILED'
      AND NOT EXISTS (
          SELECT 1 FROM dbo.vw_RefundAttemptLedger active
          WHERE active.payment_id = r.payment_id AND active.purpose = 'PAYMENT_COMPENSATION'
            AND active.status IN ('PENDING', 'UNKNOWN', 'SUCCEEDED'));
