
CREATE   PROCEDURE dbo.usp_HoldLockSelection
    @actor_id uniqueidentifier, @event_id uniqueidentifier, @selections nvarchar(max), @target_hold uniqueidentifier=NULL,
    @include_active bit=1
AS
BEGIN
    SET NOCOUNT ON;
    IF @@TRANCOUNT=0 THROW 51310,'Transaction required',1;
    DECLARE @events TABLE(id uniqueidentifier PRIMARY KEY);
    INSERT @events SELECT @event_id WHERE @event_id IS NOT NULL;
    INSERT @events SELECT event_id FROM dbo.tc_ticket_holds
        WHERE (@include_active=1 AND user_id=@actor_id AND status='ACTIVE' OR id=@target_hold)
          AND event_id NOT IN(SELECT id FROM @events) GROUP BY event_id;
    DECLARE @id uniqueidentifier,@dummy int;
    DECLARE event_locks CURSOR LOCAL FAST_FORWARD FOR SELECT id FROM @events ORDER BY id;
    OPEN event_locks; FETCH NEXT FROM event_locks INTO @id;
    WHILE @@FETCH_STATUS=0 BEGIN
        SELECT @dummy=1 FROM dbo.tc_events WITH(UPDLOCK,HOLDLOCK) WHERE id=@id;
        FETCH NEXT FROM event_locks INTO @id;
    END;
    CLOSE event_locks; DEALLOCATE event_locks;
    SELECT @dummy=1 FROM dbo.tc_users WITH(UPDLOCK,HOLDLOCK) WHERE id=@actor_id;
    IF @include_active=1 AND EXISTS(SELECT 1 FROM dbo.tc_ticket_holds WHERE user_id=@actor_id AND status='ACTIVE'
        AND event_id NOT IN(SELECT id FROM @events)) THROW 51309,'Hold preflight changed; retry transaction',1;
    DECLARE @holds TABLE(id uniqueidentifier PRIMARY KEY);
    INSERT @holds SELECT id FROM dbo.tc_ticket_holds WHERE @include_active=1 AND user_id=@actor_id AND status='ACTIVE' OR id=@target_hold;
    DECLARE hold_locks CURSOR LOCAL FAST_FORWARD FOR SELECT id FROM @holds ORDER BY id;
    OPEN hold_locks; FETCH NEXT FROM hold_locks INTO @id;
    WHILE @@FETCH_STATUS=0 BEGIN
        SELECT @dummy=1 FROM dbo.tc_ticket_holds WITH(UPDLOCK,HOLDLOCK) WHERE id=@id;
        FETCH NEXT FROM hold_locks INTO @id;
    END;
    CLOSE hold_locks; DEALLOCATE hold_locks;
    DECLARE order_locks CURSOR LOCAL FAST_FORWARD FOR
        SELECT id FROM dbo.tc_orders WHERE hold_id IN(SELECT id FROM @holds) ORDER BY id;
    OPEN order_locks; FETCH NEXT FROM order_locks INTO @id;
    WHILE @@FETCH_STATUS=0 BEGIN
        SELECT @dummy=1 FROM dbo.tc_orders WITH(UPDLOCK,HOLDLOCK) WHERE id=@id;
        FETCH NEXT FROM order_locks INTO @id;
    END;
    CLOSE order_locks; DEALLOCATE order_locks;
    DECLARE @zones TABLE(id uniqueidentifier PRIMARY KEY);
    DECLARE @seats TABLE(id uniqueidentifier PRIMARY KEY);
    INSERT @zones SELECT zone_id FROM dbo.tc_ticket_hold_items WHERE hold_id IN(SELECT id FROM @holds)
        UNION SELECT TRY_CONVERT(uniqueidentifier,JSON_VALUE(value,'$.zoneId')) FROM OPENJSON(@selections)
        WHERE TRY_CONVERT(uniqueidentifier,JSON_VALUE(value,'$.zoneId')) IS NOT NULL;
    INSERT @seats SELECT seat_id FROM dbo.tc_ticket_hold_items WHERE hold_id IN(SELECT id FROM @holds) AND seat_id IS NOT NULL
        UNION SELECT TRY_CONVERT(uniqueidentifier,JSON_VALUE(value,'$.seatId')) FROM OPENJSON(@selections)
        WHERE TRY_CONVERT(uniqueidentifier,JSON_VALUE(value,'$.seatId')) IS NOT NULL;
    DECLARE zone_locks CURSOR LOCAL FAST_FORWARD FOR SELECT id FROM @zones ORDER BY id;
    OPEN zone_locks; FETCH NEXT FROM zone_locks INTO @id;
    WHILE @@FETCH_STATUS=0 BEGIN
        SELECT @dummy=1 FROM dbo.tc_zones WITH(UPDLOCK,HOLDLOCK) WHERE id=@id;
        FETCH NEXT FROM zone_locks INTO @id;
    END;
    CLOSE zone_locks; DEALLOCATE zone_locks;
    DECLARE seat_locks CURSOR LOCAL FAST_FORWARD FOR SELECT id FROM @seats ORDER BY id;
    OPEN seat_locks; FETCH NEXT FROM seat_locks INTO @id;
    WHILE @@FETCH_STATUS=0 BEGIN
        SELECT @dummy=1 FROM dbo.tc_seats WITH(UPDLOCK,HOLDLOCK) WHERE id=@id;
        FETCH NEXT FROM seat_locks INTO @id;
    END;
    CLOSE seat_locks; DEALLOCATE seat_locks;
END;
