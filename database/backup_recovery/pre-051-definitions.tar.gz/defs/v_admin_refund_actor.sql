
CREATE   VIEW dbo.v_admin_refund_actor AS
SELECT u.id,u.status,u.auth_version,
 CAST(CASE WHEN u.platform_role='ADMIN' THEN 1 ELSE 0 END AS bit) is_admin
FROM dbo.tc_users u;
