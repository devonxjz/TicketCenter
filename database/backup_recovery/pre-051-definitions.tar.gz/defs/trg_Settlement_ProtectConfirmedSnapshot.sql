
/* Trigger: trg_Settlement_ProtectConfirmedSnapshot */
CREATE   TRIGGER dbo.trg_Settlement_ProtectConfirmedSnapshot ON dbo.tc_settlements
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM deleted d LEFT JOIN inserted i ON i.id = d.id
        WHERE d.status IN ('CONFIRMED', 'PAID')
          AND (i.id IS NULL OR i.event_id <> d.event_id OR i.created_at <> d.created_at
               OR ISNULL(i.confirmed_at, '19000101') <> ISNULL(d.confirmed_at, '19000101')
               OR i.gross_revenue <> d.gross_revenue OR i.total_refund <> d.total_refund
               OR i.total_commission <> d.total_commission OR i.net_payable <> d.net_payable
               OR NOT (d.status = 'CONFIRMED' AND i.status IN ('CONFIRMED', 'PAID') OR d.status = 'PAID' AND i.status = 'PAID'))
    ) THROW 51109, 'Confirmed settlement snapshot is immutable', 1;
END;
