
/* Stored Procedure: usp_CreateOrderFromHold */
CREATE   PROCEDURE dbo.usp_CreateOrderFromHold @hold_id uniqueidentifier, @actor_id uniqueidentifier
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @started bit = CASE WHEN @@TRANCOUNT = 0 THEN 1 ELSE 0 END;
    IF @started = 1 BEGIN TRANSACTION; ELSE SAVE TRANSACTION tc_sp06;
    BEGIN TRY
        DECLARE @order_id uniqueidentifier, @event_id uniqueidentifier, @subtotal decimal(19,0), @now datetime2(3) = SYSUTCDATETIME();
        SELECT @order_id = id FROM dbo.tc_orders WITH (UPDLOCK, HOLDLOCK) WHERE hold_id = @hold_id;
        IF @order_id IS NOT NULL BEGIN
            SELECT id order_id, order_code, subtotal_amount, discount_amount, total_amount FROM dbo.tc_orders WHERE id = @order_id;
            IF @started = 1 COMMIT TRANSACTION; RETURN;
        END;
        SELECT @event_id = event_id FROM dbo.tc_ticket_holds WITH (UPDLOCK, HOLDLOCK)
        WHERE id = @hold_id AND user_id = @actor_id AND status = 'ACTIVE' AND expires_at > @now;
        IF @event_id IS NULL THROW 51260, 'Active unexpired hold owned by actor required', 1;
        IF NOT EXISTS (SELECT 1 FROM dbo.tc_events WITH (UPDLOCK, HOLDLOCK) WHERE id = @event_id AND status = 'PUBLISHED')
            THROW 51261, 'Event is unavailable', 1;
        SELECT @subtotal = SUM(unit_price * quantity) FROM dbo.tc_ticket_hold_items WHERE hold_id = @hold_id;
        IF @subtotal IS NULL THROW 51262, 'Hold has no items', 1;
        SET @order_id = NEWID();
        INSERT dbo.tc_orders(id, user_id, event_id, hold_id, order_code, subtotal_amount, discount_amount, total_amount)
        VALUES (@order_id, @actor_id, @event_id, @hold_id, CONCAT('ORD-', REPLACE(CONVERT(varchar(36), @order_id), '-', '')), @subtotal, 0, @subtotal);
        INSERT dbo.tc_order_items(order_id, zone_id, seat_id, quantity, unit_price, zone_name_snapshot, seat_label_snapshot)
        SELECT @order_id, hi.zone_id, hi.seat_id, hi.quantity, hi.unit_price, z.name, s.label
        FROM dbo.tc_ticket_hold_items hi JOIN dbo.tc_zones z ON z.id = hi.zone_id LEFT JOIN dbo.tc_seats s ON s.id = hi.seat_id
        WHERE hi.hold_id = @hold_id;
        IF @started = 1 COMMIT TRANSACTION;
        SELECT id order_id, order_code, subtotal_amount, discount_amount, total_amount FROM dbo.tc_orders WHERE id = @order_id;
    END TRY BEGIN CATCH
        IF @started = 1 AND XACT_STATE() <> 0 ROLLBACK TRANSACTION;
        ELSE IF @started = 0 AND XACT_STATE() = 1 ROLLBACK TRANSACTION tc_sp06;
        THROW;
    END CATCH
END;
