
CREATE   PROCEDURE dbo.usp_HoldMutation
    @actor_id uniqueidentifier,@auth_version int,@request_key uniqueidentifier,@fingerprint varchar(64),
    @kind varchar(10),@event_id uniqueidentifier=NULL,@selections nvarchar(max)=N'[]',@hold_id uniqueidentifier=NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON; SET LOCK_TIMEOUT 10000;
    IF @@TRANCOUNT<>0 THROW 51310,'Facade requires autocommit',1;
    IF @request_key IS NULL OR @request_key='00000000-0000-0000-0000-000000000000'
        OR LEN(@fingerprint)<>64 OR @fingerprint LIKE '%[^0-9a-f]%' THROW 51300,'Invalid request',1;
    EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
    BEGIN TRY
        BEGIN TRANSACTION;
        DECLARE @app_result int,@resource nvarchar(255)=CONCAT('hold-user:',CONVERT(varchar(36),@actor_id));
        EXEC @app_result=sys.sp_getapplock @Resource=@resource,@LockMode='Exclusive',@LockOwner='Transaction',@LockTimeout=10000;
        IF @app_result<0 THROW 51830,'Hold user lock unavailable; retry',1;
        DECLARE @payload nvarchar(max),@prior_fingerprint varchar(200),@prior_target uniqueidentifier,
            @key varchar(100)=LOWER(CONVERT(char(36),@request_key)),@changes nvarchar(max),@old_hold uniqueidentifier;
        SELECT @payload=response_payload,@prior_fingerprint=fingerprint,@prior_target=target_id
        FROM dbo.tc_request_idempotency WITH(UPDLOCK,HOLDLOCK)
        WHERE actor_id=@actor_id AND operation='HOLD_MUTATION' AND idempotency_key=@key;
        IF @kind='CANCEL' BEGIN
            SELECT @event_id=event_id FROM dbo.tc_ticket_holds WHERE id=@hold_id AND user_id=@actor_id;
            IF @event_id IS NULL THROW 51304,'Hold not found',1;
        END;
        IF @kind NOT IN('CREATE','CANCEL') THROW 51300,'Invalid mutation kind',1;
        DECLARE @include_active bit=CASE WHEN @kind='CREATE' THEN 1 ELSE 0 END;
        EXEC dbo.usp_HoldLockSelection @actor_id,@event_id,@selections,@hold_id,@include_active;
        EXEC dbo.usp_HoldAuthorize @actor_id,@auth_version;
        IF NOT EXISTS(SELECT 1 FROM dbo.tc_events e JOIN dbo.tc_organizations o WITH(HOLDLOCK) ON o.id=e.organization_id
            WHERE e.id=@event_id AND o.status='APPROVED') THROW 51303,'Event unavailable',1;
        IF @payload IS NOT NULL BEGIN
            IF @prior_fingerprint<>@fingerprint OR (@kind='CANCEL' AND @prior_target<>@hold_id)
                THROW 51308,'Idempotency key conflict',1;
            IF NOT EXISTS(SELECT 1 FROM dbo.tc_ticket_holds WHERE id=@prior_target AND user_id=@actor_id)
                THROW 51304,'Hold not found',1;
            COMMIT;
            SELECT CAST(1 AS bit) replayed,@payload response_payload,N'[]' changes_payload;
            RETURN;
        END;
        DECLARE @affected TABLE(hold_id uniqueidentifier PRIMARY KEY);
        IF @kind='CREATE' BEGIN
            SELECT @old_hold=id FROM dbo.tc_ticket_holds WHERE user_id=@actor_id AND status='ACTIVE';
            EXEC dbo.usp_CreateTicketHold @actor_id,@event_id,@selections,@hold_id OUTPUT,1;
            IF @old_hold IS NOT NULL INSERT @affected VALUES(@old_hold);
        END ELSE IF @kind='CANCEL' BEGIN
            IF EXISTS(SELECT 1 FROM dbo.tc_ticket_holds WHERE id=@hold_id AND status='CONSUMED')
                THROW 51306,'Consumed hold cannot be cancelled',1;
            IF EXISTS(SELECT 1 FROM dbo.tc_ticket_holds WHERE id=@hold_id AND status='ACTIVE')
                INSERT @affected VALUES(@hold_id);
            EXEC dbo.usp_ReleaseTicketHold @hold_id,@actor_id,'USER_CANCEL',@suppress_result=1;
        END ELSE THROW 51300,'Invalid mutation kind',1;
        IF @kind='CREATE' INSERT @affected VALUES(@hold_id);
        DECLARE @outcome varchar(20)=CASE WHEN @kind='CREATE' THEN 'CREATED' ELSE 'CANCELLED' END;
        EXEC dbo.usp_HoldSnapshot @hold_id,@outcome,@payload OUTPUT;
        INSERT dbo.tc_request_idempotency(actor_id,operation,idempotency_key,target_id,fingerprint,response_payload,expires_at)
        VALUES(@actor_id,'HOLD_MUTATION',@key,@hold_id,@fingerprint,@payload,CONVERT(datetime2(3),'9999-12-31'));
        SELECT @changes=(SELECT LOWER(CONVERT(char(36),h.user_id)) actorId,LOWER(CONVERT(char(36),h.event_id)) eventId,
            LOWER(CONVERT(char(36),h.id)) holdId,h.version FROM dbo.tc_ticket_holds h JOIN @affected a ON a.hold_id=h.id FOR JSON PATH);
        COMMIT;
        SELECT CAST(0 AS bit) replayed,@payload response_payload,COALESCE(@changes,N'[]') changes_payload;
    END TRY BEGIN CATCH
        IF XACT_STATE()<>0 ROLLBACK;
        THROW;
    END CATCH;
END;
