
CREATE   PROCEDURE dbo.sp_refund_retry @refund_id uniqueidentifier,@admin_user_id uniqueidentifier,
 @idempotency_key uniqueidentifier,@expected_auth_version int
AS BEGIN SET NOCOUNT ON;
 EXEC dbo.sp_admin_refund_decide @refund_id,@admin_user_id,@expected_auth_version,'RETRY',NULL,NULL,@idempotency_key;
END;
