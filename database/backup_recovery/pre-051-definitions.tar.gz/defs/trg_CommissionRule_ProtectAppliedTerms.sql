
/* Trigger: trg_CommissionRule_ProtectAppliedTerms */
CREATE   TRIGGER dbo.trg_CommissionRule_ProtectAppliedTerms ON dbo.tc_commission_rules
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM deleted d LEFT JOIN inserted i ON i.id = d.id
        WHERE EXISTS (SELECT 1 FROM dbo.tc_events e WHERE e.commission_rule_id = d.id)
          AND (i.id IS NULL OR i.organization_id <> d.organization_id
               OR i.rate_percent <> d.rate_percent OR i.fixed_fee <> d.fixed_fee)
    ) THROW 51103, 'Applied commission terms are immutable', 1;
END;
