
CREATE   TRIGGER dbo.trg_VuongRefundEvidenceFreeze ON dbo.tc_refund_transfer_logs AFTER INSERT,UPDATE,DELETE AS
BEGIN
 SET NOCOUNT ON;
 IF EXISTS(SELECT 1 FROM inserted i FULL JOIN deleted d ON d.id=i.id
 CROSS APPLY(SELECT i.refund_id refund_id UNION SELECT d.refund_id) a JOIN dbo.vw_VuongRefunds r ON r.id=a.refund_id
 JOIN dbo.vw_VuongOrders o ON o.id=r.order_id JOIN dbo.tc_events e WITH(UPDLOCK,HOLDLOCK) ON e.id=o.event_id JOIN dbo.tc_settlements s ON s.event_id=e.id
 WHERE s.status IN('CONFIRMED','PAID') AND r.purpose='CUSTOMER_REFUND')
 THROW 52709,'CONFIRMED_FINANCIAL_SOURCE_IMMUTABLE',1;
END;
